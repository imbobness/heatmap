# Canary Axiom Production Heatmap — implementation kit

This kit converts the Canary historian export into a standard, read-only Axiom heatmap design. It validated **234 of 261** required raw counter mappings exactly. The **27** unresolved roles belong to TAM04, TAM15, and TAM16 and must display as `UNMAPPED` or `OOP`, never as zero.

## Recommended architecture

1. **Canary Historian** retains the raw cumulative counters listed in `axiom_heatmap_tag_map.xlsx`.
2. **Canary Calculation Server** creates reset-safe hour/shift deltas, yields, status codes, timestamps, and projections. Use the historian's reset-aware delta aggregate (commonly `DeltaTotalCount`) rather than subtracting only the first and last raw values.
3. **Canary Views** exposes one normalized asset type, `TAMLine`, so every Axiom line card uses the same bindings even though legacy, transition, hybrid, and Flex PLC tag names differ.
4. **Axiom** uses Asset Template controls for repeated line cards and Symbol controls for the seven colored process zones.

Do not calculate yield from raw cumulative totals. Calculate numerator and denominator over the same time window. If a denominator is zero, quality is bad, or the data is stale, return no value plus a status code—not 0%.

## Standard virtual-view contract

Create a `TAMLine` asset type with instances TAM01–TAM10 and TAM15–TAM33. Add these properties:

- Configuration: `LineNumber`, `LineFamily`, `InProduction`, `HourlyTarget`, `ShiftGoal`, `PlannedMinutes`.
- Raw aliases: `Z1`, `Z2A`, `Z3_IN`, `Z3_OUT`, `Z4_OUT`, `Z5_IN`, `ALI_IN`, `ALI_OUT`, `Z6_IN`.
- Calculated values per window: `HourlyOutput`, `ShiftOutput`, `ShiftProjection`, `Z2A_Yield`, `Z3_Yield`, `Z4_Yield`, `Z5_Yield`, `ALI_Yield`, `Z6_Yield`, `LineYield`.
- Health: `StatusCode`, `WorstZone`, `DataAgeMinutes`, `ActiveStop`, `PlannedDowntime`, `Recovering`.

Status precedence is: OOP → bad/stale/unmapped → planned downtime → active stop → recovering → performance color. Recommended codes: `-2 OOP`, `-1 NO DATA`, `0 GREEN`, `1 YELLOW`, `2 ORANGE`, `3 RED`, `4 ACTIVE DOWN`, `5 RECOVERING`, `6 PLANNED`.

## Axiom screens (1920×1080)

### 1. Operations

- Screen Control: title `3GT TAM Operations Dashboard`; enable asset picker and 60-second refresh.
- Asset Template: `AssetType = TAMLine`; repeat one compact line card per selected line. Default filter: `InProduction = true`; provide a separate saved view that includes OOP lines.
- Each line card shows TAM number, shift actual/goal/projection, Line Yield, Loader Out (`Z6_IN`), worst zone, data age, and seven small Symbol controls in physical order Z1 → Z2A → Z3 → Z4 → Z5 → ALI → Z6.
- Sort first by status severity, then projected goal gap, then TAM number. Never let an OOP line enter fleet performance totals.

### 2. Line Story

- Use `axiom_zone_layout.svg` in an Image Control as the background.
- Overlay seven Symbol controls bound to zone `StatusCode`; overlay Value Boxes for selected-window yield and output.
- Gray placeholders are intentional for physical stations 2B, 4B, 5A, 7, 8, 9, and 10 because they are not in the current KPI chain.
- Clicking a zone navigates to Zone Analysis with the current asset and zone selection.

### 3. Zone Analysis

- Trend Graph: input count, output count, yield, and target using a common time range.
- Value Boxes: current hour, last completed hour, current shift, data age, last good timestamp.
- Events Table: active/recent stop, planned downtime, warning, and recovery events. Separate the initiating event from downstream symptoms.

### 4. Loader Out & Downstream Impact

- Center this screen on `Z6_IN` because it is the final Loader Out count.
- Show Loader Out rate, shift projection, ALI output, line yield, no-increment duration, and recent downstream events.

### 5. Shift History

- Shifts are 06:00–18:00 and 18:00–06:00. Confirm the historian/Axiom timezone before commissioning.
- Show the last 30 shifts by line: actual, goal, projection error, line yield, downtime minutes, planned minutes, and worst zone.

### 6. Data Quality

- Table by line/role: resolved tag, current quality, last timestamp, age, calculation health, and mapping status.
- A failed prerequisite must remain visible and must not roll up as a healthy zero.

## Color limits

- Green: ≥98%; yellow: 90–<98%; orange: 70–<90%; red: <70%.
- Zone-specific targets override the generic green boundary: Z5 95%, ALI 90%, Line 90%; see the config file.
- Active down: dark red. Recovering: blue. No data/unmapped: gray. OOP: slate.
- Use Axiom Symbol/Value Box limits against the calculated status or KPI tag. Put the status code on the symbol and the numeric KPI in the adjacent Value Box.

## Commissioning checklist

1. Import the exact raw mappings into Views and flag TAM04/TAM15/TAM16 as OOP or unresolved.
2. Create reset-safe calculated tags for hourly and shift windows; verify one normal increment and one counter reset per controller family.
3. Confirm Eastern-vs-UTC handling at both shift boundaries and daylight-saving transitions.
4. Verify blank, bad quality, stale, and denominator-zero cases render gray/blank—not green or zero.
5. Compare Axiom deltas with Canary Trend for at least one legacy line, TAM21/22, TAM23, TAM24–28, and TAM29–33.
6. Validate planned downtime exclusion and initiating/downstream event classification with Operations.
7. Grant Axiom read access only. Do not use Data Entry controls or write-back scripts.

## Files

- `axiom_heatmap_tag_map.xlsx`: exact, validated raw aliases and implementation status.
- `axiom_heatmap_config.json`: screen colors, thresholds, shifts, precedence, and machine-readable defaults.
- `axiom_calculation_plan.csv`: calculated metric contract.
- `axiom_zone_layout.svg`: dark process-line background for Axiom Image Control.
- `build_axiom_heatmap_kit.py`: repeatable extractor/validator for future Canary exports.

An importable `.AxiomApp2` is intentionally not fabricated because Canary's application package is proprietary and version-specific. Export a blank or current `.AxiomApp2` from the target Axiom server to use as the safe application template.
