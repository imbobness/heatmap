#!/usr/bin/env python3
"""Build an Axiom heatmap implementation kit from the Canary tag export workbook."""
from __future__ import annotations

import argparse, csv, json, re
from pathlib import Path
import pandas as pd

LINES = list(range(1, 11)) + list(range(15, 34))
ROLES = ["Z1", "Z2A", "Z3_IN", "Z3_OUT", "Z4_OUT", "Z5_IN", "ALI_IN", "ALI_OUT", "Z6_IN"]
TARGETS = {"Z2A": 98, "Z3": 98, "Z4": 98, "Z5": 95, "ALI": 90, "Z6": 98, "LINE": 90}

def legacy(line: int) -> dict[str, str]:
    base=f"VISUSJANAW0001.TAM{line:02d}_HMI.T{line if line != 1 else '01'}_HMI_"
    # The workbook uses T01 for TAM01; other legacy lines use T2...T20.
    suffix={"Z1":"P0_GOODCOUNT1","Z2A":"P0_GOODCOUNT2","Z3_IN":"P0_GOODCOUNT6",
            "Z3_OUT":"P1_GOODCOUNT1","Z4_OUT":"P1_GOODCOUNT3","Z5_IN":"P2_INCOUNT2",
            "ALI_IN":"P2_INCOUNT3","ALI_OUT":"P2_OUTCOUNT3","Z6_IN":"P3_LOAD_IN_CNT"}
    return {k: base+v for k,v in suffix.items()}

def transition(line: int) -> dict[str, str]:
    b=f"VISUSJANAW0001.TAM{line:02d}_AS.T{line}_AS_"
    return {"Z1":b+"P1_Data.Crv_CountIMMStarts","Z2A":b+"P1_Data.GoodCountInlay",
            "Z3_IN":b+"P1_Data.GoodCountCure","Z3_OUT":b+"P1_Data.GoodCountDemold",
            "Z4_OUT":b+"P1_Data.GoodCountFCXfer","Z5_IN":b+"P3_Data.InCountLensXfer",
            "ALI_IN":b+"P3_Data.OutCountLensXfer","ALI_OUT":b+"P3_Data.OutCountDIRemoval",
            "Z6_IN":b+"P4_Data.OutCountLoader"}

def flex(line: int) -> dict[str, str]:
    t=f"T{line}"; root=f"VISUSJANAW0001.TAM{line:02d}_PLC"
    z3plc="01" if line <= 28 else "02"
    z3eq="EM0304_WB_Demold" if line <= 28 else "EM0312_Demold"
    return {
      "Z1":f"{root}01.{t}_PLC01_StatsCnt_Z01.CurrS.Total.In",
      "Z2A":f"{root}01.{t}_PLC01_StatsCnt_Z02.CurrS.Total.In",
      "Z3_IN":f"{root}{z3plc}.{t}_PLC{z3plc}_{z3eq}.StatsCnt.CurrS.Total.In",
      "Z3_OUT":f"{root}{z3plc}.{t}_PLC{z3plc}_{z3eq}.StatsCnt.CurrS.Total.Out",
      "Z4_OUT":f"{root}{z3plc}.{t}_PLC{z3plc}_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out",
      "Z5_IN":f"{root}03.{t}_PLC03_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In",
      "ALI_IN":f"{root}03.{t}_PLC03_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In",
      "ALI_OUT":f"{root}03.{t}_PLC03_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
      "Z6_IN":f"{root}04.{t}_PLC04_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In"}

def expected(line: int) -> tuple[str, dict[str,str]]:
    if line <= 20: return "Legacy 3GT", legacy(line)
    if line in (21,22): return "Transition AB", transition(line)
    if line == 23:
        m=legacy(23)
        m["Z6_IN"]="VISUSJANAW0001.TAM23_AS.T23_AS_P4_Data.OutCountLoader"
        return "Hybrid", m
    return "Flex AB", flex(line)

def norm(s: str) -> str: return re.sub(r"[^a-z0-9]", "", str(s).lower())

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("workbook", type=Path)
    ap.add_argument("outdir", type=Path)
    args=ap.parse_args(); args.outdir.mkdir(parents=True, exist_ok=True)
    book=pd.ExcelFile(args.workbook)
    canary_name=next((s for s in book.sheet_names if s.strip().lower()=="canary"), None)
    if not canary_name:
        raise SystemExit(f"Canary sheet not found. Available sheets: {book.sheet_names}")
    canary=pd.read_excel(book, sheet_name=canary_name, usecols="A:B", dtype=str).fillna("")
    tags=[x.strip() for x in canary.iloc[:,0].tolist() if x.strip()]
    exact={x.lower():x for x in tags}; normalized={norm(x):x for x in tags}
    rows=[]
    for line in LINES:
        family, mapping=expected(line)
        for role in ROLES:
            want=mapping[role]; found=exact.get(want.lower()) or normalized.get(norm(want), "")
            rows.append({"Line":f"TAM{line:02d}","Family":family,"Role":role,
                         "Expected Canary Tag":want,"Resolved Canary Tag":found,
                         "Status":"Exact" if found else "Missing / review",
                         "Use in production":"No" if line in (4,15,16) else "Yes",
                         "Notes":"Never display missing data as zero" if not found else ""})
    csv_path=args.outdir/"axiom_heatmap_tag_map.csv"
    with csv_path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
    (args.outdir/"tag_map_rows.json").write_text(json.dumps(rows,indent=2),encoding="utf-8")
    config={"version":"1.0","sourceWorkbook":args.workbook.name,"lines":LINES,
      "zoneOrder":["Z1","Z2A","Z3","Z4","Z5","ALI","Z6"],"yieldTargetsPct":TARGETS,
      "colors":{"healthy":"#2E7D32","watch":"#F9A825","degraded":"#EF6C00","poor":"#C62828",
      "activeDown":"#7F0000","recovering":"#1565C0","noData":"#616161","outOfProduction":"#455A64"},
      "statusPrecedence":["outOfProduction","badOrStaleData","plannedDowntime","activeStop","recovering","performance"],
      "staleAfterMinutes":5,"refreshSeconds":60,"shifts":["06:00-18:00","18:00-06:00"],
      "readOnly":True,"mappingSummary":{"rows":len(rows),"exact":sum(r["Status"]=="Exact" for r in rows),
      "missing":sum(r["Status"]!="Exact" for r in rows)}}
    (args.outdir/"axiom_heatmap_config.json").write_text(json.dumps(config,indent=2),encoding="utf-8")
    calc_rows=[
      ["Metric","Window","Definition","Target / rule","Axiom display"],
      ["Hourly output","Current clock hour","Reset-safe delta of the zone output counter","Count","Value Box"],
      ["Shift output","Current 12-hour shift","Reset-safe delta from shift start to now","Count","Value Box"],
      ["Shift projection","Current shift","Shift output / elapsed productive minutes × planned productive minutes","Count","Value Box"],
      ["Z2A yield","Selected window","Delta(Z2A) / Delta(Z1) × 100","98%","Symbol + Value Box"],
      ["Z3 yield","Selected window","Delta(Z3_OUT) / Delta(Z3_IN) × 100","98%","Symbol + Value Box"],
      ["Z4 yield","Selected window","Delta(Z4_OUT) / Delta(Z3_OUT) × 100","98%","Symbol + Value Box"],
      ["Z5 yield","Selected window","Delta(Z5_IN) / Delta(Z4_OUT) × 100","95%","Symbol + Value Box"],
      ["ALI yield","Selected window","Delta(ALI_OUT) / Delta(ALI_IN) × 100","90%","Symbol + Value Box"],
      ["Z6 yield","Selected window","Delta(Z6_IN) / Delta(ALI_OUT) × 100","98%","Symbol + Value Box"],
      ["Line yield","Selected window","Delta(Z6_IN) / Delta(Z1) × 100","90%","Line card"],
      ["Stale","Now","Last good timestamp older than 5 minutes","Gray; never zero","Status overlay"],
      ["Active stop","Now","Confirmed stopping event or no-increment rule while scheduled","Dark red","Status override"],
      ["Recovering","Now","Output resumed after stop; hold until stable window passes","Blue","Status override"],
    ]
    with (args.outdir/"axiom_calculation_plan.csv").open("w",newline="",encoding="utf-8-sig") as f:
        csv.writer(f).writerows(calc_rows)
    readme=f"""# Canary Axiom Production Heatmap — implementation kit

This kit converts the Canary historian export into a standard, read-only Axiom heatmap design. It validated **{config['mappingSummary']['exact']} of {config['mappingSummary']['rows']}** required raw counter mappings exactly. The **{config['mappingSummary']['missing']}** unresolved roles belong to TAM04, TAM15, and TAM16 and must display as `UNMAPPED` or `OOP`, never as zero.

## Recommended architecture

1. **Canary Historian** retains the raw cumulative counters listed in `axiom_heatmap_tag_map.xlsx`.
2. **Canary Calculation Server** creates reset-safe hour/shift deltas, yields, status codes, timestamps, and projections. Use the historian's reset-aware delta aggregate (commonly `DeltaTotalCount`) rather than subtracting only the first and last raw values.
3. **Canary Views** exposes one normalized asset type, `TAMLine`, so every Axiom line card uses the same bindings even though legacy, transition, hybrid, and Flex PLC tag names differ.
4. **Axiom** uses Asset Template controls for repeated line cards and Symbol controls for the seven colored process zones.

Do not calculate yield from raw cumulative totals. Calculate numerator and denominator over the same time window. If a denominator is zero, quality is bad, or the data is stale, return no value plus a status code—not 0%.

## Standard virtual-view contract

Create a `TAMLine` asset type with instances TAM01–TAM10 and TAM15–TAM33. Add these properties:

- Configuration: `LineNumber`, `LineFamily`, `InProduction`, `HourlyTarget`, `ShiftGoal`, `PlannedMinutes`.
- Raw aliases: `Z1`, `Z2A`, `Z3_IN`, `Z3_OUT`, `Z4_OUT`, `Z5_IN`, `ALI_IN`, `ALI_OUT`, `Z6_IN`.
- Calculated values per window: `HourlyOutput`, `ShiftOutput`, `ShiftProjection`, `Z2A_Yield`, `Z3_Yield`, `Z4_Yield`, `Z5_Yield`, `ALI_Yield`, `Z6_Yield`, `LineYield`.
- Health: `StatusCode`, `WorstZone`, `DataAgeMinutes`, `ActiveStop`, `PlannedDowntime`, `Recovering`.

Status precedence is: OOP → bad/stale/unmapped → planned downtime → active stop → recovering → performance color. Recommended codes: `-2 OOP`, `-1 NO DATA`, `0 GREEN`, `1 YELLOW`, `2 ORANGE`, `3 RED`, `4 ACTIVE DOWN`, `5 RECOVERING`, `6 PLANNED`.

## Axiom screens (1920×1080)

### 1. Operations

- Screen Control: title `3GT TAM Operations Dashboard`; enable asset picker and 60-second refresh.
- Asset Template: `AssetType = TAMLine`; repeat one compact line card per selected line. Default filter: `InProduction = true`; provide a separate saved view that includes OOP lines.
- Each line card shows TAM number, shift actual/goal/projection, Line Yield, Loader Out (`Z6_IN`), worst zone, data age, and seven small Symbol controls in physical order Z1 → Z2A → Z3 → Z4 → Z5 → ALI → Z6.
- Sort first by status severity, then projected goal gap, then TAM number. Never let an OOP line enter fleet performance totals.

### 2. Line Story

- Use `axiom_zone_layout.svg` in an Image Control as the background.
- Overlay seven Symbol controls bound to zone `StatusCode`; overlay Value Boxes for selected-window yield and output.
- Gray placeholders are intentional for physical stations 2B, 4B, 5A, 7, 8, 9, and 10 because they are not in the current KPI chain.
- Clicking a zone navigates to Zone Analysis with the current asset and zone selection.

### 3. Zone Analysis

- Trend Graph: input count, output count, yield, and target using a common time range.
- Value Boxes: current hour, last completed hour, current shift, data age, last good timestamp.
- Events Table: active/recent stop, planned downtime, warning, and recovery events. Separate the initiating event from downstream symptoms.

### 4. Loader Out & Downstream Impact

- Center this screen on `Z6_IN` because it is the final Loader Out count.
- Show Loader Out rate, shift projection, ALI output, line yield, no-increment duration, and recent downstream events.

### 5. Shift History

- Shifts are 06:00–18:00 and 18:00–06:00. Confirm the historian/Axiom timezone before commissioning.
- Show the last 30 shifts by line: actual, goal, projection error, line yield, downtime minutes, planned minutes, and worst zone.

### 6. Data Quality

- Table by line/role: resolved tag, current quality, last timestamp, age, calculation health, and mapping status.
- A failed prerequisite must remain visible and must not roll up as a healthy zero.

## Color limits

- Green: ≥98%; yellow: 90–<98%; orange: 70–<90%; red: <70%.
- Zone-specific targets override the generic green boundary: Z5 95%, ALI 90%, Line 90%; see the config file.
- Active down: dark red. Recovering: blue. No data/unmapped: gray. OOP: slate.
- Use Axiom Symbol/Value Box limits against the calculated status or KPI tag. Put the status code on the symbol and the numeric KPI in the adjacent Value Box.

## Commissioning checklist

1. Import the exact raw mappings into Views and flag TAM04/TAM15/TAM16 as OOP or unresolved.
2. Create reset-safe calculated tags for hourly and shift windows; verify one normal increment and one counter reset per controller family.
3. Confirm Eastern-vs-UTC handling at both shift boundaries and daylight-saving transitions.
4. Verify blank, bad quality, stale, and denominator-zero cases render gray/blank—not green or zero.
5. Compare Axiom deltas with Canary Trend for at least one legacy line, TAM21/22, TAM23, TAM24–28, and TAM29–33.
6. Validate planned downtime exclusion and initiating/downstream event classification with Operations.
7. Grant Axiom read access only. Do not use Data Entry controls or write-back scripts.

## Files

- `axiom_heatmap_tag_map.xlsx`: exact, validated raw aliases and implementation status.
- `axiom_heatmap_config.json`: screen colors, thresholds, shifts, precedence, and machine-readable defaults.
- `axiom_calculation_plan.csv`: calculated metric contract.
- `axiom_zone_layout.svg`: dark process-line background for Axiom Image Control.
- `build_axiom_heatmap_kit.py`: repeatable extractor/validator for future Canary exports.

An importable `.AxiomApp2` is intentionally not fabricated because Canary's application package is proprietary and version-specific. Export a blank or current `.AxiomApp2` from the target Axiom server to use as the safe application template.
"""
    (args.outdir/"README.md").write_text(readme,encoding="utf-8")
    zones=[("Z1",80),("Z2A",260),("Z3",440),("Z4",620),("Z5",800),("ALI",980),("Z6",1160)]
    blocks=[]
    for label,x in zones:
        blocks.append(f'<rect x="{x}" y="170" width="140" height="90" rx="10" fill="#263238" stroke="#78909C" stroke-width="3"/><text x="{x+70}" y="225" text-anchor="middle" fill="#ECEFF1" font-family="Arial" font-size="25" font-weight="700">{label}</text>')
    svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1380" height="430" viewBox="0 0 1380 430"><rect width="1380" height="430" fill="#101820"/><text x="70" y="70" fill="#ECEFF1" font-family="Arial" font-size="34" font-weight="700">TAM Process Line</text><text x="70" y="105" fill="#90A4AE" font-family="Arial" font-size="18">Overlay Axiom Symbol controls on the seven mapped zones</text><path d="M150 310 H1230" stroke="#607D8B" stroke-width="5" fill="none"/><path d="M1230 310 l-18 -12 v24 z" fill="#607D8B"/>'''+''.join(blocks)+'''<text x="690" y="370" text-anchor="middle" fill="#78909C" font-family="Arial" font-size="16">Product flow • Z6 is Loader Out</text></svg>'''
    (args.outdir/"axiom_zone_layout.svg").write_text(svg,encoding="utf-8")
    print(json.dumps(config["mappingSummary"]))

if __name__ == "__main__": main()
