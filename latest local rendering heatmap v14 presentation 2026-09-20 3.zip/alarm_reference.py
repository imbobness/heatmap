import csv
import io
import json
import os
import re
import traceback
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import parse_qs, urlparse

import pyodbc

HOST = "127.0.0.1"
PORT = 8090
DRIVER = os.getenv("ALARM_SQL_DRIVER", "SQL Server")
USER = os.getenv("ALARM_SQL_USER", "wwUser")
PASSWORD = os.getenv("ALARM_SQL_PASSWORD")
LEGACY_SERVER = os.getenv("LEGACY_ALARM_SERVER", "visusjp3gtalarm.jaxprod.local")
LEGACY_DB = os.getenv("LEGACY_ALARM_DATABASE", "WWALMDB")
FLEX_SERVER = os.getenv("FLEX_ALARM_SERVER", "visusjpflxalarm.jaxprod.local")
FLEX_DB = os.getenv("FLEX_ALARM_DATABASE", "RWAEDB")
LINES = ["TAM01","TAM02","TAM05","TAM06","TAM07","TAM09","TAM10","TAM17","TAM18","TAM20","TAM21","TAM22","TAM23","TAM24","TAM25","TAM26","TAM27","TAM28","TAM29","TAM30","TAM31","TAM32","TAM33"]

ACCESS_PATTERNS = [
    (re.compile(r"zone\s*stop|z\s*stop|zstop|_zstop_|pbl.*actuat", re.I), "Zone stop / stop pushbutton"),
    (re.compile(r"guard\s*(door|open)|safety\s*guard\s*open|guard_open|gls(_lck)?", re.I), "Guard door / guard circuit"),
    (re.compile(r"safety\s*mat|walk.?in\s*mat", re.I), "Safety mat"),
    (re.compile(r"light\s*curtain|lightcurtain", re.I), "Light curtain"),
    (re.compile(r"door\s*open|door_open|door opened", re.I), "Door opened"),
]
CONSEQUENCE_PATTERNS = [
    (re.compile(r"e[- ]?stop|emergency\s*stop|emergency stopped|estopcondition", re.I), "E-stop consequence"),
    (re.compile(r"controller\s*fault|controllerfault|controller fauled", re.I), "Controller consequence"),
    (re.compile(r"not\s*enabled|not\s*ready|emergency", re.I), "Disabled/not-ready consequence"),
    (re.compile(r"zero\s*position|zeroposition", re.I), "Recovery/zero-position consequence"),
]


def connstr(server, database):
    if not PASSWORD:
        raise RuntimeError("Set ALARM_SQL_PASSWORD before starting the application.")
    return (
        f"DRIVER={{{DRIVER}}};SERVER={server};DATABASE={database};"
        f"UID={USER};PWD={PASSWORD};Connection Timeout=15;"
    )


def normalize_line(logging_node):
    match = re.search(r"(\d{1,2})$", str(logging_node or ""))
    return f"TAM{int(match.group(1)):02d}" if match else str(logging_node or "Unknown")


def elapsed_seconds(start, end):
    """Use timestamps, not the inconsistent stored duration columns."""
    if not isinstance(start, datetime) or not isinstance(end, datetime):
        return None
    return round(max((end - start).total_seconds(), 0.0), 3)


def parse_filters(query):
    params = parse_qs(query)
    def number(name, default, low, high):
        try:
            return max(low, min(int(params.get(name, [str(default)])[0]), high))
        except ValueError:
            return default
    source = params.get("source", ["both"])[0]
    if source not in {"both", "legacy", "flex"}: source = "both"
    view = params.get("view", ["actionable"])[0]
    if view not in {"actionable", "all", "candidate", "access", "suppressed"}: view = "actionable"
    return {
        "source": source,
        "view": view,
        "hours": number("hours", 600, 1, 8760),
        "cascadeSeconds": number("cascadeSeconds", 120, 0, 3600),
        "legacyMinPriority": number("legacyMinPriority", 1, -32768, 32767),
        "flexMinSeverity": number("flexMinSeverity", 740, -999999, 999999),
        "limit": number("limit", 10000, 1, 50000),
        "lines": [x.upper() for x in params.get("line", []) if x.upper() in LINES],
        "keyword": params.get("keyword", [""])[0].strip(),
        "zone": params.get("zone", [""])[0].strip(),
    }


def query_legacy(filters):
    # Priority 500 is a hard exclusion by design. It cannot be re-enabled in the UI.
    sql = """
    SELECT TOP (?) LoggingNode, GroupName, Comment, Priority,
           OriginationTime, ReturnTime, TagName, AlarmType
    FROM WWALMDB.dbo.[3GTAlarms]
    WHERE OriginationTime >= DATEADD(HOUR, -?, GETDATE())
      AND Priority >= ?
      AND Priority <> 500
    """
    args = [filters["limit"], filters["hours"], filters["legacyMinPriority"]]
    if filters["keyword"]:
        sql += " AND (Comment LIKE ? OR TagName LIKE ?)"
        term = f"%{filters['keyword']}%"
        args.extend([term, term])
    if filters["zone"]:
        sql += " AND GroupName LIKE ?"
        args.append(f"%{filters['zone']}%")
    sql += " ORDER BY OriginationTime DESC"
    records = []
    with pyodbc.connect(connstr(LEGACY_SERVER, LEGACY_DB), autocommit=True) as connection:
        cursor = connection.cursor()
        cursor.execute(sql, args)
        for row in cursor.fetchall():
            line = normalize_line(row.LoggingNode)
            if filters["lines"] and line not in filters["lines"]: continue
            records.append({
                "sourceSystem": "Legacy 3GT", "line": line,
                "loggingNode": str(row.LoggingNode or ""), "zone": str(row.GroupName or ""),
                "alarm": str(row.Comment or ""), "tag": str(row.TagName or ""),
                "alarmType": str(row.AlarmType or "").strip(), "severity": None,
                "priority": None if row.Priority is None else int(row.Priority),
                "start": row.OriginationTime, "end": row.ReturnTime,
                "durationSeconds": elapsed_seconds(row.OriginationTime, row.ReturnTime),
                "acked": None,
            })
    return records


def query_flex(filters):
    sql = """
    SELECT TOP (?) LoggingNode, SourceName, Message, Severity, Priority,
           AlarmStartTimeStamp, AlarmEndTimeStamp, Acked
    FROM RWAEDB.dbo.FLEXALARMS
    WHERE AlarmStartTimeStamp >= DATEADD(HOUR, -?, GETDATE())
      AND Severity >= ?
    """
    args = [filters["limit"], filters["hours"], filters["flexMinSeverity"]]
    if filters["keyword"]:
        sql += " AND (Message LIKE ? OR SourceName LIKE ?)"
        term = f"%{filters['keyword']}%"
        args.extend([term, term])
    if filters["zone"]:
        sql += " AND SourceName LIKE ?"
        args.append(f"%{filters['zone']}%")
    sql += " ORDER BY AlarmStartTimeStamp DESC"
    records = []
    with pyodbc.connect(connstr(FLEX_SERVER, FLEX_DB), autocommit=True) as connection:
        cursor = connection.cursor()
        cursor.execute(sql, args)
        for row in cursor.fetchall():
            line = normalize_line(row.LoggingNode)
            if filters["lines"] and line not in filters["lines"]: continue
            records.append({
                "sourceSystem": "Flex", "line": line,
                "loggingNode": str(row.LoggingNode or ""), "zone": str(row.SourceName or ""),
                "alarm": str(row.Message or ""), "tag": str(row.SourceName or ""),
                "alarmType": "", "severity": None if row.Severity is None else int(row.Severity),
                "priority": None if row.Priority is None else int(row.Priority),
                "start": row.AlarmStartTimeStamp, "end": row.AlarmEndTimeStamp,
                "durationSeconds": elapsed_seconds(row.AlarmStartTimeStamp, row.AlarmEndTimeStamp),
                "acked": None if row.Acked is None else bool(row.Acked),
            })
    return records


def pattern_match(record, patterns):
    text = " ".join(str(record.get(key) or "") for key in ("alarm", "tag", "zone"))
    for regex, reason in patterns:
        if regex.search(text): return reason
    return None


def classify(records, cascade_seconds):
    grouped = {}
    for record in records: grouped.setdefault(record["line"], []).append(record)
    episode_id = 0
    for line, items in grouped.items():
        items.sort(key=lambda item: item["start"] or datetime.min)
        access_events = []
        for record in items:
            access_reason = pattern_match(record, ACCESS_PATTERNS)
            consequence_reason = pattern_match(record, CONSEQUENCE_PATTERNS)
            base = "Operator Access" if access_reason else ("Consequence" if consequence_reason else "Root-cause Candidate")
            record.update(baseCategory=base, classification=base, nuisance=False, suppressionReason="", accessEpisode=None)
            if access_reason and isinstance(record.get("start"), datetime):
                event_end = record["end"] if isinstance(record.get("end"), datetime) and record["end"] >= record["start"] else record["start"]
                access_events.append({"start": record["start"], "end": event_end + timedelta(seconds=cascade_seconds), "reason": access_reason})
        episodes = []
        for event in access_events:
            if episodes and event["start"] <= episodes[-1]["end"]:
                episodes[-1]["end"] = max(episodes[-1]["end"], event["end"])
                if event["reason"] not in episodes[-1]["reasons"]: episodes[-1]["reasons"].append(event["reason"])
            else:
                episode_id += 1
                episodes.append({"id": episode_id, "start": event["start"], "end": event["end"], "reasons": [event["reason"]]})
        for record in items:
            start = record.get("start")
            if not isinstance(start, datetime): continue
            episode = next((item for item in episodes if item["start"] <= start <= item["end"]), None)
            if not episode: continue
            record["nuisance"] = True
            record["accessEpisode"] = episode["id"]
            if record["baseCategory"] == "Operator Access":
                record["suppressionReason"] = "; ".join(episode["reasons"])
            else:
                record["classification"] = "Suppressed Access Consequence"
                record["suppressionReason"] = f"Started after operator-access trigger on {line}; episode {episode['start'].isoformat()} to {episode['end'].isoformat()}"
    records.sort(key=lambda item: item["start"] or datetime.min, reverse=True)
    return records


def apply_view(records, view):
    if view == "all": return records
    if view == "access": return [x for x in records if x["classification"] == "Operator Access"]
    if view == "suppressed": return [x for x in records if x["classification"] == "Suppressed Access Consequence"]
    if view == "candidate": return [x for x in records if x["classification"] == "Root-cause Candidate"]
    return [x for x in records if not x["nuisance"]]


def query_all(filters):
    """Query Legacy and FLEX alarm databases concurrently when both are requested."""
    records, errors, jobs = [], [], []
    if filters["source"] in {"both", "legacy"}: jobs.append(("Legacy 3GT", query_legacy))
    if filters["source"] in {"both", "flex"}: jobs.append(("Flex", query_flex))
    with ThreadPoolExecutor(max_workers=max(1, len(jobs)), thread_name_prefix="alarm-db") as pool:
        future_map={pool.submit(fn, filters): name for name,fn in jobs}
        for future in as_completed(future_map):
            name=future_map[future]
            try: records.extend(future.result())
            except Exception as error: errors.append({"source": name, "error": str(error)})
    classify(records, filters["cascadeSeconds"])
    return apply_view(records, filters["view"]), records, errors


def summarize(records):
    by_line, alarm_counts = {}, {}
    for record in records:
        info = by_line.setdefault(record["line"], {"line": record["line"], "alarmCount": 0, "alarmMinutes": 0.0, "rootCauseCandidates": 0, "operatorAccess": 0, "suppressedConsequences": 0})
        info["alarmCount"] += 1
        info["alarmMinutes"] += (record["durationSeconds"] or 0) / 60.0
        if record["classification"] == "Root-cause Candidate": info["rootCauseCandidates"] += 1
        elif record["classification"] == "Operator Access": info["operatorAccess"] += 1
        elif record["classification"] == "Suppressed Access Consequence": info["suppressedConsequences"] += 1
        key = (record["line"], record["alarm"])
        alarm_counts[key] = alarm_counts.get(key, 0) + 1
    for info in by_line.values():
        occurrences, alarm = max(((count, alarm) for (line, alarm), count in alarm_counts.items() if line == info["line"]), default=(0, ""))
        info.update(topAlarm=alarm, topAlarmOccurrences=occurrences, alarmMinutes=round(info["alarmMinutes"], 2))
    return sorted(by_line.values(), key=lambda item: (-item["alarmCount"], item["line"]))


def json_ready(record):
    output = dict(record)
    for key in ("start", "end"):
        if hasattr(output[key], "isoformat"): output[key] = output[key].isoformat()
    return output

HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Unified TAM Alarm Viewer</title><style>:root{--bg:#101722;--panel:#1b2533;--grid:#3a4960;--text:#eef4fb;--accent:#65b9ff}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font:13px Arial}header{padding:12px;background:#0a1018}h1{margin:0 0 10px}.filters{display:flex;gap:8px;flex-wrap:wrap;align-items:end}.filters label{display:flex;flex-direction:column;gap:3px}.filters input,.filters select,.filters button,.tabs button{padding:6px;background:#202c3b;color:#fff;border:1px solid var(--grid)}.notice,.meta,.error{padding:7px 12px}.notice{background:#3a2e13;color:#ffe8a3}.error{color:#ff9a9a}.tabs{padding:8px 12px}.panel{margin:0 12px 12px;background:var(--panel);border:1px solid var(--grid)}.scroll{overflow:auto;max-height:calc(100vh - 275px)}table{width:100%;border-collapse:collapse;min-width:1500px}th,td{padding:5px;border:1px solid var(--grid);vertical-align:top}th{position:sticky;top:0;background:#263449;text-align:left}.num{text-align:right}.legacy{background:#253853}.flex{background:#24452f}.line-link{color:var(--accent);text-decoration:underline;cursor:pointer}.hidden{display:none}.alarm{max-width:420px;white-space:normal}</style></head><body><header><h1>Unified TAM Alarm Viewer</h1><div class="filters"><label>Source<select id="source"><option value="both">Both</option><option value="legacy">Legacy 3GT</option><option value="flex">Flex</option></select></label><label>Hours<input id="hours" type="number" value="24"></label><label>Line<select id="line"><option value="">All lines</option></select></label><label>View<select id="view"><option value="actionable">Actionable only</option><option value="all">All alarms</option><option value="candidate">Root-cause candidates</option><option value="access">Operator access</option><option value="suppressed">Suppressed access consequences</option></select></label><label>Cascade window sec<input id="cascadeSeconds" type="number" value="120"></label><label>Legacy min priority<input id="legacyMinPriority" type="number" value="1"></label><label>Flex min severity<input id="flexMinSeverity" type="number" value="740"></label><label>Alarm/tag contains<input id="keyword"></label><label>Zone/source contains<input id="zone"></label><label>Max rows/source<input id="limit" type="number" value="10000"></label><button onclick="loadData()">Run Query</button><button onclick="downloadCsv()">Download CSV</button></div></header><div class="notice">Legacy Priority 500 is permanently excluded. Duration is calculated from alarm appearance timestamp to alarm clear timestamp.</div><div class="tabs"><button onclick="tab('detail')">Alarm Detail</button><button onclick="tab('summary')">Summary by Line</button></div><section id="detailPanel" class="panel"><div id="meta" class="meta"></div><div id="errors"></div><div class="scroll"><table id="detail"></table></div></section><section id="summaryPanel" class="panel hidden"><div class="scroll"><table id="summary"></table></div></section><script>const lines=%LINES%,line=document.getElementById('line');line.innerHTML+=lines.map(x=>`<option>${x}</option>`).join('');function params(){let q=new URLSearchParams();for(let id of ['source','hours','view','cascadeSeconds','legacyMinPriority','flexMinSeverity','keyword','zone','limit'])q.set(id,document.getElementById(id).value);if(line.value)q.append('line',line.value);return q}function fmt(v){return v==null?'':Number(v).toLocaleString(undefined,{maximumFractionDigits:3})}function dt(v){return v?new Date(v).toLocaleString():''}async function loadData(){let d=await fetch('/api/alarms?'+params(),{cache:'no-store'}).then(r=>r.json());if(d.error){errors.innerHTML=`<div class="error">${d.error}</div>`;return}meta.textContent=`${d.records.length.toLocaleString()} visible of ${d.allRecordCount.toLocaleString()} total alarms | ${new Date(d.generatedAt).toLocaleString()}`;errors.innerHTML=(d.errors||[]).map(e=>`<div class="error">${e.source}: ${e.error}</div>`).join('');let h='<tr><th>Source</th><th>Line</th><th>Classification</th><th>Start</th><th>Clear</th><th>Duration sec</th><th>Severity</th><th>Priority</th><th>Zone/Source</th><th>Alarm</th><th>Tag</th><th>Suppression reason</th><th>Episode</th><th>Acked</th></tr>';for(let x of d.records)h+=`<tr class="${x.sourceSystem==='Flex'?'flex':'legacy'}"><td>${x.sourceSystem}</td><td><a class="line-link" onclick="selectLine('${x.line}')">${x.line}</a></td><td>${x.classification}</td><td>${dt(x.start)}</td><td>${dt(x.end)}</td><td class="num">${fmt(x.durationSeconds)}</td><td class="num">${fmt(x.severity)}</td><td class="num">${fmt(x.priority)}</td><td>${x.zone}</td><td class="alarm">${x.alarm}</td><td>${x.tag}</td><td class="alarm">${x.suppressionReason||''}</td><td>${x.accessEpisode||''}</td><td>${x.acked==null?'':x.acked}</td></tr>`;detail.innerHTML=h;let s='<tr><th>Line</th><th>Visible Count</th><th>Alarm Minutes</th><th>Root Candidates</th><th>Operator Access</th><th>Suppressed</th><th>Top Visible Alarm</th><th>Occurrences</th></tr>';for(let x of d.summary)s+=`<tr><td><a class="line-link" onclick="selectLine('${x.line}')">${x.line}</a></td><td>${fmt(x.alarmCount)}</td><td>${fmt(x.alarmMinutes)}</td><td>${fmt(x.rootCauseCandidates)}</td><td>${fmt(x.operatorAccess)}</td><td>${fmt(x.suppressedConsequences)}</td><td>${x.topAlarm}</td><td>${fmt(x.topAlarmOccurrences)}</td></tr>`;summary.innerHTML=s}function selectLine(v){line.value=v;loadData()}function downloadCsv(){location='/api/export.csv?'+params()}function tab(v){detailPanel.classList.toggle('hidden',v!=='detail');summaryPanel.classList.toggle('hidden',v!=='summary')}loadData()</script></body></html>'''.replace('%LINES%', json.dumps(LINES))

class Handler(BaseHTTPRequestHandler):
    def send_bytes(self, body, content_type, status=200, filename=None):
        self.send_response(status); self.send_header("Content-Type", content_type); self.send_header("Cache-Control", "no-store")
        if filename: self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/": return self.send_bytes(HTML.encode(), "text/html; charset=utf-8")
            if parsed.path in {"/api/alarms", "/api/export.csv"}:
                selected = parse_filters(parsed.query)
                records, all_records, errors = query_all(selected)
                if parsed.path == "/api/alarms":
                    payload = {"generatedAt": datetime.now(timezone.utc).isoformat(), "filters": selected, "errors": errors, "allRecordCount": len(all_records), "records": [json_ready(x) for x in records], "summary": summarize(records), "classificationSummary": summarize(all_records)}
                    return self.send_bytes(json.dumps(payload, default=str).encode(), "application/json")
                fields = ["sourceSystem","line","classification","nuisance","suppressionReason","accessEpisode","loggingNode","zone","alarm","tag","alarmType","severity","priority","start","end","durationSeconds","acked"]
                buffer = io.StringIO(); writer = csv.DictWriter(buffer, fieldnames=fields); writer.writeheader()
                for record in records: writer.writerow({key: json_ready(record).get(key) for key in fields})
                return self.send_bytes(buffer.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8", filename="Unified_TAM_Alarms.csv")
            self.send_bytes(b"Not Found", "text/plain", 404)
        except Exception as error:
            traceback.print_exc(); self.send_bytes(json.dumps({"error": str(error)}).encode(), "application/json", 500)
    def log_message(self, fmt, *args): print(f"[{datetime.now().isoformat(timespec='seconds')}] {fmt % args}")

if __name__ == "__main__":
    print(f"Open http://localhost:{PORT}")
    print(f"Legacy {LEGACY_SERVER}/{LEGACY_DB}; Priority 500 excluded")
    print(f"Flex {FLEX_SERVER}/{FLEX_DB}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
