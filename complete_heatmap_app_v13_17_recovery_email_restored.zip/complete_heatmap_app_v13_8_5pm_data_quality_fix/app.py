import math
import json
import os
import random
import smtplib
import ssl
import subprocess
import threading
import time
import traceback
import re
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from concurrent.futures import ThreadPoolExecutor
from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config" / "config.json"
TARGETS_PATH = ROOT / "config" / "targets.json"
ALERTS_PATH = ROOT / "config" / "alerts.json"
ALERT_STATE_PATH = ROOT / "data" / "alert_state.json"
RECIPIENTS_PATH = ROOT / "config" / "recipients.json"
LINE_STATUS_PATH = ROOT / "config" / "line_status.json"
ACTIONS_PATH = ROOT / "data" / "interventions.json"
HISTORICAL_RECORDS_PATH = ROOT / "data" / "historical_records.json"
HISTORY_SCAN_DAYS = int(os.getenv("DASHBOARD_HISTORY_SCAN_DAYS", "365"))
HISTORY_SCAN_STATUS = {"running": False, "startedAt": None, "finishedAt": None, "currentLine": None, "completed": 0, "total": 0, "error": None}
HISTORY_SCAN_LOCK = threading.Lock()

# Visualization-only compliance boundary. In this mode the application is intentionally
# read-only: no source-system writes, no operational record creation, no email sending,
# no intervention logging, and no configuration mutation through the UI/API.
VISUALIZATION_ONLY = os.getenv("DASHBOARD_VISUALIZATION_ONLY", "1").strip().lower() not in {"0", "false", "no"}
APP_VERSION = "13.17-recovery-email-restored"



def load_json(path, default):
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else default
    except (OSError, json.JSONDecodeError):
        return default


DEFAULT_CONFIG = {
    "provider": "aveva-sql",
    "host": "127.0.0.1",
    "port": 8080,
    "historyHours": 12,
    "refreshSeconds": 60,
    "legacyLines": [1, 2, 5, 6, 7, 9, 10, 17, 18, 20],
    "flexLines": [24, 25, 26, 27, 28, 29, 30, 31, 32, 33],
    "sql": {
        "driver": os.getenv("WW_SQL_DRIVER", "ODBC Driver 18 for SQL Server"),
        "server": os.getenv("WW_SQL_SERVER", "visusjp3gthist.na.jnj.com"),
        "database": os.getenv("WW_SQL_DATABASE", "Runtime"),
        "usernameEnv": "WW_SQL_USER",
        "passwordEnv": "WW_SQL_PASSWORD",
    },
}

CONFIG = load_json(CONFIG_PATH, {})
if not CONFIG:
    CONFIG = json.loads(json.dumps(DEFAULT_CONFIG))
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(CONFIG, indent=2), encoding="utf-8")
else:
    merged = json.loads(json.dumps(DEFAULT_CONFIG))
    merged.update({key: value for key, value in CONFIG.items() if key != "sql"})
    merged["sql"].update(CONFIG.get("sql", {}))
    CONFIG = merged

# Startup scripts set DASHBOARD_MODE so demo/live cannot accidentally mix providers.
_mode = os.getenv("DASHBOARD_MODE", "").strip().lower()
if _mode in {"demo", "synthetic"}:
    CONFIG["provider"] = "synthetic"
    CONFIG["alarmProvider"] = "synthetic"
elif _mode == "live":
    CONFIG["provider"] = "aveva-sql"
    CONFIG["alarmProvider"] = "live"

HOST = str(CONFIG.get("host", "127.0.0.1"))
PORT = int(CONFIG.get("port", 8080))
HISTORY_HOURS = int(CONFIG.get("historyHours", 12))
REFRESH_SECONDS = int(CONFIG.get("refreshSeconds", 60))

YIELD_TARGETS = {
    "Z2A_YIELD": 98.0,
    "Z3_YIELD": 98.0,
    "Z4_YIELD": 98.0,
    "Z5_YIELD": 95.0,
    "ALI_YIELD": 90.0,
    "Z6_YIELD": 98.0,
    "LINE_YIELD": 90.0,
}

EXCLUDED_LINES = {
    "TAM03", "TAM04", "TAM08", "TAM11", "TAM12", "TAM13",
    "TAM14", "TAM15", "TAM16", "TAM19",
}

LEGACY_PREFIXES = {
    1: "A", 2: "B", 3: "C", 4: "D", 5: "E", 6: "F", 7: "G",
    8: "H", 9: "I", 10: "J", 15: "K", 16: "L", 17: "M",
    18: "N", 19: "O", 20: "P",
}

LEGACY_OVERRIDES = {}
FLEX_OVERRIDES = {
    26: {
        "ALI_IN": "L26_PLC3.EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.Out",
        "ALI_OUT": "L26_PLC3.EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
    },
    27: {
        "ALI_IN": "L27_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In",
        "ALI_OUT": "L27_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
    },
}


def legacy_tags(line_number):
    prefix = LEGACY_PREFIXES.get(line_number)
    if prefix is None:
        raise ValueError(f"No historian prefix defined for TAM{line_number:02d}")
    return {
        "Z1": f"{prefix}P0_GOODCOUNT1",
        "Z2A": f"{prefix}P0_GOODCOUNT2",
        "Z3_IN": f"{prefix}P0_GOODCOUNT6",
        "Z3_OUT": f"{prefix}P1_GOODCOUNT1",
        "Z4_OUT": f"{prefix}P1_GOODCOUNT3",
        "Z5_IN": f"{prefix}P2_INCOUNT2",
        "ALI_IN": f"{prefix}P2_INCOUNT3",
        "ALI_OUT": f"{prefix}P2_OUTCOUNT3",
        "Z6_IN": f"{prefix}P3_LOAD_IN_CNT",
    }


def transition_tags(line_number):
    if line_number not in (21, 22):
        raise ValueError("transition_tags supports TAM21/TAM22 only")
    p1 = f"L{line_number}_P1_Data."
    p3 = f"L{line_number}_P3_Data."
    p4 = f"L{line_number}_P4_Data."
    return {
        "Z1": p1 + "Crv_CountIMMStarts",
        "Z2A": p1 + "GoodCountInlay",
        "Z3_IN": p1 + "GoodCountCure",
        "Z3_OUT": p1 + "GoodCountDemold",
        "Z4_OUT": p1 + "GoodCountFCXfer",
        "Z5_IN": p3 + "InCountLensXfer",
        "ALI_IN": p3 + "OutCountLensXfer",
        "ALI_OUT": p3 + "OutCountDIRemoval",
        "Z6_IN": p4 + "OutCountLoader",
    }


def tam23_tags():
    return {
        "Z1": "SP0_GOODCOUNT1", "Z2A": "SP0_GOODCOUNT2",
        "Z3_IN": "SP0_GOODCOUNT6", "Z3_OUT": "SP1_GOODCOUNT1",
        "Z4_OUT": "SP1_GOODCOUNT3", "Z5_IN": "SP2_INCOUNT2",
        "ALI_IN": "SP2_INCOUNT3", "ALI_OUT": "SP2_OUTCOUNT3",
        "Z6_IN": "SP3_LOAD_IN_CNT",
    }


def flex_tags(line_number):
    p1 = f"L{line_number}_PLC1_"
    p2 = f"L{line_number}_PLC2_"
    p3 = f"L{line_number}_PLC3_"
    p4 = f"L{line_number}_PLC4_"
    if line_number >= 29:
        return {
            "Z1": p1 + "Global.StatsCnt_Z01.CurrS.Total.In",
            "Z2A": p1 + "Global.StatsCnt_Z02.CurrS.Total.In",
            "Z3_IN": p2 + "EM0312_Demold.StatsCnt.CurrS.Total.In",
            "Z3_OUT": p2 + "EM0312_Demold.StatsCnt.CurrS.Total.Out",
            "Z4_IN": p2 + "EM0332_FC_Transfer.StatsCnt.CurrS.Total.In",
            "Z4_OUT": p2 + "EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out",
            "Z5_IN": p3 + "EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In",
            "ALI_IN": p3 + "EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In",
            "ALI_OUT": p3 + "EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
            "Z6_IN": p4 + "EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In",
        }
    return {
        "Z1": p1 + "Global.StatsCnt_Z01.CurrS.Total.In",
        "Z2A": p1 + "Global.StatsCnt_Z02.CurrS.Total.In",
        "Z3_IN": p1 + "EM0304_WB_Demold.StatsCnt.CurrS.Total.In",
        "Z3_OUT": p1 + "EM0304_WB_Demold.StatsCnt.CurrS.Total.Out",
        "Z4_OUT": p1 + "EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out",
        "Z5_IN": p3 + "EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In",
        "ALI_IN": p3 + "EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.In",
        "ALI_OUT": p3 + "EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
        "Z6_IN": p4 + "EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In",
    }


def apply_overrides(tags, overrides, line_number):
    result = dict(tags)
    result.update(overrides.get(line_number, {}))
    return result


SUPPORTED_LEGACY_LINES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 16, 17, 18, 19, 20]
configured_legacy = {int(value) for value in CONFIG.get("legacyLines", SUPPORTED_LEGACY_LINES)}
legacy_numbers = [n for n in SUPPORTED_LEGACY_LINES if n in configured_legacy]
flex_numbers = [int(n) for n in CONFIG.get("flexLines", range(24, 34)) if int(n) >= 24]
LEGACY_MAP = {f"TAM{n:02d}": apply_overrides(legacy_tags(n), LEGACY_OVERRIDES, n) for n in legacy_numbers}
TRANSITION_MAP = {
    "TAM21": transition_tags(21), "TAM22": transition_tags(22), "TAM23": tam23_tags()
}
FLEX_MAP = {f"TAM{n:02d}": apply_overrides(flex_tags(n), FLEX_OVERRIDES, n) for n in flex_numbers}
ALL_LINE_MAP = {
    line: tags for line, tags in {**LEGACY_MAP, **TRANSITION_MAP, **FLEX_MAP}.items()
    if line not in EXCLUDED_LINES
}


def load_line_targets():
    return load_json(TARGETS_PATH, {})


def atomic_write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2), encoding="utf-8")
    temp.replace(path)

def load_recipients_config():
    config = load_json(RECIPIENTS_PATH, {})
    if config:
        return config
    alerts = load_json(ALERTS_PATH, {})
    emails = []
    for key in ("performanceRecipients", "zoneRecipients"):
        for email in alerts.get(key, []):
            if email and email.lower() not in {x["email"].lower() for x in emails}:
                emails.append({"name": email.split("@")[0], "email": email, "enabled": True})
    return {"people": emails, "groups": {"Hourly Performance": [x["email"] for x in emails], "Zone Alerts": alerts.get("zoneRecipients", [])}, "activePerformanceGroup": "Hourly Performance", "activeZoneGroup": "Zone Alerts"}

def resolve_recipients(config, purpose):
    rc = load_recipients_config()
    group = rc.get("activePerformanceGroup" if purpose == "performance" else "activeZoneGroup")
    members = rc.get("groups", {}).get(group, [])
    enabled = {p.get("email", "").lower() for p in rc.get("people", []) if p.get("enabled", True)}
    resolved = [e for e in members if e.lower() in enabled]
    fallback = "performanceRecipients" if purpose == "performance" else "zoneRecipients"
    return resolved or config.get(fallback, [])

def trend_metrics(periods, hourly_targets):
    completed = [p for p in periods if not p.get("isLiveHour")]
    values = [p.get("columns", {}).get("Z6_IN") for p in completed]
    values = [float(v) for v in values if isinstance(v, (int, float))]
    if not values:
        return {"status":"No data","direction":"unknown","message":"No completed hourly loader data yet."}
    recent = values[:3]; prior = values[3:6]
    recent_avg = sum(recent)/len(recent); prior_avg = sum(prior)/len(prior) if prior else None
    change = ((recent_avg-prior_avg)/prior_avg*100) if prior_avg and prior_avg > 0 else None
    target = hourly_targets.get("Z6_IN")
    target_pct = recent_avg/target*100 if isinstance(target,(int,float)) and target>0 else None
    if change is None: direction,status="stable","Establishing trend"
    elif change >= 5: direction,status="improving","Recovering"
    elif change <= -5: direction,status="declining","Declining"
    else: direction,status="stable","Stabilizing"
    message = "Recent output is improving. Allow stabilization after corrective actions unless a new fault appears." if direction=="improving" else ("Recent output is deteriorating; additional investigation may be warranted." if direction=="declining" else "Recent output is relatively stable; watch the next hour before escalating if conditions remain controlled.")
    return {"status":status,"direction":direction,"recentAverage":round(recent_avg,2),"priorAverage":None if prior_avg is None else round(prior_avg,2),"changePercent":None if change is None else round(change,2),"targetAttainmentPercent":None if target_pct is None else round(target_pct,2),"message":message,"series":list(reversed(values[:8]))}

def action_status(trend, projected_attainment=None):
    """Translate shift attainment + current trend into an operational recommendation."""
    direction = (trend or {}).get("direction", "unknown")
    current = (trend or {}).get("targetAttainmentPercent")
    change = (trend or {}).get("changePercent")
    projected = projected_attainment if isinstance(projected_attainment, (int, float)) else None

    if direction == "unknown" or current is None:
        return {"code":"NO_DATA","label":"NO DATA","priority":5,"message":"Not enough completed-hour data to classify the line."}
    if direction == "declining" and (current < 95 or (projected is not None and projected < 95)):
        return {"code":"INTERVENE","label":"INTERVENE","priority":1,"message":"Performance is below expectation and deteriorating. Investigate the active constraint."}
    if direction == "declining":
        return {"code":"INVESTIGATE","label":"INVESTIGATE","priority":2,"message":"The line is still acceptable overall, but recent output is declining. Check for an emerging constraint."}
    if direction == "improving" and current < 98:
        return {"code":"RECOVERING","label":"RECOVERING","priority":3,"message":"Output is improving but has not fully recovered. Continue monitoring the existing corrective action."}
    if direction in ("improving", "stable") and current >= 98 and projected is not None and projected < 95:
        return {"code":"STABILIZE","label":"STABILIZE","priority":4,"message":"Current rate has recovered even though earlier losses keep the shift projection low. Avoid unnecessary adjustment while performance holds."}
    if direction == "stable" and current < 95:
        return {"code":"INVESTIGATE","label":"INVESTIGATE","priority":2,"message":"Performance is persistently below target without a clear recovery trend."}
    return {"code":"HEALTHY","label":"HEALTHY","priority":5,"message":"Current performance and trend are acceptable. Continue normal monitoring."}

def safe_yield(output_value, input_value):
    if not isinstance(input_value, (int, float)) or input_value == 0:
        return None
    if not isinstance(output_value, (int, float)):
        return None
    return round(output_value / input_value * 100.0, 2)


def counter_delta(start_value, end_value):
    if start_value is None or end_value is None:
        return None
    return end_value - start_value if end_value >= start_value else end_value



def sanitize_zone_production(values, hourly_targets):
    """
    Reject obviously impossible one-hour production deltas caused by bad historian
    samples/counter discontinuities. This affects visualization calculations only.

    A valid production delta should be non-negative and reasonably close to the
    configured hourly target. We allow a generous 4x target ceiling so short bursts
    are not clipped. If a zone has no configured target, use a 100,000 lens/hour
    absolute safety ceiling.

    Rejected values become None / No data rather than displaying millions/billions
    or contaminating yield/trend calculations.
    """
    cleaned = {}
    for key, value in values.items():
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            cleaned[key] = None
            continue

        target = hourly_targets.get(key)
        if isinstance(target, (int, float)) and target > 0:
            ceiling = max(float(target) * 4.0, 25000.0)
        else:
            ceiling = 100000.0

        if value < 0 or value > ceiling:
            print(
                f"[DATA QUALITY] Rejected implausible production delta "
                f"{key}={value:,.0f}; ceiling={ceiling:,.0f}"
            )
            cleaned[key] = None
        else:
            cleaned[key] = value
    return cleaned


def calculate_columns(values):
    return {
        "Z1": values.get("Z1"),
        "Z2A_YIELD": safe_yield(values.get("Z2A"), values.get("Z1")),
        "Z2A": values.get("Z2A"),
        "Z3_IN": values.get("Z3_IN"),
        "Z3_YIELD": safe_yield(values.get("Z3_OUT"), values.get("Z3_IN")),
        "Z3_OUT": values.get("Z3_OUT"),
        "Z4_YIELD": safe_yield(values.get("Z4_OUT"), values.get("Z3_OUT")),
        "Z4_OUT": values.get("Z4_OUT"),
        "Z5_YIELD": safe_yield(values.get("Z5_IN"), values.get("Z4_OUT")),
        "Z5_IN": values.get("Z5_IN"),
        "ALI_IN": values.get("ALI_IN"),
        "ALI_YIELD": safe_yield(values.get("ALI_OUT"), values.get("ALI_IN")),
        "ALI_OUT": values.get("ALI_OUT"),
        "Z6_YIELD": safe_yield(values.get("Z6_IN"), values.get("ALI_OUT")),
        "Z6_IN": values.get("Z6_IN"),
        "LINE_YIELD": safe_yield(values.get("Z6_IN"), values.get("Z1")),
    }


def format_hour(value):
    return value.strftime("%#I:%M %p") if os.name == "nt" else value.strftime("%-I:%M %p")


def build_connection_string():
    sql = dict(CONFIG["sql"])
    sql["driver"] = os.getenv("WW_SQL_DRIVER", sql.get("driver", "ODBC Driver 18 for SQL Server"))
    sql["server"] = os.getenv("WW_SQL_SERVER", sql.get("server", ""))
    sql["database"] = os.getenv("WW_SQL_DATABASE", sql.get("database", "Runtime"))
    username_env = sql.get("usernameEnv", "WW_SQL_USER")
    password_env = sql.get("passwordEnv", "WW_SQL_PASSWORD")
    username = os.getenv(username_env)
    password = os.getenv(password_env)
    if not username or not password:
        raise RuntimeError(f"Set {username_env} and {password_env} before starting app.py")
    return (
        f"DRIVER={{{sql['driver']}}};SERVER={sql['server']};DATABASE={sql['database']};"
        f"UID={username};PWD={password};TrustServerCertificate=yes;"
    )


def query_live(cursor, tag):
    cursor.execute("SELECT TOP 1 DateTime, Value, Quality, QualityDetail FROM Runtime.dbo.AnalogLive WHERE TagName = ?", tag)
    row = cursor.fetchone()
    if row is None:
        return None
    return {"timestamp": row[0], "value": None if row[1] is None else float(row[1]), "quality": row[2], "qualityDetail": row[3]}


def query_delta_values(cursor, tag, start_time, end_time):
    cursor.execute("""
        SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory
        WHERE TagName = ? AND DateTime >= ? AND DateTime <= ?
          AND wwRetrievalMode = 'Delta'
        ORDER BY DateTime
    """, tag, start_time, end_time)
    return [(row[0], None if row[1] is None else float(row[1])) for row in cursor.fetchall()]


def query_boundaries(cursor, tag, start_time, end_time):
    cursor.execute("""
        SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory
        WHERE TagName = ? AND DateTime >= ? AND DateTime <= ?
          AND wwRetrievalMode = 'Cyclic' AND wwResolution = 3600000
        ORDER BY DateTime
    """, tag, start_time, end_time)
    return {row[0].replace(minute=0, second=0, microsecond=0): (None if row[1] is None else float(row[1])) for row in cursor.fetchall()}


def accumulated_counter_delta(samples):
    usable = [(stamp, value) for stamp, value in samples if isinstance(value, (int, float))]
    if len(usable) < 2:
        return None
    total = 0.0
    previous = usable[0][1]
    for _, current in usable[1:]:
        total += current - previous if current >= previous else current
        previous = current
    return round(total, 2)


def current_shift_start(now):
    six = now.replace(hour=6, minute=0, second=0, microsecond=0)
    eighteen = now.replace(hour=18, minute=0, second=0, microsecond=0)
    if now >= eighteen:
        return eighteen
    if now >= six:
        return six
    return six - timedelta(hours=12)


def query_loader_shift_metrics(cursor, loader_tag, now):
    shift_start = current_shift_start(now)
    previous_start = shift_start - timedelta(hours=12)
    last_shift = accumulated_counter_delta(query_delta_values(cursor, loader_tag, previous_start, shift_start))
    current_samples = query_delta_values(cursor, loader_tag, shift_start, now)
    live = query_live(cursor, loader_tag)
    effective_now = now
    if live and isinstance(live["value"], (int, float)):
        effective_now = live["timestamp"]
        if not current_samples or current_samples[-1][0] < live["timestamp"]:
            current_samples.append((live["timestamp"], live["value"]))
    actual = accumulated_counter_delta(current_samples)
    elapsed = max((effective_now - shift_start).total_seconds(), 0.0)
    projection = round(actual / elapsed * 43200, 2) if isinstance(actual, (int, float)) and elapsed > 0 else None
    return last_shift, actual, projection


def load_line_status():
    raw = load_json(LINE_STATUS_PATH, {})
    return {line: bool(raw.get(line, True)) for line in ALL_LINE_MAP}


def line_is_in_production(line):
    return load_line_status().get(line, True)


def active_production_lines():
    status = load_line_status()
    return [line for line in ALL_LINE_MAP if status.get(line, True)]


def synthetic_all_lines_shift_overview():
    """Offline/demo fleet overview with deterministic operational states."""
    targets = load_line_targets(); rows=[]; now=datetime.now()
    states = [
        (68,-13,72),(72,16,88),(76,3,101),(80,-8,90),(84,12,94),(87,1,99),
        (89,-6,96),(91,9,97),(93,2,100),(94,-10,91),(96,7,101),(97,1,100),
        (98,-5,97),(99,5,102),(100,1,101),(102,-2,100),(103,6,104),(105,0,103)
    ]
    active_lines = active_production_lines()
    for idx,line in enumerate(active_lines):
        goal=targets.get(line,{}).get("SHIFT_GOAL") or 42000
        attainment,change,current_pct=states[idx % len(states)]
        projection=round(goal*attainment/100.0); last_shift=round(goal*(.88+((idx*7)%19)/100.0)); actual=round(projection*.58)
        direction="improving" if change>=5 else "declining" if change<=-5 else "stable"
        trend={"direction":direction,"changePercent":change,"targetAttainmentPercent":current_pct}
        action=action_status(trend, attainment)
        rows.append({"line":line,"lastShift":last_shift,"currentActual":actual,"currentProjection":projection,"goal":goal,"attainment":attainment,"gap":round(projection-goal,2),"trendDirection":direction,"trendChange":change,"currentRateAttainment":current_pct,"action":action,"error":None})
    rows.sort(key=lambda row:(row["attainment"],row["line"]))
    return {"generatedAt":datetime.now(timezone.utc).isoformat(),"shiftStart":current_shift_start(now).isoformat(),"rows":rows,"provider":"synthetic-demo"}


def synthetic_management_review_triggers():
    overview = synthetic_all_lines_shift_overview()["rows"]
    results = []
    for i, row in enumerate(overview[:7]):
        reds = 2 + i
        tier = "Tier 3" if reds >= 8 else "Tier 2" if reds >= 5 else "Tier 1"
        results.append({"tier": tier, "line": row["line"], "consecutiveRedShifts": reds,
                        "lastCompletedShift": row["lastShift"], "goal": row["goal"],
                        "gap": round(row["lastShift"]-row["goal"], 2),
                        "lastKnownGreenShift": round(row["goal"]*1.03),
                        "lastGreenEnd": (datetime.now(timezone.utc)-timedelta(hours=12*(reds+1))).isoformat()})
    rank={"Tier 3":3,"Tier 2":2,"Tier 1":1}
    results.sort(key=lambda r:(-rank[r["tier"]],-r["consecutiveRedShifts"],r["line"]))
    return {"generatedAt": datetime.now(timezone.utc).isoformat(), "rows": results,
            "provider": "synthetic-demo"}

def all_lines_shift_overview():
    import pyodbc
    now = datetime.now()
    targets = load_line_targets()
    rows = []
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for line, tags in ALL_LINE_MAP.items():
            if not line_is_in_production(line):
                continue
            goal = targets.get(line, {}).get("SHIFT_GOAL")
            last_shift = actual = projection = None
            error = None
            try:
                last_shift, actual, projection = query_loader_shift_metrics(cursor, tags["Z6_IN"], now)
            except Exception as exc:
                error = str(exc)
            attainment = gap = None
            if isinstance(projection, (int, float)) and isinstance(goal, (int, float)) and goal > 0:
                attainment = round(projection / goal * 100.0, 2)
                gap = round(projection - goal, 2)
            # Operational-intelligence columns for the fleet overview.
            # Current Rate = current average shift rate expressed against the configured
            # Loader Out hourly target. Trend compares the latest two completed hourly
            # Loader Out deltas, and Action uses the existing dashboard decision logic.
            current_rate_attainment = None
            trend_change = None
            trend_direction = None
            action = None
            try:
                hourly_target = targets.get(line, {}).get("Z6_IN")
                shift_start = current_shift_start(now)
                elapsed_hours = max((now - shift_start).total_seconds() / 3600.0, 0.0)
                if isinstance(actual, (int, float)) and isinstance(hourly_target, (int, float)) and hourly_target > 0 and elapsed_hours > 0:
                    current_hourly_rate = actual / elapsed_hours
                    current_rate_attainment = round(current_hourly_rate / hourly_target * 100.0, 2)

                current_hour = now.replace(minute=0, second=0, microsecond=0)
                boundary_start = current_hour - timedelta(hours=3)
                b = query_boundaries(cursor, tags["Z6_IN"], boundary_start, current_hour)
                hourly = []
                for i in range(2):
                    hs = current_hour - timedelta(hours=2-i)
                    delta = counter_delta(b.get(hs), b.get(hs + timedelta(hours=1)))
                    if isinstance(delta, (int, float)) and isinstance(hourly_target, (int, float)) and hourly_target > 0:
                        # Same generous data-quality ceiling used by the heatmap.
                        ceiling = max(float(hourly_target) * 4.0, 25000.0)
                        if 0 <= delta <= ceiling:
                            hourly.append(delta)
                if len(hourly) >= 2 and hourly[-2] > 0:
                    trend_change = round((hourly[-1] - hourly[-2]) / hourly[-2] * 100.0, 2)
                    trend_direction = "improving" if trend_change >= 5 else "declining" if trend_change <= -5 else "stable"

                trend = {
                    "direction": trend_direction,
                    "changePercent": trend_change,
                    "targetAttainmentPercent": current_rate_attainment
                }
                action = action_status(trend, attainment)
            except Exception as exc:
                print(f"[OVERVIEW INTELLIGENCE] {line}: {exc}")

            rows.append({
                "line": line,
                "lastShift": last_shift,
                "currentActual": actual,
                "currentProjection": projection,
                "goal": goal,
                "attainment": attainment,
                "gap": gap,
                "currentRateAttainment": current_rate_attainment,
                "trendDirection": trend_direction,
                "trendChange": trend_change,
                "action": action,
                "error": error
            })
    rows.sort(key=lambda row: (row["attainment"] is None, row["attainment"] if row["attainment"] is not None else 999999, row["line"]))
    return {"generatedAt": datetime.now(timezone.utc).isoformat(), "shiftStart": current_shift_start(now).isoformat(), "rows": rows}


def completed_shift_history(cursor, loader_tag, shift_start, count=60, goal=None):
    """Return completed 12-hour shifts oldest -> newest, rejecting impossible historian totals."""
    records = []
    # A real completed shift can exceed goal, but multi-million/billion values are counter artifacts.
    # Use a deliberately generous 2x goal ceiling; if goal is unavailable, use 150,000 units/shift.
    ceiling = max(float(goal) * 2.0, 75000.0) if isinstance(goal, (int, float)) and goal > 0 else 150000.0
    for index in range(count - 1, -1, -1):
        shift_end = shift_start - timedelta(hours=12 * index)
        shift_begin = shift_end - timedelta(hours=12)
        try:
            samples = query_delta_values(cursor, loader_tag, shift_begin, shift_end)
            total = accumulated_counter_delta(samples)
            if isinstance(total, (int, float)) and math.isfinite(total):
                if 0 <= total <= ceiling:
                    records.append({"start": shift_begin, "end": shift_end, "value": round(total, 2)})
                else:
                    print(f"[DATA QUALITY] Rejected impossible completed shift {loader_tag} "
                          f"{shift_begin.isoformat()} -> {shift_end.isoformat()}: "
                          f"{total:,.0f} (ceiling {ceiling:,.0f})")
        except Exception as exc:
            print(f"[SHIFT HISTORY] {loader_tag} {shift_begin.isoformat()} -> {shift_end.isoformat()} failed: {exc}")
    return records


def load_historical_records():
    return load_json(HISTORICAL_RECORDS_PATH, {"version":1,"lines":{},"department":{},"generatedAt":None,"scanDays":HISTORY_SCAN_DAYS})

def _record_from_shifts(line, shifts, goal):
    valid=[r for r in shifts if isinstance(r.get("value"),(int,float))]
    ranked=sorted(valid,key=lambda r:r["value"],reverse=True)[:10]
    greens=[r for r in valid if goal and r["value"]>=goal]
    last_green=max(greens,key=lambda r:r["end"]) if greens else None
    def ser(r):
        return None if not r else {"value":round(r["value"],2),"start":r["start"].isoformat(),"end":r["end"].isoformat(),"attainment":round(r["value"]/goal*100,2) if goal else None}
    return {"line":line,"goal":goal,"record":ser(ranked[0]) if ranked else None,"top10":[ser(r) for r in ranked],"lastGreen":ser(last_green),"shiftsScanned":len(valid)}

def deep_shift_history_for_line(line, scan_days=HISTORY_SCAN_DAYS):
    import pyodbc
    loader_tag = ALL_LINE_MAP[line].get("Z6_IN")
    if not loader_tag:
        raise ValueError(f"No Loader Out historian tag mapped for {line}")
    goal = float(load_line_targets().get(line, {}).get("SHIFT_GOAL", 0) or 0)
    shift_start = current_shift_start(datetime.now())
    remaining = max(60, int(scan_days * 2))
    records = []
    with pyodbc.connect(build_connection_string(), timeout=30, autocommit=True) as connection:
        cursor = connection.cursor()
        # Query in 60-shift chunks to keep historian requests bounded.
        while remaining > 0:
            take = min(60, remaining)
            chunk = completed_shift_history(cursor, loader_tag, shift_start, take, goal)
            records.extend(chunk)
            shift_start = shift_start - timedelta(hours=12 * take)
            remaining -= take
    return _record_from_shifts(line, records, goal)


def synthetic_historical_record(line):
    goal=float(load_line_targets().get(line,{}).get("SHIFT_GOAL",0) or 0); seed=sum(map(ord,line))+4401
    rng=random.Random(seed); end=current_shift_start(datetime.now(timezone.utc)); shifts=[]
    for i in range(180):
        start=end-timedelta(hours=12*(i+1)); base=goal*(.95+(seed%8)/100) if goal else 42000
        shifts.append({"start":start,"end":start+timedelta(hours=12),"value":round(max(0,base*(1+rng.uniform(-.11,.10))),2)})
    return _record_from_shifts(line,shifts,goal)

def rebuild_historical_records_worker():
    try:
        lines=list(ALL_LINE_MAP)
        with HISTORY_SCAN_LOCK: HISTORY_SCAN_STATUS.update({"running":True,"startedAt":datetime.now(timezone.utc).isoformat(),"finishedAt":None,"currentLine":None,"completed":0,"total":len(lines),"error":None})
        results={}
        if CONFIG.get("provider")!="aveva-sql":
            for idx,line in enumerate(lines,1):
                results[line]=synthetic_historical_record(line)
                with HISTORY_SCAN_LOCK: HISTORY_SCAN_STATUS.update({"currentLine":line,"completed":idx})
        else:
            # Controlled concurrency plus 30-day query chunks avoids one enormous historian response.
            with ThreadPoolExecutor(max_workers=3,thread_name_prefix="history-scan") as pool:
                jobs=[(line,pool.submit(deep_shift_history_for_line,line)) for line in lines]
                for idx,(line,fut) in enumerate(jobs,1):
                    try: results[line]=fut.result()
                    except Exception as exc: results[line]={"line":line,"error":str(exc),"top10":[],"record":None,"lastGreen":None,"shiftsScanned":0}
                    with HISTORY_SCAN_LOCK: HISTORY_SCAN_STATUS.update({"currentLine":line,"completed":idx})
        candidates=[{"line":line,**r["record"]} for line,r in results.items() if r.get("record")]
        department=max(candidates,key=lambda r:r["value"]) if candidates else None
        atomic_write_json(HISTORICAL_RECORDS_PATH,{"version":1,"generatedAt":datetime.now(timezone.utc).isoformat(),"scanDays":HISTORY_SCAN_DAYS,"lines":results,"department":{"record":department}})
        with HISTORY_SCAN_LOCK: HISTORY_SCAN_STATUS.update({"running":False,"finishedAt":datetime.now(timezone.utc).isoformat(),"currentLine":None})
    except Exception as exc:
        with HISTORY_SCAN_LOCK: HISTORY_SCAN_STATUS.update({"running":False,"finishedAt":datetime.now(timezone.utc).isoformat(),"error":str(exc)})

def start_historical_rebuild():
    with HISTORY_SCAN_LOCK:
        if HISTORY_SCAN_STATUS.get("running"): return dict(HISTORY_SCAN_STATUS)
        HISTORY_SCAN_STATUS.update({"running":True,"startedAt":datetime.now(timezone.utc).isoformat(),"finishedAt":None,"currentLine":None,"completed":0,"total":len(ALL_LINE_MAP),"error":None})
    threading.Thread(target=rebuild_historical_records_worker,name="historical-record-rebuild",daemon=True).start()
    return dict(HISTORY_SCAN_STATUS)

def historical_record_summary(line):
    cache=load_historical_records(); rec=cache.get("lines",{}).get(line)
    if not rec and CONFIG.get("provider")!="aveva-sql": rec=synthetic_historical_record(line)
    return {"line":line,"record":rec or {},"department":cache.get("department",{}),"generatedAt":cache.get("generatedAt"),"scanDays":cache.get("scanDays",HISTORY_SCAN_DAYS),"scanStatus":dict(HISTORY_SCAN_STATUS)}

def query_shift_summary(cursor, tags, now, shift_goal=None):
    loader_tag = tags.get("Z6_IN")
    if not loader_tag:
        return []
    shift_start = current_shift_start(now)
    samples = query_delta_values(cursor, loader_tag, shift_start, now)
    live = query_live(cursor, loader_tag)
    effective_now = now
    if live and isinstance(live["value"], (int, float)):
        effective_now = live["timestamp"]
        if not samples or samples[-1][0] < live["timestamp"]:
            samples.append((live["timestamp"], live["value"]))
    actual = accumulated_counter_delta(samples)
    elapsed = max((effective_now - shift_start).total_seconds(), 0.0)
    remaining = max(43200 - elapsed, 0.0)
    hourly_rate = round(actual / elapsed * 3600, 2) if isinstance(actual, (int, float)) and elapsed > 0 else None
    projected_remaining = round(actual / elapsed * remaining, 2) if isinstance(actual, (int, float)) and elapsed > 0 else None
    projected_total = round(actual + projected_remaining, 2) if isinstance(actual, (int, float)) and isinstance(projected_remaining, (int, float)) else None
    completed = completed_shift_history(cursor, loader_tag, shift_start, 60, shift_goal)

    def average_last(count):
        values = [row["value"] for row in completed[-count:]]
        return round(sum(values) / len(values), 2) if values else None

    below = above = None
    if isinstance(shift_goal, (int, float)) and shift_goal > 0:
        below = 0
        for row in reversed(completed):
            if row["value"] < shift_goal:
                below += 1
            else:
                break
        above = 0
        for row in reversed(completed):
            if row["value"] >= shift_goal:
                above += 1
            else:
                break
    attainment = round(projected_total / shift_goal * 100, 2) if isinstance(projected_total, (int, float)) and isinstance(shift_goal, (int, float)) and shift_goal > 0 else None
    detail = f"{format_hour(shift_start)} to {format_hour(shift_start + timedelta(hours=12))}"
    if isinstance(actual, (int, float)) and isinstance(hourly_rate, (int, float)):
        detail += f" | Actual {round(actual):,} | Rate {round(hourly_rate):,}/hr"
    rows = [{"label": "Current Shift Projection", "shiftWindow": detail, "value": projected_total, "format": "count"}]
    if isinstance(shift_goal, (int, float)):
        rows += [
            {"label": "Shift Goal", "shiftWindow": "Configured Loader In goal", "value": shift_goal, "format": "count"},
            {"label": "Projected Attainment", "shiftWindow": "Projection versus shift goal", "value": attainment, "format": "percent"},
        ]
    rows += [
        {"label": "5 Shift Average", "shiftWindow": "Last 5 completed shifts", "value": average_last(5), "format": "count"},
        {"label": "14 Shift Average", "shiftWindow": "Last 14 completed shifts", "value": average_last(14), "format": "count"},
        {"label": "20 Shift Average", "shiftWindow": "Last 20 completed shifts", "value": average_last(20), "format": "count"},
        {"label": "Consecutive Shifts Below Goal", "shiftWindow": "Most recent completed shifts below configured goal", "value": below, "format": "integer"},
        {"label": "Consecutive Shifts Above Goal", "shiftWindow": "Most recent completed shifts meeting or exceeding configured goal", "value": above, "format": "integer"},
        {"label": "30 Day Average", "shiftWindow": "Last 60 completed shifts", "value": average_last(60), "format": "count"},
    ]
    return rows


def _management_review_state(completed, goal):
    """Derive Management Review state chronologically from historian data; no local status record required."""
    valid = [r for r in completed if isinstance(r.get("value"), (int, float))]
    on_review = False
    entered_tier = None
    red_run = 0
    current_red_run = 0
    avg20 = None
    exit_met = False

    for idx, row in enumerate(valid):
        value = row["value"]
        if value < goal:
            red_run += 1
        else:
            red_run = 0

        if not on_review and red_run >= 2:
            on_review = True
            entered_tier = "Tier 3" if red_run >= 8 else "Tier 2" if red_run >= 5 else "Tier 1"

        if on_review and idx >= 19:
            recent20 = [x["value"] for x in valid[idx-19:idx+1]]
            avg20 = sum(recent20) / 20.0
            if avg20 >= goal:
                on_review = False
                exit_met = True
                entered_tier = None
                # A future 2-red run can place the line back on review.

    # Current consecutive-red run is always measured newest backwards.
    for row in reversed(valid):
        if row["value"] < goal:
            current_red_run += 1
        else:
            break

    recent20 = [r["value"] for r in valid[-20:]]
    avg20 = (sum(recent20) / 20.0) if len(recent20) == 20 else None
    tier = "Tier 3" if current_red_run >= 8 else "Tier 2" if current_red_run >= 5 else "Tier 1" if current_red_run >= 2 else "Recovery"
    return {
        "onReview": on_review,
        "tier": tier if on_review else None,
        "consecutiveRedShifts": current_red_run,
        "twentyShiftAverage": round(avg20, 2) if avg20 is not None else None,
        "twentyShiftGap": round(avg20 - goal, 2) if avg20 is not None else None,
        "exitCriteriaMet": (not on_review and exit_met),
    }


def management_review_triggers():
    import pyodbc
    now = datetime.now()
    shift_start = current_shift_start(now)
    targets = load_line_targets()
    results = []
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for line, tags in ALL_LINE_MAP.items():
            if not line_is_in_production(line):
                continue
            goal = targets.get(line, {}).get("SHIFT_GOAL")
            loader_tag = tags.get("Z6_IN")
            if not isinstance(goal, (int, float)) or goal <= 0 or not loader_tag:
                continue
            try:
                # 120 shifts (~60 days) gives enough context to derive prior review entry/exit.
                completed = completed_shift_history(cursor, loader_tag, shift_start, 120, goal)
            except Exception as exc:
                results.append({"tier": "Error", "line": line, "error": str(exc)})
                continue
            if not completed:
                continue
            review = _management_review_state(completed, goal)
            if not review["onReview"]:
                continue
            last = completed[-1]
            last_green = next((row for row in reversed(completed) if row["value"] >= goal), None)
            cached_green = None
            if last_green is None:
                cached_green = load_historical_records().get("lines", {}).get(line, {}).get("lastGreen")
            results.append({
                "tier": review["tier"], "line": line,
                "consecutiveRedShifts": review["consecutiveRedShifts"],
                "lastCompletedShift": last["value"], "goal": goal,
                "gap": round(last["value"] - goal, 2),
                "twentyShiftAverage": review["twentyShiftAverage"],
                "twentyShiftGap": review["twentyShiftGap"],
                "reviewStatus": "REMAINS ON REVIEW",
                "lastKnownGreenShift": last_green["value"] if last_green is not None else (cached_green or {}).get("value"),
                "lastGreenEnd": last_green["end"].isoformat() if last_green is not None else (cached_green or {}).get("end"),
            })
    tier_rank = {"Tier 3": 3, "Tier 2": 2, "Tier 1": 1, "Recovery": 0, "Error": -1}
    results.sort(key=lambda row: (-tier_rank.get(row.get("tier"), 0), -row.get("consecutiveRedShifts", 0), row["line"]))
    return {"generatedAt": datetime.now(timezone.utc).isoformat(), "rows": results}


def hourly_live_data(selected_line):
    import pyodbc
    if selected_line not in ALL_LINE_MAP:
        raise ValueError(f"Unknown TAM line: {selected_line}")
    tags = ALL_LINE_MAP[selected_line]
    targets = load_line_targets().get(selected_line, {})
    now = datetime.now()
    current_hour = now.replace(minute=0, second=0, microsecond=0)
    first_boundary = current_hour - timedelta(hours=HISTORY_HOURS)
    boundaries, live_values, missing = {}, {}, []
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for key, tag in tags.items():
            boundaries[key] = query_boundaries(cursor, tag, first_boundary, current_hour)
            live_values[key] = query_live(cursor, tag)
            if not boundaries[key] and live_values[key] is None:
                missing.append(tag)
        summary = query_shift_summary(cursor, tags, now, targets.get("SHIFT_GOAL"))
    periods = []
    for offset in range(HISTORY_HOURS - 1, -1, -1):
        start = first_boundary + timedelta(hours=offset)
        end = start + timedelta(hours=1)
        values = {key: counter_delta(boundaries[key].get(start), boundaries[key].get(end)) for key in tags}
        values = sanitize_zone_production(values, targets)
        periods.append({"label": f"{format_hour(start)} to {format_hour(end)}", "start": start.isoformat(), "end": end.isoformat(), "isLiveHour": False, "columns": calculate_columns(values)})
    live_metrics = {}
    live_end = now
    for key in tags:
        record = live_values[key]
        value = None if record is None else record["value"]
        if record and record["timestamp"] > live_end:
            live_end = record["timestamp"]
        live_metrics[key] = counter_delta(boundaries[key].get(current_hour), value)
    live_metrics = sanitize_zone_production(live_metrics, targets)
    periods.insert(0, {"label": "Current Hour", "start": current_hour.isoformat(), "end": live_end.isoformat(), "isLiveHour": True, "columns": calculate_columns(live_metrics)})
    return {
        "provider": "aveva-sql-hourly", "generatedAt": datetime.now(timezone.utc).isoformat(),
        "selectedLine": selected_line, "availableLines": list(ALL_LINE_MAP),
        "historyHours": HISTORY_HOURS, "refreshSeconds": REFRESH_SECONDS,
        "targets": YIELD_TARGETS, "hourlyTargets": targets, "shiftGoal": targets.get("SHIFT_GOAL"),
        "tags": tags, "missingTags": missing, "periods": periods, "shiftSummary": summary, "trend": trend_metrics(periods, targets), "actionStatus": action_status(trend_metrics(periods, targets), None),
    }



def load_interventions():
    raw = load_json(ACTIONS_PATH, {"actions": []})
    actions = raw.get("actions", []) if isinstance(raw, dict) else []
    return actions if isinstance(actions, list) else []

def save_interventions(actions):
    ACTIONS_PATH.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_json(ACTIONS_PATH, {"actions": actions})

def interventions_for_line(line):
    rows = [a for a in load_interventions() if a.get("line") == line]
    rows.sort(key=lambda a: a.get("timestamp", ""), reverse=True)
    return rows

def synthetic_hourly_data(selected_line):
    if selected_line not in ALL_LINE_MAP: selected_line=next(iter(ALL_LINE_MAP))
    targets=load_line_targets().get(selected_line,{}); now=datetime.now(); current_hour=now.replace(minute=0,second=0,microsecond=0); periods=[]
    idx=list(ALL_LINE_MAP).index(selected_line)
    # Oldest -> newest multipliers. Different lines demonstrate recovery, stabilization, decline and healthy operation.
    profiles=[
        [.62,.66,.70,.75,.82,.90,.97,1.01], [.98,.95,.91,.86,.82,.78,.73,.69],
        [.72,.78,.86,.94,.99,1.01,1.00,1.01], [.99,1.00,1.01,1.00,.99,1.00,1.01,1.00]
    ]
    profile=profiles[idx%len(profiles)]; z6target=targets.get("Z6_IN") or 5200
    for offset in range(HISTORY_HOURS):
        start=current_hour-timedelta(hours=offset+1); mult=profile[-1-offset] if offset<len(profile) else profile[0]
        z6=int(z6target*mult); ali=max(int(z6/.88),1); z4=max(int(ali/.95),1); z3=max(int(z4/.96),1); z1=max(int(z3/.94),1)
        values={"Z1":z1,"Z2A":int(z1*.98),"Z3_IN":z3,"Z3_OUT":int(z3*.98),"Z4_OUT":z4,"Z5_IN":int(z4*.96),"ALI_IN":ali,"ALI_OUT":ali,"Z6_IN":z6}
        periods.append({"label":f"{format_hour(start)} to {format_hour(start+timedelta(hours=1))}","start":start.isoformat(),"end":(start+timedelta(hours=1)).isoformat(),"isLiveHour":False,"columns":calculate_columns(values)})
    periods.insert(0,dict(periods[0],label="Current Hour",isLiveHour=True))
    trend=trend_metrics(periods,targets)
    overview=next((r for r in synthetic_all_lines_shift_overview()["rows"] if r["line"]==selected_line),None)
    projected_attainment=overview.get("attainment") if overview else None; action=action_status(trend,projected_attainment)
    goal=targets.get("SHIFT_GOAL") or 42000; projection=round(goal*(projected_attainment or 90)/100)
    summary=[
      {"label":"Current Shift Projection","shiftWindow":"Synthetic demo projection","value":projection,"format":"count"},
      {"label":"Projected Attainment","shiftWindow":"Projection versus shift goal","value":projected_attainment,"format":"percent"},
      {"label":"5 Shift Average","shiftWindow":"Previous 5 completed shifts","value":round(goal*.94),"format":"count"},
      {"label":"14 Shift Average","shiftWindow":"Previous 14 completed shifts","value":round(goal*.96),"format":"count"},
      {"label":"20 Shift Average","shiftWindow":"Previous 20 completed shifts","value":round(goal*.97),"format":"count"},
      {"label":"Consecutive Shifts Below Goal","shiftWindow":"Synthetic demo history","value":2 if projected_attainment and projected_attainment<95 else 0,"format":"count"},
      {"label":"Consecutive Shifts Above Goal","shiftWindow":"Synthetic demo history","value":1 if projected_attainment and projected_attainment>=98 else 0,"format":"count"},
      {"label":"30 Day Average","shiftWindow":"Synthetic demo history","value":round(goal*.965),"format":"count"}]
    return {"provider":"synthetic-hourly","generatedAt":datetime.now(timezone.utc).isoformat(),"selectedLine":selected_line,"availableLines":list(ALL_LINE_MAP),"historyHours":HISTORY_HOURS,"refreshSeconds":REFRESH_SECONDS,"targets":YIELD_TARGETS,"hourlyTargets":targets,"shiftGoal":goal,"tags":ALL_LINE_MAP[selected_line],"missingTags":[],"periods":periods,"shiftSummary":summary,"trend":trend,"actionStatus":action,"projectedAttainment":projected_attainment}



def synthetic_alarm_events(line, periods):
    rows=sorted([p for p in periods if not p.get("isLiveHour")], key=lambda p:p["start"])
    if not rows: return []
    base=datetime.fromisoformat(rows[max(1,len(rows)//2-1)]["start"])+timedelta(minutes=17)
    specs=[("Root-cause Candidate","Z4","Z4 servo position deviation",base,660),("Consequence","Z4","Z4 controller fault",base+timedelta(minutes=2),480),("Operator Access","Z4","Zone Stop Pushbutton Actuated",base+timedelta(minutes=48),240),("Suppressed Access Consequence","Z4","Controller not enabled",base+timedelta(minutes=49),180),("Suppressed Access Consequence","Z4","Zero position required",base+timedelta(minutes=50),120)]
    # Demo declining lines keep one current root-cause alarm active so the Line Story page can exercise DOWN state rendering.
    if list(ALL_LINE_MAP).index(line) % 4 == 1:
        active_start=datetime.now()-timedelta(minutes=22)
        specs.append(("Root-cause Candidate","Z4","Z4 controller not enabled — active demo fault",active_start,3600))
    return [{"sourceSystem":"Synthetic Alarm DB","line":line,"classification":c,"zone":z,"alarm":a,"tag":"DEMO_"+z,"severity":900 if c=="Root-cause Candidate" else 780,"priority":None,"start":t.isoformat(),"end":(t+timedelta(seconds=d)).isoformat(),"durationSeconds":d,"acked":True} for c,z,a,t,d in specs]

def alarm_events(line, data):
    alarm_mode = str(CONFIG.get("alarmProvider", "live" if CONFIG.get("provider") == "aveva-sql" else "synthetic")).lower()
    if alarm_mode not in {"live", "alarm-sql", "sql"}:
        return synthetic_alarm_events(line, data.get("periods",[]))
    # Live alarm mode reuses the supplied alarm database query/classification engine.
    from alarm_reference import query_all, json_ready as alarm_json_ready
    filters={"source":"both","view":"all","hours":24,"cascadeSeconds":120,"legacyMinPriority":1,"flexMinSeverity":740,"limit":10000,"lines":[line],"keyword":"","zone":""}
    _visible, records, errors=query_all(filters)
    if errors and not records:
        raise RuntimeError("; ".join(f"{e['source']}: {e['error']}" for e in errors))
    return [alarm_json_ready(r) for r in records]

def combined_line_snapshot(line):
    """Query production historian and alarm databases concurrently for one line."""
    live_production = CONFIG.get("provider") == "aveva-sql"
    production_fn = hourly_live_data if live_production else synthetic_hourly_data
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="line-data") as pool:
        prod_future = pool.submit(production_fn, line)
        # Alarm query needs only the line in live mode; synthetic alarm generation needs periods,
        # so resolve production first only for synthetic alarms.
        alarm_mode = str(CONFIG.get("alarmProvider", "live" if live_production else "synthetic")).lower()
        if alarm_mode in {"live", "alarm-sql", "sql"}:
            alarm_future = pool.submit(alarm_events, line, {"periods": []})
            data = prod_future.result()
            try:
                alarms = alarm_future.result()
            except Exception as exc:
                print(f"Alarm source unavailable for {line}: {exc}")
                alarms = []
        else:
            data = prod_future.result()
            try:
                alarms = alarm_events(line, data)
            except Exception as exc:
                print(f"Synthetic alarm generation unavailable for {line}: {exc}")
                alarms = []
    return data, alarms

def shift_history_data(line, count=60):
    count = max(5, min(int(count or 60), 120))
    goal = float(load_line_targets().get(line, {}).get("SHIFT_GOAL", 0) or 0)
    if CONFIG.get("provider") != "aveva-sql":
        seed = sum(ord(c) for c in line) + 913
        rng = random.Random(seed)
        now = current_shift_start(datetime.now(timezone.utc))
        base = goal * (0.93 + (seed % 9) / 100.0) if goal else 42000
        rows=[]
        drift=0.0
        for i in range(count-1,-1,-1):
            drift += rng.uniform(-0.012,0.012)
            value=max(0, base*(1+drift+rng.uniform(-0.09,0.07)))
            start=now-timedelta(hours=12*(i+1))
            rows.append({"start":start.isoformat(),"end":(start+timedelta(hours=12)).isoformat(),"value":round(value,2),"attainment":round(value/goal*100,2) if goal else None})
        return {"line":line,"goal":goal,"rows":rows,"provider":"synthetic-history"}
    import pyodbc
    tags=ALL_LINE_MAP.get(line)
    if not tags or not tags.get("Z6_IN"):
        raise ValueError(f"No Loader Out historian tag mapped for {line}")
    now=datetime.now(timezone.utc)
    shift_start=current_shift_start(now)
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        rows=completed_shift_history(connection.cursor(), tags["Z6_IN"], shift_start, count, goal)
    # completed_shift_history already returns oldest -> newest for charting
    for r in rows:
        r["start"]=r["start"].isoformat(); r["end"]=r["end"].isoformat(); r["attainment"]=round(r["value"]/goal*100,2) if goal else None
    return {"line":line,"goal":goal,"rows":rows,"provider":"aveva-sql"}


def connection_health():
    status = {"mode": "live" if CONFIG.get("provider") == "aveva-sql" else "demo", "production": {}, "alarms": {}, "email": {}}
    # Production historian
    try:
        if CONFIG.get("provider") != "aveva-sql":
            status["production"] = {"ok": True, "mode": "synthetic", "detail": "Synthetic production data"}
        else:
            import pyodbc
            started=time.perf_counter()
            with pyodbc.connect(build_connection_string(), timeout=8, autocommit=True) as c:
                c.cursor().execute("SELECT TOP 1 TagName FROM Runtime.dbo.AnalogLive").fetchone()
            status["production"]={"ok":True,"mode":"live","detail":CONFIG["sql"].get("server", ""),"ms":round((time.perf_counter()-started)*1000)}
    except Exception as exc:
        status["production"]={"ok":False,"mode":"live","detail":str(exc)}
    # Alarm DBs (Legacy and FLEX are independent SQL databases)
    alarm_mode=str(CONFIG.get("alarmProvider", "live" if CONFIG.get("provider") == "aveva-sql" else "synthetic")).lower()
    if alarm_mode not in {"live","alarm-sql","sql"}:
        status["alarms"]={"ok":True,"mode":"synthetic","detail":"Synthetic alarm data","sources":{}}
    else:
        try:
            import pyodbc
            import alarm_reference as ar
            sources={}
            for name,server,database in [("legacy",ar.LEGACY_SERVER,ar.LEGACY_DB),("flex",ar.FLEX_SERVER,ar.FLEX_DB)]:
                try:
                    started=time.perf_counter()
                    with pyodbc.connect(ar.connstr(server,database), timeout=8, autocommit=True) as c:
                        c.cursor().execute("SELECT 1").fetchone()
                    sources[name]={"ok":True,"server":server,"database":database,"ms":round((time.perf_counter()-started)*1000)}
                except Exception as exc:
                    sources[name]={"ok":False,"server":server,"database":database,"detail":str(exc)}
            status["alarms"]={"ok":all(x["ok"] for x in sources.values()),"mode":"live","sources":sources}
        except Exception as exc:
            status["alarms"]={"ok":False,"mode":"live","detail":str(exc),"sources":{}}
    alerts=load_alert_config()
    status["email"]={"ok":True,"enabled":bool(alerts.get("enabled",False)),"transport":alerts.get("transport","outlook"),"detail":"OFF by default at startup" if not alerts.get("enabled") else "Enabled by user after startup"}
    status["generatedAt"]=datetime.now(timezone.utc).isoformat()
    return status

def build_shift_story(line,data,alarms,actions):
    timeline=[]
    for a in alarms:
        if a.get("classification")=="Suppressed Access Consequence": continue
        timeline.append({"timestamp":a["start"],"kind":"access" if a.get("classification")=="Operator Access" else "alarm","label":a.get("classification","Alarm"),"zone":a.get("zone",""),"detail":a.get("alarm","")})
    for a in actions: timeline.append({"timestamp":a.get("timestamp"),"kind":"action","label":"Corrective action","zone":a.get("zone",""),"detail":a.get("action","")})
    timeline.sort(key=lambda x:x.get("timestamp") or "")
    trend=data.get("trend",{}); status=data.get("actionStatus",{}); change=trend.get("changePercent"); att=data.get("projectedAttainment")
    roots=[a for a in alarms if a.get("classification")=="Root-cause Candidate"]; accesses=[a for a in alarms if a.get("classification")=="Operator Access"]
    headline=f"{line} — {status.get('label','MONITOR')}"+(f": {roots[0].get('alarm')} is the leading alarm candidate." if roots else ": no root-cause alarm candidate identified.")
    trendword="improving" if change is not None and change>=5 else ("declining" if change is not None and change<=-5 else "stable")
    narrative=(f"Projected shift attainment is {att:.1f}%. " if att is not None else "")+f"Recent production is {trendword}"+(f" ({change:+.1f}% versus the prior 3-hour window). " if change is not None else ". ")+f"The timeline contains {len(roots)} root-cause candidate(s), {len(accesses)} operator-access event(s), and {len(actions)} logged intervention(s). Alarm association is temporal evidence, not proof of causation."
    return {"line":line,"headline":headline,"narrative":narrative,"alarmMinutes":sum((a.get("durationSeconds") or 0) for a in alarms)/60,"rootCandidates":len(roots),"operatorAccess":len(accesses),"interventionCount":len(actions),"timeline":timeline,"alarms":alarms}

DEFAULT_ALERT_CONFIG = {
    "enabled": False,
    "transport": "outlook",
    "fromAddress": "",
    "performanceRecipients": [],
    "zoneRecipients": [],
    # Special 5 PM performance email: intentionally sent only to the MTL/user.
    "fivePmRecipient": "rdees1@its.jnj.com",
    "performanceThresholdPercent": 95.0,
    "performanceStartHourIntoShift": 2,
    "zoneIdleMinutes": 15,
    "zoneCheckMinutes": 5,
    "zoneKeys": ["Z1", "Z2A", "Z3_OUT", "Z4_OUT", "Z5_IN", "ALI_OUT", "Z6_IN"],
    "sendRecoveryEmails": True,
    "lineDowntimeZone": "Z6_IN",
    "smtp": {"host": "", "port": 587, "startTls": True, "usernameEnv": "ALERT_SMTP_USER", "passwordEnv": "ALERT_SMTP_PASSWORD"},
}


def load_alert_config():
    config = dict(DEFAULT_ALERT_CONFIG)
    raw = load_json(ALERTS_PATH, {})
    config.update({key: value for key, value in raw.items() if key != "smtp"})
    smtp = dict(DEFAULT_ALERT_CONFIG["smtp"])
    smtp.update(raw.get("smtp", {}))
    config["smtp"] = smtp
    return config


def load_alert_state():
    state = load_json(ALERT_STATE_PATH, {})
    state.setdefault("performanceSent", {})
    state.setdefault("zones", {})
    state.setdefault("lastRun", None)
    state.setdefault("lastError", None)
    state.setdefault("downtimeEvents", [])
    return state


def line_shift_downtime_minutes(state, line, shift_start, line_zone="Z6_IN"):
    """Completed no-increment time for the configured line-output counter, clipped to this shift."""
    shift_end = shift_start + timedelta(hours=12)
    intervals = []
    for event in state.get("downtimeEvents", []):
        if event.get("line") != line or event.get("zone") != line_zone:
            continue
        try:
            event_start = datetime.fromisoformat(event["startedAt"])
            event_end = datetime.fromisoformat(event["recoveredAt"])

            reference_tz = shift_start.tzinfo or timezone.utc
            if event_start.tzinfo is None:
                event_start = event_start.replace(tzinfo=reference_tz)
            else:
                event_start = event_start.astimezone(reference_tz)
            if event_end.tzinfo is None:
                event_end = event_end.replace(tzinfo=reference_tz)
            else:
                event_end = event_end.astimezone(reference_tz)

            if shift_start.tzinfo is None:
                shift_start = shift_start.replace(tzinfo=reference_tz)
                shift_end = shift_end.replace(tzinfo=reference_tz)

            start = max(event_start, shift_start)
            end = min(event_end, shift_end)
        except (KeyError, TypeError, ValueError):
            continue
        if end > start:
            intervals.append((start, end))
    intervals.sort()
    merged = []
    for start, end in intervals:
        if not merged or start > merged[-1][1]:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    return round(sum((end-start).total_seconds() for start, end in merged) / 60.0, 1)


def current_shift_downtime_summary():
    """
    Current-shift downtime by line/zone using dashboard-detected no-increment events.
    Includes recovered events plus currently active downtime, clipped to the current
    12-hour shift. Intended to support the 5 PM shift-status calculation.
    """
    state = load_alert_state()
    now = datetime.now(timezone.utc)
    shift_start = current_shift_start(now)
    shift_end = shift_start + timedelta(hours=12)

    by_line = {}
    by_zone = {}
    events = []

    # Completed downtime events.
    for event in state.get("downtimeEvents", []):
        try:
            event_start = datetime.fromisoformat(event["startedAt"])
            event_end = datetime.fromisoformat(event["recoveredAt"])
            if event_start.tzinfo is None:
                event_start = event_start.replace(tzinfo=timezone.utc)
            else:
                event_start = event_start.astimezone(timezone.utc)
            if event_end.tzinfo is None:
                event_end = event_end.replace(tzinfo=timezone.utc)
            else:
                event_end = event_end.astimezone(timezone.utc)
        except (KeyError, TypeError, ValueError):
            continue

        start = max(event_start, shift_start)
        end = min(event_end, now, shift_end)
        if end <= start:
            continue

        minutes = (end - start).total_seconds() / 60.0
        line = str(event.get("line", "Unknown"))
        zone = str(event.get("zone", "Unknown"))
        by_line[line] = by_line.get(line, 0.0) + minutes
        key = f"{line} / {zone}"
        by_zone[key] = by_zone.get(key, 0.0) + minutes
        events.append({"line":line,"zone":zone,"minutes":round(minutes,1),"active":False})

    # Currently active no-increment events from state["zones"].
    for key, prior in state.get("zones", {}).items():
        if not prior.get("alerted"):
            continue
        try:
            line, zone = key.split(":", 1)
            idle_since = datetime.fromisoformat(prior["idleSince"])
            if idle_since.tzinfo is None:
                idle_since = idle_since.replace(tzinfo=timezone.utc)
            else:
                idle_since = idle_since.astimezone(timezone.utc)
        except (KeyError, TypeError, ValueError):
            continue

        start = max(idle_since, shift_start)
        end = min(now, shift_end)
        if end <= start:
            continue

        minutes = (end - start).total_seconds() / 60.0
        by_line[line] = by_line.get(line, 0.0) + minutes
        line_zone = f"{line} / {zone}"
        by_zone[line_zone] = by_zone.get(line_zone, 0.0) + minutes
        events.append({"line":line,"zone":zone,"minutes":round(minutes,1),"active":True})

    return {
        "shiftStart": shift_start.isoformat(),
        "asOf": now.isoformat(),
        "eventCount": len(events),
        "totalDowntimeMinutes": round(sum(e["minutes"] for e in events), 1),
        "byLine": [{"line":k,"minutes":round(v,1)} for k,v in sorted(by_line.items(), key=lambda kv:-kv[1])],
        "byZone": [{"lineZone":k,"minutes":round(v,1)} for k,v in sorted(by_zone.items(), key=lambda kv:-kv[1])],
        "events": sorted(events, key=lambda e:-e["minutes"]),
        "note":"Current-shift historian-derived no-increment time detected by this dashboard; not CMMS-validated downtime."
    }


def compile_downtime_summary(days=30):
    """Compile locally detected/recovered downtime events by line and zone."""
    state = load_alert_state()
    cutoff = datetime.now(timezone.utc) - timedelta(days=max(1, int(days)))
    by_line = {}
    by_zone = {}
    events = []
    for event in state.get("downtimeEvents", []):
        try:
            recovered = datetime.fromisoformat(event["recoveredAt"])
            started = datetime.fromisoformat(event["startedAt"])

            # Older alert_state.json files may contain timezone-naive timestamps,
            # while newer events/cutoffs are UTC-aware. Normalize both before
            # comparing so existing saved downtime can still be compiled.
            if recovered.tzinfo is None:
                recovered = recovered.replace(tzinfo=timezone.utc)
            else:
                recovered = recovered.astimezone(timezone.utc)

            if started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            else:
                started = started.astimezone(timezone.utc)

        except (KeyError, TypeError, ValueError):
            continue

        if recovered < cutoff:
            continue
        minutes = float(event.get("detectedDowntimeMinutes") or max(0,(recovered-started).total_seconds()/60))
        line = str(event.get("line","Unknown"))
        zone = str(event.get("zone","Unknown"))
        by_line[line] = by_line.get(line,0.0) + minutes
        key = f"{line} / {zone}"
        by_zone[key] = by_zone.get(key,0.0) + minutes
        events.append(event)
    return {
        "days": int(days),
        "eventCount": len(events),
        "byLine": [{"line":k,"minutes":round(v,1)} for k,v in sorted(by_line.items(), key=lambda kv:-kv[1])],
        "byZone": [{"lineZone":k,"minutes":round(v,1)} for k,v in sorted(by_zone.items(), key=lambda kv:-kv[1])],
        "note":"Historian-derived no-increment events detected by this dashboard; not CMMS-validated downtime."
    }


def save_alert_state(state):
    # Local notification state only; never writes to manufacturing source systems.
    ALERT_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not HISTORICAL_RECORDS_PATH.exists():
        atomic_write_json(HISTORICAL_RECORDS_PATH, {"version":1,"lines":{},"department":{},"generatedAt":None,"scanDays":HISTORY_SCAN_DAYS})
    temp = ALERT_STATE_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")
    temp.replace(ALERT_STATE_PATH)


def send_outlook_email(recipients, subject, body, is_html=False):
    script = r'''
$ErrorActionPreference = 'Stop'
$outlook = New-Object -ComObject Outlook.Application
$mail = $outlook.CreateItem(0)
$mail.To = $env:HEATMAP_MAIL_TO
$mail.Subject = $env:HEATMAP_MAIL_SUBJECT
if ($env:HEATMAP_MAIL_IS_HTML -eq '1') { $mail.HTMLBody = $env:HEATMAP_MAIL_BODY } else { $mail.Body = $env:HEATMAP_MAIL_BODY }
$mail.Send()
'''
    env = os.environ.copy()
    env.update({"HEATMAP_MAIL_TO": ";".join(recipients), "HEATMAP_MAIL_SUBJECT": subject, "HEATMAP_MAIL_BODY": body, "HEATMAP_MAIL_IS_HTML": "1" if is_html else "0"})
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], check=True, capture_output=True, text=True, env=env)


def send_smtp_email(config, recipients, subject, body, is_html=False):
    smtp = config["smtp"]
    message = EmailMessage()
    message["Subject"], message["From"], message["To"] = subject, config.get("fromAddress") or os.getenv("ALERT_FROM_ADDRESS", ""), ", ".join(recipients)
    if is_html:
        message.set_content("This message contains an HTML manufacturing performance table.")
        message.add_alternative(body, subtype="html")
    else:
        message.set_content(body)
    username = os.getenv(smtp.get("usernameEnv", "ALERT_SMTP_USER"), "")
    password = os.getenv(smtp.get("passwordEnv", "ALERT_SMTP_PASSWORD"), "")
    with smtplib.SMTP(smtp["host"], int(smtp.get("port", 587)), timeout=30) as client:
        if smtp.get("startTls", True):
            client.starttls(context=ssl.create_default_context())
        if username:
            client.login(username, password)
        client.send_message(message)


def send_email(config, recipients, subject, body, is_html=False):
    recipients = [str(item).strip() for item in recipients if str(item).strip()]
    if not recipients:
        raise RuntimeError("No recipients configured for alert")
    if config.get("transport", "outlook").lower() == "smtp":
        send_smtp_email(config, recipients, subject, body, is_html)
    else:
        send_outlook_email(recipients, subject, body, is_html)


def performance_alert_due(now, config, state):
    if (now - current_shift_start(now)).total_seconds() / 3600 < float(config.get("performanceStartHourIntoShift", 2)):
        return None
    key = now.replace(minute=0, second=0, microsecond=0).isoformat()
    return None if key in state["performanceSent"] else key


def run_performance_alert(now, config, state):
    key = performance_alert_due(now, config, state)
    if key is None:
        return
    overview = all_lines_shift_overview()
    threshold = float(config.get("performanceThresholdPercent", 95.0))
    goal_rows = [row for row in overview["rows"] if isinstance(row.get("goal"), (int, float)) and row["goal"] > 0]
    total_goal = sum(row["goal"] for row in goal_rows)
    total_projection = sum(row["currentProjection"] if isinstance(row.get("currentProjection"), (int, float)) else 0 for row in goal_rows)
    overall_attainment = total_projection / total_goal * 100 if total_goal else None
    overall_gap = total_projection - total_goal if total_goal else None
    low = sorted([row for row in goal_rows if isinstance(row.get("attainment"), (int, float)) and row["attainment"] < threshold], key=lambda row: (row["attainment"], row["line"]))
    if not low:
        state["performanceSent"][key] = {"sent": False, "reason": "No lines below threshold"}
        save_alert_state(state)
        return
    count = lambda value: f"{round(value):,}" if isinstance(value, (int, float)) else "No data"
    pct = lambda value: f"{value:.1f}%" if isinstance(value, (int, float)) else "No data"
    gap = lambda value: f"{round(value):+,}" if isinstance(value, (int, float)) else "No data"
    rows = "".join(f'''<tr style="background:{'#fff2f2' if row['attainment'] < 90 else '#fff9db'}"><td>{escape(row['line'])}</td><td>{count(row['currentProjection'])}</td><td>{count(row['goal'])}</td><td>{pct(row['attainment'])}</td><td>{gap(row['gap'])}</td></tr>''' for row in low)
    overall_color = "#16a34a" if overall_attainment and overall_attainment >= 98 else "#eab308" if overall_attainment and overall_attainment >= 95 else "#dc2626"
    html = f'''<html><body style="font-family:Segoe UI,Arial"><h2>3GT Manufacturing Shift Projection Alert</h2><p><b>Generated:</b> {now:%Y-%m-%d %I:%M %p}<br><b>Shift:</b> {current_shift_start(now):%I:%M %p} to {(current_shift_start(now)+timedelta(hours=12)):%I:%M %p}<br><b>Threshold:</b> below {threshold:.1f}%</p><table style="border-collapse:collapse;width:100%"><tr><td style="padding:12px;border:1px solid #ccc"><b>Overall Projection</b><br>{count(total_projection)}</td><td style="padding:12px;border:1px solid #ccc"><b>Overall Goal</b><br>{count(total_goal)}</td><td style="padding:12px;border:1px solid #ccc;background:{overall_color};color:white"><b>Overall Attainment</b><br>{pct(overall_attainment)}</td><td style="padding:12px;border:1px solid #ccc"><b>Overall Gap</b><br>{gap(overall_gap)}</td></tr></table><h3>All Lines Below {threshold:.1f}% ({len(low)})</h3><table style="border-collapse:collapse;width:100%"><tr style="background:#1f4e78;color:white"><th>Line</th><th>Projection</th><th>Goal</th><th>Attainment</th><th>Current Rate</th><th>Trend</th><th>Action</th><th>Gap</th></tr>{rows}</table></body></html>'''
    # The 5 PM performance email is intentionally private to the configured MTL/user.
    # All other hourly performance emails continue to use the selected performance group.
    if now.hour == 17:
        # Add the same current-shift downtime calculation exposed on Shift Control.
        try:
            downtime = current_shift_downtime_summary()
            line_rows = "".join(
                f"<tr><td>{html_lib.escape(str(r['line']))}</td><td>{r['minutes']:.1f} min</td></tr>"
                for r in downtime.get("byLine", [])
            ) or "<tr><td colspan='2'>No detected downtime this shift</td></tr>"
            zone_rows = "".join(
                f"<tr><td>{html_lib.escape(str(r['lineZone']))}</td><td>{r['minutes']:.1f} min</td></tr>"
                for r in downtime.get("byZone", [])
            ) or "<tr><td colspan='2'>No detected downtime this shift</td></tr>"
            html += (
                "<h3>This Shift Downtime</h3>"
                f"<p><b>Total detected downtime:</b> {downtime.get('totalDowntimeMinutes',0):.1f} minutes</p>"
                "<table border='1' cellpadding='4' cellspacing='0'><tr><th>Line</th><th>Minutes</th></tr>"
                + line_rows + "</table>"
                "<br><table border='1' cellpadding='4' cellspacing='0'><tr><th>Line / Zone</th><th>Minutes</th></tr>"
                + zone_rows + "</table>"
                "<p><small>Historian-derived no-increment time detected by the dashboard; CMMS remains the validated maintenance record.</small></p>"
            )
        except Exception as exc:
            print(f"[5 PM DOWNTIME] Could not compile current-shift downtime: {exc}")

        five_pm_recipient = str(config.get("fivePmRecipient", "rdees1@its.jnj.com")).strip()
        recipients = [five_pm_recipient] if five_pm_recipient else ["rdees1@its.jnj.com"]
        subject_prefix = "3GT 5 PM Shift Alert"
    else:
        recipients = resolve_recipients(config, "performance")
        subject_prefix = "3GT Shift Alert"

    send_email(
        config,
        recipients,
        f"{subject_prefix}: {len(low)} line(s) below {threshold:.0f}% | Overall {pct(overall_attainment)}",
        html,
        True
    )
    state["performanceSent"][key] = {"sent": True, "lines": [row["line"] for row in low], "overallProjection": total_projection, "overallGoal": total_goal, "overallAttainment": overall_attainment}
    for old_key in sorted(state["performanceSent"])[:-72]:
        state["performanceSent"].pop(old_key, None)
    save_alert_state(state)


def zone_activity(cursor, tag, now, minutes):
    start = now - timedelta(minutes=minutes)
    cursor.execute("""
        SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory
        WHERE TagName = ? AND DateTime >= ? AND DateTime <= ?
          AND wwRetrievalMode = 'Cyclic' AND wwResolution = 60000
        ORDER BY DateTime
    """, tag, start, now)
    samples = [(row[0], None if row[1] is None else float(row[1])) for row in cursor.fetchall()]
    live = query_live(cursor, tag)
    if live and isinstance(live["value"], (int, float)) and (not samples or samples[-1][0] < live["timestamp"]):
        samples.append((live["timestamp"], live["value"]))
    return {"delta": accumulated_counter_delta(samples), "start": start, "end": now}


def run_zone_alerts(now, config, state):
    import pyodbc
    minutes = int(config.get("zoneIdleMinutes", 15))
    if (now - current_shift_start(now)).total_seconds() < minutes * 60:
        return
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for line, tags in ALL_LINE_MAP.items():
            if not line_is_in_production(line):
                continue
            for zone in config.get("zoneKeys", DEFAULT_ALERT_CONFIG["zoneKeys"]):
                tag = tags.get(zone)
                if not tag:
                    continue
                key = f"{line}|{zone}"
                try:
                    activity = zone_activity(cursor, tag, now, minutes)
                except Exception as exc:
                    state["zones"].setdefault(key, {})["lastError"] = str(exc)
                    continue
                delta, prior = activity["delta"], state["zones"].get(key, {})
                if delta is None:
                    state["zones"][key] = {**prior, "line": line, "zone": zone, "tag": tag, "dataAvailable": False, "lastChecked": now.isoformat()}
                    continue
                idle = delta <= 0
                if idle and not prior.get("alerted"):
                    body = f"3GT Heatmap zone inactivity alert\n\nLine: {line}\nZone: {zone}\nTag: {tag}\nProduction in last {minutes} minutes: {delta:,.0f}\nWindow: {activity['start']:%I:%M %p} to {activity['end']:%I:%M %p}"
                    send_email(config, resolve_recipients(config, "zone"), f"3GT Zone Alert: {line} {zone} produced zero lenses for {minutes} minutes", body)
                    state["zones"][key] = {"line": line, "zone": zone, "tag": tag, "alerted": True, "idleSince": activity["start"].isoformat(), "lastChecked": now.isoformat(), "lastDelta": delta}
                elif not idle and prior.get("alerted"):
                    # Preserve the complete recovery/downtime context before clearing the alert.
                    try:
                        idle_since = datetime.fromisoformat(prior["idleSince"])
                        # Alert state may contain either legacy naive or newer aware timestamps.
                        if idle_since.tzinfo is not None and now.tzinfo is None:
                            idle_since = idle_since.replace(tzinfo=None)
                        elif idle_since.tzinfo is None and now.tzinfo is not None:
                            idle_since = idle_since.replace(tzinfo=now.tzinfo)
                    except (KeyError, TypeError, ValueError):
                        idle_since = now - timedelta(minutes=minutes)

                    detected_minutes = max(0.0, (now - idle_since).total_seconds() / 60.0)
                    shift_start = current_shift_start(now)
                    event = {
                        "line": line,
                        "zone": zone,
                        "tag": tag,
                        "startedAt": idle_since.isoformat(),
                        "recoveredAt": now.isoformat(),
                        "detectedDowntimeMinutes": round(detected_minutes, 1),
                        "shiftStart": shift_start.isoformat(),
                        "method": f"no increment for {minutes} minutes"
                    }
                    state.setdefault("downtimeEvents", []).append(event)

                    # Retain up to 90 days of recovered dashboard-derived downtime events.
                    cutoff = now - timedelta(days=90)
                    retained = []
                    for item in state.get("downtimeEvents", []):
                        try:
                            recovered_at = datetime.fromisoformat(item.get("recoveredAt", ""))
                            if recovered_at.tzinfo is not None and cutoff.tzinfo is None:
                                recovered_at = recovered_at.replace(tzinfo=None)
                            elif recovered_at.tzinfo is None and cutoff.tzinfo is not None:
                                recovered_at = recovered_at.replace(tzinfo=cutoff.tzinfo)
                            if recovered_at >= cutoff:
                                retained.append(item)
                        except (TypeError, ValueError):
                            pass
                    state["downtimeEvents"] = retained

                    line_proxy_zone = str(config.get("lineDowntimeZone", "Z6_IN"))
                    try:
                        shift_line_minutes = line_shift_downtime_minutes(
                            state, line, shift_start, line_proxy_zone
                        )
                    except Exception as exc:
                        print(f"[RECOVERY DOWNTIME] {line}: {exc}")
                        shift_line_minutes = 0.0

                    if config.get("sendRecoveryEmails", True):
                        recovery_body = (
                            f"Production resumed.\n\n"
                            f"Line: {line}\n"
                            f"Zone: {zone}\n"
                            f"Tag: {tag}\n"
                            f"Detected stop began: {idle_since:%Y-%m-%d %I:%M %p}\n"
                            f"Recovery detected: {now:%Y-%m-%d %I:%M %p}\n"
                            f"Detected zone downtime: {detected_minutes:.1f} minutes\n"
                            f"Production in latest {minutes} minutes: {delta:,.0f}\n\n"
                            f"Line downtime this shift: {shift_line_minutes:.1f} minutes\n"
                            f"Line downtime proxy: {line_proxy_zone} no-increment events\n"
                            f"Shift: {shift_start:%Y-%m-%d %I:%M %p} to "
                            f"{(shift_start + timedelta(hours=12)):%Y-%m-%d %I:%M %p}\n\n"
                            "Downtime is historian-derived from counter inactivity and "
                            "is not a CMMS-validated event."
                        )
                        send_email(
                            config,
                            resolve_recipients(config, "zone"),
                            f"3GT Zone Recovery: {line} {zone} production resumed",
                            recovery_body
                        )

                    state["zones"][key] = {
                        "line": line, "zone": zone, "tag": tag, "alerted": False,
                        "recovered": now.isoformat(), "lastChecked": now.isoformat(),
                        "lastDelta": delta
                    }
                else:
                    state["zones"][key] = {**prior, "line": line, "zone": zone, "tag": tag, "alerted": bool(prior.get("alerted") and idle), "lastChecked": now.isoformat(), "lastDelta": delta}
    save_alert_state(state)


def alert_engine():
    state = load_alert_state()
    while True:
        config = load_alert_config()
        now = datetime.now()
        if config.get("enabled", False) and CONFIG.get("provider") == "aveva-sql":
            try:
                run_performance_alert(now, config, state)
                last = state.get("lastZoneCheck")
                if not last or now - datetime.fromisoformat(last) >= timedelta(minutes=int(config.get("zoneCheckMinutes", 5))):
                    run_zone_alerts(now, config, state)
                    state["lastZoneCheck"] = now.isoformat()
                state["lastRun"], state["lastError"] = now.isoformat(), None
            except Exception as exc:
                traceback.print_exc()
                state["lastRun"], state["lastError"] = now.isoformat(), f"{type(exc).__name__}: {exc}"
            save_alert_state(state)
        time.sleep(60)


INDEX_HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>3GT Hourly Heatmap</title>
<style>
:root{--bg:#101318;--panel:#171c24;--head:#303030;--grid:#3b424c;--text:#eee;--muted:#aeb5bf;--green:#04e51b;--yellow:#fff000;--red:#ff1212;--nodata:#4a586d;--period:#202a38}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;background:var(--bg);color:var(--text);font-family:Segoe UI,Arial,sans-serif}body{display:flex;flex-direction:column;overflow:hidden}header{height:112px;flex:0 0 112px;background:#262626;padding:10px 12px}h1{font-size:20px;margin:0}.controls{display:flex;gap:14px;align-items:center;margin-top:8px}.nav{display:flex;gap:6px;margin-top:8px}.nav button{padding:6px 14px;background:#1b2430}.nav button.active{background:#1d5f99;border-color:#7dd3fc}.page{display:none;flex:1;min-height:0;padding:8px;overflow:hidden}.page.active{display:flex}.page-grid{width:100%;min-height:0;display:grid;gap:8px}.ops-grid{grid-template-rows:minmax(170px,24vh) minmax(280px,1fr) minmax(145px,20vh) minmax(135px,18vh)}.trends-grid{grid-template-rows:auto 1fr}.history-grid{grid-template-columns:minmax(0,1fr) 360px}.control-page{overflow:auto;align-items:flex-start}.meta{font-size:12px;color:var(--muted)}select{background:#162238;color:white;border:1px solid #64748b;padding:6px 10px}.wrap{flex:1;min-height:0;padding:8px;display:grid;grid-template-rows:minmax(170px,24vh) minmax(280px,1fr) minmax(145px,20vh) minmax(135px,18vh);gap:8px;overflow:hidden}.panel{min-height:0;display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--grid);background:var(--panel)}.panel-title{height:34px;flex:0 0 34px;padding:7px 8px;font-size:16px;font-weight:600;border-bottom:1px solid var(--grid)}.scroll{flex:1;min-height:0;overflow:auto}#main-content{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:8px}table{border-collapse:collapse;width:100%;table-layout:fixed}th,td{border:1px solid var(--grid);padding:5px;text-align:right;white-space:nowrap}thead th{position:sticky;top:0;background:var(--head);z-index:5}.left,.period{text-align:left}.period{background:var(--period);font-weight:600}.green{background:var(--green);color:#102010}.yellow,.count{background:var(--yellow);color:#222}.red{background:var(--red);color:white}.nodata{background:var(--nodata)}#overview{min-width:900px}#heatmap{width:100%;table-layout:fixed}#heatmap th,#heatmap td{font-size:10px;padding:1px 2px;overflow:hidden;text-overflow:ellipsis}#heatmap th:first-child,#heatmap td:first-child{width:128px}#zoneAlerts{min-width:980px}.zone-alert-row{background:#4c1515;color:#fff}.zone-alert-line{font-weight:700;color:#7dd3fc;cursor:pointer;text-align:left}.overview-line{color:#7dd3fc;font-weight:700;cursor:pointer;text-align:left}.overview-selected{outline:2px solid #6ee7ff;outline-offset:-2px}.gap-positive{color:#86efac}.gap-negative{color:#fca5a5}.summary-sub{display:block;font-size:10px;opacity:.75;margin-top:2px}#summary th:first-child,#summary td:first-child{width:62%}#reviewTriggers{min-width:1100px}.tier1{background:#fef3c7;color:#111}.tier2{background:#fed7aa;color:#111}.tier3{background:#fecaca;color:#111;font-weight:700}.empty{text-align:center;padding:18px;color:var(--muted)}
.trend-card{margin:6px;border:1px solid var(--grid);background:#1b2430;padding:8px}.trend-top{display:flex;justify-content:space-between}.trend-name{font-weight:700}.trend-value{font-size:18px;font-weight:700}.trend-improving{color:#63e692}.trend-declining{color:#ff7777}.trend-stable{color:#ffe26c}.trend-msg{font-size:10px;color:var(--muted);margin-top:4px}.action-badge{display:inline-block;padding:3px 8px;border-radius:12px;font-weight:800;font-size:11px}.action-INTERVENE{background:#b91c1c;color:white}.action-INVESTIGATE{background:#d97706;color:white}.action-RECOVERING{background:#075985;color:white}.action-STABILIZE{background:#475569;color:white}.action-HEALTHY{background:#166534;color:white}.action-NO_DATA{background:#444;color:#ddd}.decision-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;padding:8px}.decision-box{border:1px solid var(--grid);padding:10px;background:#18212d}.decision-box b{display:block;font-size:20px;margin-top:5px}@media(max-width:900px){.decision-grid{grid-template-columns:1fr 1fr}}.spark{display:flex;height:26px;gap:3px;align-items:flex-end;margin-top:5px}.spark i{display:block;flex:1;background:#6b8199}.modal{display:none;position:absolute;inset:90px 12px 12px;background:#101720;border:1px solid #718096;z-index:20;overflow:auto;padding:14px}.modal.open{display:block}.modal-head{display:flex;justify-content:space-between}.settings-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.settings-card{border:1px solid var(--grid);background:var(--panel);padding:12px}.person{display:grid;grid-template-columns:24px 1fr 1.5fr 90px 90px;gap:6px;align-items:center;margin:4px 0}.target-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.target-grid input{width:100%}button,input{background:#162238;color:white;border:1px solid #64748b;padding:6px 9px}button{cursor:pointer}.primary{background:#1d5f99}@media(max-width:1000px){.settings-grid{grid-template-columns:1fr}}.chart-wrap{padding:10px;min-height:260px}.trend-svg{width:100%;height:280px;background:#121923;border:1px solid var(--grid)}.chart-legend{display:flex;gap:18px;font-size:12px;color:var(--muted);padding:4px 0}.action-layout{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:8px;min-height:0}.action-form{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:10px}.action-form label{font-size:12px;color:var(--muted)}.action-form input,.action-form select,.action-form textarea{width:100%;margin-top:3px}.action-form textarea{min-height:64px;resize:vertical}.action-form .wide{grid-column:1/-1}.action-row{padding:8px;border-bottom:1px solid var(--grid)}.action-row b{color:#7dd3fc}.effect-good{color:#86efac}.effect-watch{color:#fde68a}.effect-bad{color:#fca5a5}.event-timeline{padding:8px}.event-row{display:grid;grid-template-columns:90px 150px 70px 1fr;gap:8px;padding:7px;border-bottom:1px solid var(--grid)}.event-alarm{color:#fbbf24}.event-access{color:#c084fc}.event-action{color:#7dd3fc}.story{padding:12px;line-height:1.45}@media(max-width:800px){.event-row{grid-template-columns:80px 1fr}.event-row .zone{display:none}}
.line-grid{grid-template-rows:auto minmax(360px,1fr) auto minmax(190px,28vh);overflow:auto}.line-summary{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;padding:8px}.line-kpi{background:#18212d;border:1px solid var(--grid);padding:10px}.line-kpi span{display:block;color:var(--muted);font-size:11px}.line-kpi b{display:block;font-size:18px;margin-top:4px}.schematic-wrap{padding:12px;overflow:auto}.line-schematic{min-width:1050px;display:grid;grid-template-columns:repeat(12,minmax(70px,1fr));grid-template-rows:112px 64px 132px;gap:8px;align-items:stretch}.zone-card{border:2px solid #516071;background:#202936;padding:8px;position:relative;cursor:pointer;overflow:hidden;min-width:0}.zone-card:hover{outline:2px solid #7dd3fc}.zone-card.selected{outline:3px solid #6ee7ff}.zone-card .zone-name{font-weight:800;font-size:13px}.zone-card .zone-desc{font-size:10px;color:#cbd5e1;margin-top:2px}.zone-card .zone-rate{font-size:21px;font-weight:900;margin-top:7px}.zone-card .zone-state{font-size:11px;font-weight:800;margin-top:2px}.zone-card .zone-trend{position:absolute;right:7px;top:7px;font-weight:900}.zone-healthy{background:#123c2a;border-color:#36c275}.zone-watch{background:#4a4312;border-color:#e6c84a}.zone-under{background:#5a3015;border-color:#e99037}.zone-critical{background:#571b22;border-color:#ee5361}.zone-down{background:#7f111d;border-color:#ff6675;box-shadow:inset 0 0 0 2px #31070c}.zone-recover{background:#123b55;border-color:#45b8ef}.zone-unknown{background:#252b34;border-color:#566271;color:#aeb5bf}.flow-arrow{display:flex;align-items:center;justify-content:center;font-size:28px;color:#7c8ca0}.line-details{display:grid;grid-template-columns:minmax(0,1fr) 420px;gap:8px;min-height:0}.zone-detail{padding:12px;line-height:1.45}.zone-detail h3{margin:0 0 8px}.zone-detail-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0}.zone-detail-grid div{border:1px solid var(--grid);background:#18212d;padding:8px}.zone-detail-grid span{display:block;font-size:10px;color:var(--muted)}.line-event-list{padding:6px}.line-event{padding:7px;border-bottom:1px solid var(--grid);font-size:12px}.legend-row{display:flex;gap:12px;flex-wrap:wrap;padding:0 12px 10px;font-size:11px;color:var(--muted)}.legend-dot{display:inline-block;width:10px;height:10px;margin-right:4px;border:1px solid #aaa}.line-flow-note{font-size:12px;color:var(--muted);padding:0 12px 10px}@media(max-width:1000px){.line-summary{grid-template-columns:1fr 1fr}.line-details{grid-template-columns:1fr}.zone-detail-grid{grid-template-columns:1fr 1fr}}

.zone-analysis{display:grid;grid-template-columns:minmax(0,2fr) minmax(300px,1fr);gap:8px;min-height:330px}.zone-chart-panel{padding:10px;min-width:0}.zone-analysis-svg{width:100%;height:300px;background:#0d1621;border:1px solid var(--grid)}.zone-analysis-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:6px}.zone-analysis-head h3{margin:0;font-size:15px}.zone-analysis-legend{display:flex;gap:14px;flex-wrap:wrap;font-size:11px;color:var(--muted);margin:5px 0}.zone-insight{padding:12px}.zone-insight h3{margin:0 0 10px}.insight-row{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--grid)}.insight-row strong{text-align:right}.assessment-box{margin-top:12px;border:1px solid var(--grid);background:#18212d;padding:10px;line-height:1.4}.prop-good{color:#63e692}.prop-watch{color:#ffe26c}.prop-bad{color:#ff7777}@media(max-width:1000px){.zone-analysis{grid-template-columns:1fr}}

/* v10.3 Line Story visual redesign */
.line-grid{display:block!important;overflow:auto!important;padding-bottom:12px}.line-hero{display:grid;grid-template-columns:190px 230px repeat(5,minmax(135px,1fr));border:1px solid #334155;background:#07111c;border-radius:8px;margin-bottom:8px;min-width:1200px}.hero-cell{padding:12px 14px;border-right:1px solid #263546;min-height:78px}.hero-cell:last-child{border-right:0}.hero-label{display:block;color:#cbd5e1;font-size:11px;margin-bottom:8px}.hero-value{display:block;font-size:20px;font-weight:800}.hero-sub{font-size:10px;color:#94a3b8;margin-top:3px}.hero-bad{color:#ff3b30}.hero-good{color:#35d36f}.hero-warn{color:#ffb020}.line-process-panel{border:1px solid #334155;background:#08131f;border-radius:8px;margin-bottom:8px;overflow:hidden}.line-process-head{display:flex;justify-content:space-between;align-items:center;padding:9px 12px;border-bottom:1px solid #334155;gap:12px;flex-wrap:wrap}.line-process-head strong{font-size:16px}.process-legend{display:flex;gap:12px;flex-wrap:wrap;font-size:10px;color:#cbd5e1}.process-legend i{width:18px;height:10px;display:inline-block;margin-right:4px;border-radius:2px;vertical-align:-1px}.schematic-wrap{padding:16px 28px 20px;overflow:auto}.line-schematic{min-width:1080px;display:flex!important;align-items:center;justify-content:space-between;gap:0;height:180px}.zone-card{width:128px;min-width:128px;height:98px;border-radius:6px;padding:9px 7px;text-align:center;display:flex;flex-direction:column;justify-content:center;position:relative}.zone-card .zone-name{font-size:16px}.zone-card .zone-desc{font-size:10px}.zone-card .zone-rate{font-size:20px;margin-top:3px}.zone-card .zone-state{font-size:9px}.flow-link{height:2px;background:#d6dde6;flex:1;min-width:24px;position:relative;margin:0 7px}.flow-link:after{content:'›';position:absolute;right:-5px;top:-16px;color:#e8edf3;font-size:28px}.line-analysis-layout{display:grid;grid-template-columns:minmax(0,2.1fr) 300px 390px;gap:8px;margin-bottom:8px;min-width:1180px}.line-analysis-layout .panel,.line-bottom-grid .panel{border-radius:8px}.zone-chart-panel{padding:12px}.zone-analysis-svg{height:320px}.zone-status-card,.prop-card{padding:12px}.metric-row{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid #334155}.metric-row:last-child{border-bottom:0}.metric-row b{font-size:14px}.recommend{color:#ffb020;font-weight:900}.line-bottom-grid{display:grid;grid-template-columns:1fr 1.35fr 1.1fr;gap:8px;min-width:1180px}.mini-table{width:100%;font-size:11px}.mini-table th,.mini-table td{text-align:left;padding:8px;border-color:#263546}.mini-table th{position:static;background:#111d29}.event-type{display:inline-block;padding:3px 8px;border-radius:10px;font-size:9px;font-weight:800;background:#6b1b14}.line-story-caption{font-size:11px;color:#aeb5bf;padding:4px 2px 10px}.zone-detail{padding:0}.zone-detail-grid{grid-template-columns:1fr 1fr!important}.zone-detail-grid div{background:transparent;border:0;border-bottom:1px solid #334155;padding:9px 0}.line-flow-note,.line-summary{display:none}
.compliance-banner{height:34px;flex:0 0 34px;background:#123b2a;border-bottom:1px solid #35d36f;color:#eafff0;display:flex;align-items:center;gap:22px;padding:0 14px;font-size:11px;letter-spacing:.3px}.compliance-banner b{font-size:13px}.compliance-banner span:before{content:"✓ ";color:#63e692}header h1 small{font-size:10px;color:#94a3b8;font-weight:500}.boundary-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;padding:12px}.boundary-card{background:#101c29;border:1px solid #334155;border-radius:8px;padding:14px}.boundary-card b{display:block;font-size:17px;color:#63e692;margin:6px 0}.boundary-card .no{color:#ff7777}.compliance-body{padding:16px;overflow:auto}.compliance-statement{font-size:18px;line-height:1.55;background:#0d1b27;border:1px solid #35d36f;border-radius:8px;padding:18px;margin-bottom:12px}.read-only-chip{display:inline-block;padding:4px 9px;border-radius:12px;background:#123b2a;border:1px solid #35d36f;color:#9ff0b9;font-size:10px;font-weight:800;margin-right:5px}@media(max-width:900px){.compliance-banner{height:auto;flex-wrap:wrap;padding:6px 10px}.boundary-grid{grid-template-columns:1fr 1fr}}
</style></head><body>
<div class="compliance-banner"><b>READ-ONLY VISUALIZATION</b><span>NO MACHINE CONTROL</span><span>NO SOURCE DATA MODIFICATION</span><span>NO PRODUCT DISPOSITION</span><span>NOT A SYSTEM OF RECORD</span></div><header><h1>3GT TAM Operations Dashboard <small>v13.6</small></h1><div class="controls"><label>Line <select id="line"></select></label><span id="meta" class="meta">Loading...</span><span id="alert-meta" class="meta">Alerts loading...</span><span id="trend-pill" class="meta">Trend loading...</span></div><nav class="nav"><button data-page="operations" class="active">Operations</button><button data-page="lineview">Line Story</button><button data-page="trends">Trends</button><button data-page="history">Shift History</button><button data-page="shiftcontrol">Shift Control</button><button data-page="controls">System / Boundary</button><button data-page="compliance">Compliance</button></nav></header>
<div id="page-operations" class="page active"><div class="page-grid ops-grid">
<section class="panel"><div class="panel-title">All Lines Loader Shift Performance <span id="overview-meta" class="meta"></span></div><div class="scroll"><table id="overview"></table></div></section>
<section id="main-content"><div class="panel"><div class="panel-title">Selected Line Hourly Performance</div><div class="scroll"><table id="heatmap"></table></div></div><aside class="panel"><div class="panel-title">Shift Performance Summary</div><div class="scroll"><table id="summary"></table></div></aside></section>
<section class="panel"><div class="panel-title">Management Review Triggers <span class="meta">Tier 1: 2-4 red shifts | Tier 2: 5-7 | Tier 3: 8+</span></div><div class="scroll"><table id="reviewTriggers"></table></div></section>
<section class="panel"><div class="panel-title">Active Zone Alerts <span id="zone-alert-meta" class="meta">Loading...</span></div><div class="scroll"><table id="zoneAlerts"></table></div></section>
</div></div>
<div id="page-lineview" class="page"><div class="line-grid" style="width:100%">
<div id="lineHero" class="line-hero"></div>
<section class="line-process-panel"><div class="line-process-head"><div><strong><span id="lineStoryTitle"></span> — Process Line Overview</strong> <span class="meta">Click any zone to analyze trends vs Loader Out (Z6)</span></div><div class="process-legend"><span><i class="zone-healthy"></i>Healthy (≥98%)</span><span><i class="zone-watch"></i>Watch (90-98%)</span><span><i class="zone-under"></i>Underperf. (70-90%)</span><span><i class="zone-critical"></i>Critical (&lt;70%)</span><span><i class="zone-down"></i>Down (Alarm)</span><span><i class="zone-recover"></i>Recovering</span></div></div><div class="schematic-wrap"><div id="lineSchematic" class="line-schematic"></div><div id="lineFlowNote" class="line-flow-note"></div></div></section>
<div class="line-analysis-layout"><section class="panel"><div class="panel-title">Zone Analysis: <span id="zoneAnalysisPanelTitle">Select a zone</span></div><div class="zone-chart-panel"><div class="zone-analysis-head"><h3 id="zoneAnalysisTitle">Select a monitored zone</h3><span id="zoneAnalysisStatus" class="meta"></span></div><div class="zone-analysis-legend"><span>● Selected Zone Actual %</span><span>┄ Selected Zone Target %</span><span>■ Loader Out Actual %</span><span>┄ Loader Out Target %</span></div><svg id="zoneAnalysisChart" class="zone-analysis-svg" viewBox="0 0 900 300"></svg><div id="zoneChartCaption" class="line-story-caption"></div></div></section><section class="panel"><div class="panel-title">Selected Zone</div><div id="zoneDetail" class="zone-status-card"></div></section><section class="panel"><div class="panel-title">Loader Out (Z6) & Downstream Impact</div><div id="zoneInsight" class="prop-card"></div></section></div>
<div class="line-bottom-grid"><section class="panel"><div class="panel-title">Active Alarms for Selected Zone</div><div id="activeZoneAlarmTable"></div></section><section class="panel"><div class="panel-title">Recent Alarms (Last 4 Hours)</div><div id="recentAlarmTable"></div></section><section class="panel"><div class="panel-title">Interventions / Actions (Not Recorded by MOI)</div><div id="recentInterventionTable"></div></section></div>
<div id="lineSummary"></div><div id="lineStoryMeta" style="display:none"></div><div id="lineEvents" style="display:none"></div>
</div></div>
<div id="page-trends" class="page"><div class="page-grid trends-grid"><section class="panel"><div class="panel-title">Operational Intelligence — <span id="actionBadge"></span></div><div id="decisionGrid" class="decision-grid"></div></section><section class="panel"><div class="panel-title">Hourly Output vs Target <span class="meta">Read-only production trend with source alarm context</span></div><div class="scroll chart-wrap"><div class="chart-legend">● Actual loader output &nbsp; ─ Target &nbsp; ⚠ Alarm &nbsp; ◇ Operator access</div><svg id="trendChart" class="trend-svg" viewBox="0 0 900 280" role="img" aria-label="Hourly output trend"></svg><div id="trendRecommendation" class="trend-card"></div></div></section><section class="panel"><div class="panel-title">Shift Story <span class="meta">Production + source alarm context</span></div><div id="shiftStory" class="story"></div></section><section class="panel"><div class="panel-title">Event Timeline</div><div id="eventTimeline" class="event-timeline"></div></section></div></div>
<div id="page-history" class="page"><div class="page-grid history-grid"><section class="panel"><div class="panel-title">Shift History — Last 30 Days (60 Completed Shifts)</div><div style="padding:12px;flex:1;min-height:0"><svg id="historyChart" viewBox="0 0 1000 430" style="width:100%;height:100%;min-height:360px;background:#0b1724;border:1px solid #334155"></svg></div></section><section class="panel"><div class="panel-title">Selected Line Summary</div><div id="historySummary" style="padding:12px"></div><div class="panel-title">Historical Records</div><div class="settings-card" style="margin-bottom:12px"><b>Historical Intelligence</b> <button class="primary" id="rebuildHistoryOnHistory">Build / Rebuild History</button> <span id="historyBuildMsgOnHistory" class="meta"></span><div class="meta">Read-only historian scan; rebuilds only the dashboard's local derived history snapshot.</div></div><div id="historyRecords" style="padding:12px"></div></section></div></div>
<div id="page-shiftcontrol" class="page control-page"><div style="width:100%"><div class="settings-grid"><div class="settings-card"><h3>Email Notifications</h3><div class="compliance-statement" style="margin:0 0 12px"><b>COMMUNICATION SETTINGS ONLY</b><br>These controls manage dashboard-generated informational email. They do not modify manufacturing equipment, historian/alarm data, product status, or authoritative records.</div><label style="display:flex;align-items:center;gap:10px;font-weight:700"><input type="checkbox" id="emailMasterEnabled" style="width:20px;height:20px"> Enable automatic emails</label><p id="emailControlState" class="meta">Loading email status...</p><p class="meta"><b>Startup safety:</b> automatic emails are reset to OFF every time the dashboard starts. Enable only after confirming the dashboard is operating correctly.</p><button class="primary" id="saveEmailControl">Save email control</button> <span id="emailControlMsg" class="meta"></span></div><div class="settings-card"><h3>Distribution Lists</h3><label>Hourly performance list <select id="performanceGroup"></select></label> <label>Zone-alert list <select id="zoneGroup"></select></label><div style="margin:12px 0"><input id="newGroupName" placeholder="New distribution list name"><button id="addGroup">Create list</button> <button id="deleteGroup">Delete selected list</button></div><div id="people"></div><p class="meta">Enabled controls whether a person can receive dashboard email. Perf/Zone controls membership in the selected lists.</p><input id="newName" placeholder="Name"><input id="newEmail" placeholder="email@company.com"><button id="addPerson">Add</button><br><br><button class="primary" id="saveRecipients">Save recipients</button> <span id="recipientMsg" class="meta"></span></div><div class="settings-card" style="grid-column:1/-1"><h3>Line Production Status</h3><div class="compliance-statement" style="margin:0 0 12px"><b>DASHBOARD SCOPE / ALERTING ONLY</b><br>Mark a line Out of Production to exclude it from floor performance totals, performance-alert emails, zone inactivity alerts, and Management Review Triggers. This does not modify the machine, historian, schedule, MES, or any source system.</div><div id="lineStatusGrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px"></div><p class="meta">Out-of-production lines remain available in the line selector for historical/reference viewing, but they are excluded from current floor calculations and alerts.</p><button class="primary" id="saveLineStatus">Save production status</button> <span id="lineStatusMsg" class="meta"></span></div><div class="settings-card" style="grid-column:1/-1"><h3>Dashboard Performance Targets</h3><div class="compliance-statement" style="margin:0 0 12px"><b>VISUALIZATION REFERENCE VALUES ONLY</b><br>These targets control dashboard colors, attainment calculations, trends and projections only. Saving them does not modify PLC setpoints, recipes, machine parameters, historian data, alarm data, product status, or any manufacturing-control system.</div><label>Line <select id="targetLine"></select></label><div id="targetGrid" class="target-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:10px;margin-top:12px"></div><p class="meta"><b>Output targets</b> are lenses/hour. <b>Yield targets</b> are percentages. Shift Goal is lenses/shift.</p><button class="primary" id="saveTargets">Save dashboard targets</button> <span id="targetMsg" class="meta"></span></div><div class="settings-card" style="grid-column:1/-1"><h3>Downtime Intelligence</h3><div class="compliance-statement" style="margin:0 0 12px"><b>LOCAL DERIVED DOWNTIME SUMMARY</b><br>Compiles historian-derived no-increment events detected by this dashboard by line and zone. This does not modify historian data and does not replace CMMS as the validated downtime/repair record.</div><button class="primary" id="currentShiftDowntime">This Shift Downtime</button> <label style="margin-left:12px">History Window <select id="downtimeDays"><option value="7">7 days</option><option value="30" selected>30 days</option><option value="90">90 days</option></select></label> <button class="primary" id="compileDowntime">Compile Historical Downtime</button> <span id="downtimeMsg" class="meta"></span><div id="downtimeResults" style="margin-top:12px"></div></div><div class="settings-card" style="grid-column:1/-1"><h3>Historical Intelligence</h3><div class="compliance-statement" style="margin:0 0 12px"><b>READ-ONLY SOURCE QUERY / LOCAL DERIVED CACHE</b><br>Builds a local derived history snapshot from read-only historian queries for records and last-known-green context. It does not write to or modify the historian, equipment, alarms, CMMS, or product records.</div><button class="primary" id="rebuildHistory">Build / Rebuild History</button> <span id="historyBuildMsg" class="meta"></span><p id="historyBuildState" class="meta">No rebuild running</p></div></div></div></div>
<div id="page-controls" class="page control-page"><div style="width:100%"><section class="panel"><div class="panel-title">System Boundary — Visualization-Only Mode</div><div class="boundary-grid"><div class="boundary-card">Production Sources<b>READ ONLY</b><div class="meta">Wonderware / future Canary / Ignition adapters are query-only.</div></div><div class="boundary-card">Alarm Sources<b>READ ONLY</b><div class="meta">Alarm events may be displayed; this application does not acknowledge, suppress, edit, or delete them.</div></div><div class="boundary-card">Machine Control<b class="no">NONE</b><div class="meta">No PLC, HMI, robot, drive, recipe, setpoint, or control-loop commands exist.</div></div><div class="boundary-card">Regulated Records<b class="no">NOT CREATED</b><div class="meta">The dashboard is not the authoritative production, quality, maintenance, CAPA, or disposition record.</div></div></div><div id="systemHealthReadOnly" class="compliance-body meta">Loading source health...</div></section></div></div>
<div id="page-compliance" class="page control-page"><div style="width:100%"><section class="panel"><div class="panel-title">Visualization-Only Intended Use</div><div class="compliance-body"><div class="compliance-statement"><b>Manufacturing Operations Intelligence is a read-only visualization and decision-support layer.</b><br>It retrieves information from approved source systems and presents that information in a more understandable form. It does not control manufacturing equipment, modify source-system data, perform product disposition, or replace authoritative regulated records.</div><span class="read-only-chip">READ ONLY</span><span class="read-only-chip">NO WRITE-BACK</span><span class="read-only-chip">NO CONTROL OUTPUTS</span><span class="read-only-chip">NO PRODUCT DISPOSITION</span><span class="read-only-chip">NOT SYSTEM OF RECORD</span><div class="boundary-grid" style="padding-left:0;padding-right:0"><div class="boundary-card"><b>What it does</b><div>Visualizes production and alarm information, calculates transient trends/projections, and helps users understand current line behavior.</div></div><div class="boundary-card"><b class="no">What it never does</b><div>Change equipment, recipes, parameters, alarms, historian values, product status, or approved source records.</div></div><div class="boundary-card"><b>Failure behavior</b><div>If the dashboard is unavailable, manufacturing control and authoritative source systems continue independently.</div></div><div class="boundary-card"><b>Data integrity</b><div>Unavailable, stale, or unmapped data must be identified as such rather than represented as zero or silently replaced with synthetic values.</div></div></div><p class="meta">Regulatory classification and the extent of software-assurance activities remain subject to the site's approved Quality Management System and intended-use determination. This page documents the application's technical boundary; it does not itself waive applicable requirements.</p></div></section></div></div>

<script>
const cols=[['PERIOD','Period','period'],['Z1','Z1','count'],['Z2A_YIELD','Z2A Yield','yield'],['Z2A','Z2A','count'],['Z3_IN','Z3 In','count'],['Z3_YIELD','Z3 Yield','yield'],['Z3_OUT','Z3 Out','count'],['Z4_YIELD','Z4 Yield','yield'],['Z4_OUT','Z4 Out','count'],['Z5_YIELD','Z5 Yield','yield'],['Z5_IN','Z5 In','count'],['ALI_IN','ALI In','count'],['ALI_YIELD','ALI Yield','yield'],['ALI_OUT','ALI Out','count'],['Z6_YIELD','Z6 Yield','yield'],['Z6_IN','Z6 In','count'],['LINE_YIELD','Line Yield','yield']];
let targets={},hourlyTargets={};
function fmt(v,type='count'){if(v==null)return'No data';return type==='yield'?Number(v).toFixed(2)+'%':Math.round(v).toLocaleString()}
function attainmentClass(v){if(v==null||!Number.isFinite(Number(v)))return'nodata';if(Number(v)>98)return'green';if(Number(v)>=95)return'yellow';return'red'}
function classStyle(c){if(c==='green')return'background:#04e51b;color:#102010';if(c==='yellow')return'background:#fff000;color:#222';if(c==='red')return'background:#ff1212;color:#fff';if(c==='nodata')return'background:#4a586d;color:#fff';return'background:#fff000;color:#222'}
function effectiveTarget(k,p){const n=Number(hourlyTargets[k]);if(!Number.isFinite(n)||n<=0)return null;if(!p.isLiveHour)return n;return n*Math.min(Math.max((new Date(p.end)-new Date(p.start))/3600000,0),1)}
function cellClass(k,v,p,type){if(v==null)return'nodata';if(type==='yield'){const t=targets[k]??98;return v>=t?'green':v>=t-3?'yellow':'red'}const t=effectiveTarget(k,p);return t==null?'count':attainmentClass(v/t*100)}
function escapeAttr(value){return String(value??'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function cellTip(k,v,p,type){if(v==null)return'No data';if(type==='yield'){const target=Number(targets[k]??98);return `Yield: ${fmt(v,type)} | Target: ${target.toFixed(1)}%`}const target=effectiveTarget(k,p);if(target==null||target<=0)return `Actual: ${fmt(v)} | Target not set`;const attainment=Number(v)/target*100;return `Actual: ${fmt(v)} | Target: ${Math.round(target).toLocaleString()} | Attainment: ${attainment.toFixed(1)}%`}
function gapText(v){if(v==null)return'No data';const n=Math.round(v);return`${n>0?'+':''}${n.toLocaleString()}`}
async function getJson(url){const r=await fetch(url,{cache:'no-store'});const d=await r.json();if(!r.ok||d.error)throw new Error(d.error||'Request failed');return d}
function setHtml(id,html){const el=document.getElementById(id);if(el)el.innerHTML=html}
function renderTrend(d){const t=d.trend||{};const dir=t.direction||'unknown';const cls=dir==='improving'?'trend-improving':dir==='declining'?'trend-declining':'trend-stable';const arrow=dir==='improving'?'▲':dir==='declining'?'▼':'→';const change=t.changePercent==null?'':`${t.changePercent>=0?'+':''}${Number(t.changePercent).toFixed(1)}%`;const a=d.actionStatus||{code:'NO_DATA',label:'NO DATA',message:''};setHtml('trend-pill',`${d.selectedLine}: <span class="action-badge action-${a.code}">${a.label}</span>`);setHtml('actionBadge',`<span class="action-badge action-${a.code}">${a.label}</span>`);setHtml('decisionGrid',`<div class="decision-box"><span class="meta">Projected attainment</span><b>${d.projectedAttainment==null?'—':Number(d.projectedAttainment).toFixed(1)+'%'}</b></div><div class="decision-box"><span class="meta">Current 3-hr rate</span><b>${t.targetAttainmentPercent==null?'—':Number(t.targetAttainmentPercent).toFixed(1)+'%'}</b></div><div class="decision-box"><span class="meta">3-hr trend</span><b class="${cls}">${change||'—'}</b></div><div class="decision-box"><span class="meta">Operational state</span><b><span class="action-badge action-${a.code}">${a.label}</span></b></div>`);const rec=document.getElementById('trendRecommendation');if(rec)rec.innerHTML=`<b>${arrow} ${t.status||'No trend'} ${change}</b><div>${a.message||t.message||''}</div>`;}
async function loadOverview(){const d=await getJson('/api/overview');let h='<thead><tr><th>Line</th><th>Last Shift</th><th>Current Projection</th><th>Goal</th><th>Attainment</th><th>Current Rate</th><th>Trend</th><th>Action</th><th>Gap</th></tr></thead><tbody>';for(const r of d.rows){const c=attainmentClass(r.attainment);const lc=attainmentClass(r.lastShift!=null&&Number(r.goal)>0?r.lastShift/r.goal*100:null);const selected=r.line===document.getElementById('line').value?' overview-selected':'';h+=`<tr class="${selected}"><td class="overview-line" onclick="selectLine('${r.line}')">${r.line}</td><td style="${classStyle(lc)}">${fmt(r.lastShift)}</td><td style="${classStyle(c)}">${fmt(r.currentProjection)}</td><td>${fmt(r.goal)}</td><td style="${classStyle(c)}">${r.attainment==null?'No goal':Number(r.attainment).toFixed(1)+'%'}</td><td>${r.currentRateAttainment==null?'—':Number(r.currentRateAttainment).toFixed(1)+'%'}</td><td>${r.trendChange==null?'—':(r.trendChange>=5?'▲ ':r.trendChange<=-5?'▼ ':'→ ')+(r.trendChange>=0?'+':'')+Number(r.trendChange).toFixed(1)+'%'}</td><td>${r.action?`<span class="action-badge action-${r.action.code}">${r.action.label}</span>`:'—'}</td><td class="${r.gap!=null&&r.gap>=0?'gap-positive':'gap-negative'}">${gapText(r.gap)}</td></tr>`}document.getElementById('overview').innerHTML=h+'</tbody>';document.getElementById('overview-meta').textContent=`Updated ${new Date(d.generatedAt).toLocaleTimeString()} | lowest attainment first`}
async function load(){const sel=document.getElementById('line');const selected=sel.value||'TAM01';const d=await getJson('/api/data?line='+encodeURIComponent(selected));if(!sel.options.length){(d.availableLines||[]).forEach(x=>sel.add(new Option(x,x)));sel.value=d.selectedLine||selected}else if(d.selectedLine&&sel.value!==d.selectedLine){sel.value=d.selectedLine}targets=d.targets||{};hourlyTargets=d.hourlyTargets||{};lastData=d;renderTrend(d);refreshTrendPage().catch(()=>{});document.getElementById('meta').textContent=`${d.provider} | ${d.historyHours} completed hours + current hour | missing ${d.missingTags.length}`;let h='<thead><tr>'+cols.map(x=>`<th>${x[1]}</th>`).join('')+'</tr></thead><tbody>';for(const p of d.periods){h+='<tr>';for(const [k,label,type] of cols){if(type==='period'){h+=`<td class="period">${p.label}</td>`;continue}const v=p.columns[k],c=cellClass(k,v,p,type),tip=cellTip(k,v,p,type);h+=`<td style="${classStyle(c)}" title="${escapeAttr(tip)}">${fmt(v,type)}</td>`}h+='</tr>'}document.getElementById('heatmap').innerHTML=h+'</tbody>';let s='<thead><tr><th>Metric</th><th>Loader In / Goal</th></tr></thead><tbody>';for(const r of d.shiftSummary||[]){let c=r.label==='Projected Attainment'?attainmentClass(r.value):r.label==='Current Shift Projection'&&Number(d.shiftGoal)>0?attainmentClass(r.value/d.shiftGoal*100):['5 Shift Average','14 Shift Average','20 Shift Average','30 Day Average'].includes(r.label)&&Number(d.shiftGoal)>0?attainmentClass(r.value/d.shiftGoal*100):r.label==='Consecutive Shifts Below Goal'?(Number(r.value)===0?'green':'red'):r.label==='Consecutive Shifts Above Goal'?(Number(r.value)>0?'green':'red'):'count';s+=`<tr><td class="period">${r.label}<span class="summary-sub">${r.shiftWindow||''}</span></td><td style="${classStyle(c)}">${r.format==='percent'&&r.value!=null?Number(r.value).toFixed(1)+'%':fmt(r.value)}</td></tr>`}document.getElementById('summary').innerHTML=s+'</tbody>'}
async function loadReviewTriggers(){try{const d=await getJson('/api/review-triggers');let h='<thead><tr><th>Tier</th><th>Line</th><th>Consecutive Red Shifts</th><th>20 Shift Avg</th><th>20 Shift Gap</th><th>Status</th><th>Last Completed Shift</th><th>Goal</th><th>Gap</th><th>Last Known Green Shift</th><th>Last Green End</th></tr></thead><tbody>';if(!d.rows.length)h+='<tr><td colspan="11" class="empty">No lines currently remain on Management Review.</td></tr>';for(const r of d.rows){if(r.tier==='Error'){h+=`<tr><td>Error</td><td>${r.line}</td><td colspan="9" class="left">${r.error}</td></tr>`;continue}const cls=r.tier==='Tier 3'?'tier3':r.tier==='Tier 2'?'tier2':'tier1';h+=`<tr class="${cls}"><td>${r.tier}</td><td class="left">${r.line}</td><td>${r.consecutiveRedShifts}</td><td>${fmt(r.twentyShiftAverage)}</td><td>${gapText(r.twentyShiftGap)}</td><td>${esc(r.reviewStatus||'REMAINS ON REVIEW')}</td><td>${fmt(r.lastCompletedShift)}</td><td>${fmt(r.goal)}</td><td>${gapText(r.gap)}</td><td>${fmt(r.lastKnownGreenShift)}</td><td>${r.lastGreenEnd?new Date(r.lastGreenEnd).toLocaleString():'Never in available history'}</td></tr>`}document.getElementById('reviewTriggers').innerHTML=h+'</tbody>'}catch(e){document.getElementById('reviewTriggers').innerHTML=`<tr><td class="empty">${e.message}</td></tr>`}}
async function loadZoneAlerts(){try{const d=await getJson('/api/zone-alerts');const alerts=Array.isArray(d.alerts)?d.alerts:[];let h='<thead><tr><th>Line</th><th>Zone</th><th>Historian Tag</th><th>Idle Since</th><th>Last Checked</th><th>Last Delta</th></tr></thead><tbody>';if(!alerts.length)h+='<tr><td colspan="6" class="empty">No active zone alerts</td></tr>';for(const r of alerts){h+=`<tr class="zone-alert-row"><td class="zone-alert-line" onclick="selectLine('${r.line}')">${r.line??'Unknown'}</td><td>${r.zone??'Unknown'}</td><td class="left" title="${escapeAttr(r.tag??'')}">${r.tag??'Unknown'}</td><td>${r.idleSince?new Date(r.idleSince).toLocaleString():'Unknown'}</td><td>${r.lastChecked?new Date(r.lastChecked).toLocaleString():'Unknown'}</td><td>${r.lastDelta==null?'No data':fmt(r.lastDelta)}</td></tr>`}document.getElementById('zoneAlerts').innerHTML=h+'</tbody>';document.getElementById('zone-alert-meta').textContent=`${alerts.length} active | Updated ${new Date(d.generatedAt).toLocaleTimeString()}`}catch(e){document.getElementById('zoneAlerts').innerHTML=`<tr><td class="empty">${e.message}</td></tr>`;document.getElementById('zone-alert-meta').textContent='Unavailable'}}
async function loadAlertStatus(){try{const d=await getJson('/api/alerts/status');const active=Array.isArray(d.activeZoneAlerts)?d.activeZoneAlerts.length:0;document.getElementById('alert-meta').textContent=`Alerts ${d.enabled?'enabled':'disabled'} | Active zone alerts ${active}${d.lastError?' | ERROR: '+d.lastError:''}`}catch(e){document.getElementById('alert-meta').textContent='Alert status unavailable: '+e.message}}
async function postJson(url,data){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const d=await r.json();if(!r.ok||d.error)throw new Error(d.error||'Save failed');return d}
function esc(s){return String(s??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
async function loadAlarmStory(){const line=document.getElementById('line').value;const d=await getJson('/api/story?line='+encodeURIComponent(line));document.getElementById('shiftStory').innerHTML=`<b>${esc(d.headline)}</b><div>${esc(d.narrative)}</div><div class="meta" style="margin-top:6px">Alarm burden ${Number(d.alarmMinutes||0).toFixed(1)} min · ${d.rootCandidates||0} root candidates · ${d.operatorAccess||0} operator access · ${d.interventionCount||0} interventions</div>`;document.getElementById('eventTimeline').innerHTML=(d.timeline||[]).map(e=>`<div class="event-row"><div>${new Date(e.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})}</div><div class="event-${e.kind}">${esc(e.label)}</div><div class="zone">${esc(e.zone||'—')}</div><div>${esc(e.detail||'')}</div></div>`).join('')||'<div class="empty">No correlated events.</div>';return d.alarms||[]}
async function loadActions(){const line=document.getElementById('line').value;const d=await getJson('/api/interventions?line='+encodeURIComponent(line));const list=document.getElementById('actionList');if(!d.actions.length){list.innerHTML='<div class="empty">No interventions logged for this line.</div>';return d.actions}list.innerHTML=d.actions.map(a=>`<div class="action-row"><b>${esc(a.zone)} · ${esc(a.action)}</b><div>${new Date(a.timestamp).toLocaleString()} · ${esc(a.category)}${a.technician?' · '+esc(a.technician):''}</div>${a.notes?`<div class="meta">${esc(a.notes)}</div>`:''}<div class="${a.effectClass||'effect-watch'}">${esc(a.effectText||'Awaiting enough post-action data')}</div></div>`).join('');return d.actions}
function drawTrend(d,actions,alarms){const svg=document.getElementById('trendChart');if(!svg)return;const rows=(d.periods||[]).filter(p=>!p.isLiveHour).slice().reverse();if(!rows.length){svg.innerHTML='<text x="450" y="140" text-anchor="middle" fill="#aeb5bf">No trend data</text>';return}const vals=rows.map(p=>Number(p.columns.Z6_IN)||0),target=Number((d.hourlyTargets||{}).Z6_IN)||Math.max(...vals,1),max=Math.max(target,...vals)*1.12,min=0,W=900,H=280,L=55,R=20,T=20,B=45,iw=W-L-R,ih=H-T-B,x=i=>L+(rows.length===1?iw/2:i*iw/(rows.length-1)),y=v=>T+ih-(v-min)/(max-min)*ih;let out='';for(let i=0;i<=4;i++){let v=max*i/4,yy=y(v);out+=`<line x1="${L}" y1="${yy}" x2="${W-R}" y2="${yy}" stroke="#334155"/><text x="${L-8}" y="${yy+4}" text-anchor="end" fill="#94a3b8" font-size="10">${Math.round(v).toLocaleString()}</text>`}out+=`<line x1="${L}" y1="${y(target)}" x2="${W-R}" y2="${y(target)}" stroke="#facc15" stroke-width="2" stroke-dasharray="7 5"/>`;out+=`<polyline fill="none" stroke="#60a5fa" stroke-width="3" points="${vals.map((v,i)=>x(i)+','+y(v)).join(' ')}"/>`;vals.forEach((v,i)=>{out+=`<circle cx="${x(i)}" cy="${y(v)}" r="4" fill="#93c5fd"><title>${rows[i].label}: ${v.toLocaleString()}</title></circle>`;out+=`<text x="${x(i)}" y="${H-15}" text-anchor="middle" fill="#94a3b8" font-size="9">${rows[i].label.split(' to ')[0]}</text>`});for(const a of actions||[]){const ts=new Date(a.timestamp).getTime();let best=-1,dist=Infinity;rows.forEach((r,i)=>{const mid=(new Date(r.start).getTime()+new Date(r.end).getTime())/2,dd=Math.abs(mid-ts);if(dd<dist){dist=dd;best=i}});if(best>=0&&dist<=90*60*1000){const xx=x(best);out+=`<line x1="${xx}" y1="${T}" x2="${xx}" y2="${T+ih}" stroke="#c084fc" stroke-width="2"/><polygon points="${xx},${T+2} ${xx-6},${T+12} ${xx+6},${T+12}" fill="#c084fc"><title>${esc(a.action)} — ${new Date(a.timestamp).toLocaleString()}</title></polygon>`}}for(const a of alarms||[]){const ts=new Date(a.start).getTime();let best=-1,dist=Infinity;rows.forEach((r,i)=>{const mid=(new Date(r.start).getTime()+new Date(r.end).getTime())/2,dd=Math.abs(mid-ts);if(dd<dist){dist=dd;best=i}});if(best>=0&&dist<=90*60*1000){const access=a.classification==='Operator Access',xx=x(best)+(access?7:-7),col=access?'#c084fc':'#fbbf24';out+=`<line x1="${xx}" y1="${T+15}" x2="${xx}" y2="${T+ih}" stroke="${col}" stroke-width="1" stroke-dasharray="3 4"/><circle cx="${xx}" cy="${T+18}" r="5" fill="${col}"><title>${esc(a.classification)}: ${esc(a.alarm)} — ${new Date(a.start).toLocaleString()}</title></circle>`}}svg.innerHTML=out}
async function refreshTrendPage(){if(!lastData)return;let alarms=[];try{const line=document.getElementById('line').value||lastData.selectedLine||'TAM01';const resp=await getJson('/api/alarms?line='+encodeURIComponent(line));alarms=resp.alarms||[]}catch(e){console.warn('Trend alarm context unavailable:',e)}drawTrend(lastData,[],alarms);try{const line=document.getElementById('line').value||lastData.selectedLine||'TAM01';const story=await getJson('/api/story?line='+encodeURIComponent(line));renderStory(story)}catch(e){console.warn('Shift story unavailable:',e)}}
function renderLineStatus(status){const grid=document.getElementById('lineStatusGrid');if(!grid)return;grid.innerHTML=Object.keys(status).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map(line=>`<label style="display:flex;align-items:center;gap:8px;border:1px solid #334155;padding:8px;background:#111b29"><input type="checkbox" data-line-status="${line}" ${status[line]?'checked':''}> <b>${line}</b> <span class="meta">${status[line]?'In Production':'Out'}</span></label>`).join('');grid.querySelectorAll('[data-line-status]').forEach(el=>el.addEventListener('change',()=>{const span=el.parentElement.querySelector('.meta');span.textContent=el.checked?'In Production':'Out'}))}
async function loadCommunicationSettings(){const ec=await getJson('/api/settings/email-control');document.getElementById('emailMasterEnabled').checked=!!ec.enabled;document.getElementById('emailControlState').textContent=ec.enabled?'Automatic email sending is ENABLED':'Automatic email sending is DISABLED — dashboard-only mode';recipientConfig=await getJson('/api/settings/recipients');const groups=Object.keys(recipientConfig.groups||{});for(const id of ['performanceGroup','zoneGroup']){const el=document.getElementById(id);el.innerHTML=groups.map(g=>`<option>${g}</option>`).join('')}document.getElementById('performanceGroup').value=recipientConfig.activePerformanceGroup||groups[0]||'';document.getElementById('zoneGroup').value=recipientConfig.activeZoneGroup||groups[0]||'';renderPeople();const ls=await getJson('/api/settings/line-status');renderLineStatus(ls.lines||{});const td=await getJson('/api/settings/targets');const tl=document.getElementById('targetLine');const lines=Object.keys(td.targets||{});tl.innerHTML=lines.map(line=>`<option>${line}</option>`).join('');tl.dataset.targets=JSON.stringify(td.targets||{});tl.value=(document.getElementById('line').value&&lines.includes(document.getElementById('line').value))?document.getElementById('line').value:(lines[0]||'');renderTargets()}
function renderPeople(){const pg=document.getElementById('performanceGroup').value,zg=document.getElementById('zoneGroup').value;const pset=new Set((recipientConfig.groups||{})[pg]||[]),zset=new Set((recipientConfig.groups||{})[zg]||[]);document.getElementById('people').innerHTML=(recipientConfig.people||[]).map((p,i)=>`<div class="person"><input type="checkbox" data-i="${i}" data-k="enabled" ${p.enabled!==false?'checked':''}><span>${p.name||''}</span><span>${p.email}</span><label><input type="checkbox" data-i="${i}" data-k="perf" ${pset.has(p.email)?'checked':''}> Perf</label><label><input type="checkbox" data-i="${i}" data-k="zone" ${zset.has(p.email)?'checked':''}> Zone</label></div>`).join('')}
function collectPeople(){const pg=document.getElementById('performanceGroup').value,zg=document.getElementById('zoneGroup').value;recipientConfig.groups[pg]=[];recipientConfig.groups[zg]=[];document.querySelectorAll('#people input[data-i]').forEach(el=>{const p=recipientConfig.people[Number(el.dataset.i)];if(el.dataset.k==='enabled')p.enabled=el.checked;if(el.dataset.k==='perf'&&el.checked)recipientConfig.groups[pg].push(p.email);if(el.dataset.k==='zone'&&el.checked)recipientConfig.groups[zg].push(p.email)});recipientConfig.activePerformanceGroup=pg;recipientConfig.activeZoneGroup=zg}
function renderTargets(){const all=JSON.parse(document.getElementById('targetLine').dataset.targets||'{}'),line=document.getElementById('targetLine').value,t=all[line]||{};const fields=[['Z1','Z1 Output','1'],['Z2A','Z2A Output','1'],['Z2A_YIELD','Z2A Yield %','0.1'],['Z3_OUT','Z3 Output','1'],['Z3_YIELD','Z3 Yield %','0.1'],['Z4_OUT','Z4 Output','1'],['Z4_YIELD','Z4 Yield %','0.1'],['Z5_IN','Z5 Output','1'],['Z5_YIELD','Z5 Yield %','0.1'],['ALI_OUT','ALI Output','1'],['ALI_YIELD','ALI Yield %','0.1'],['Z6_IN','Z6 Loader Out','1'],['Z6_YIELD','Z6 Yield %','0.1'],['LINE_YIELD','Line Yield %','0.1'],['SHIFT_GOAL','Shift Goal','1']];document.getElementById('targetGrid').innerHTML=fields.map(([k,label,step])=>`<label>${label}<input type="number" min="0" ${k.includes('YIELD')?'max="100"':''} step="${step}" data-target="${k}" value="${t[k]??(k.includes('YIELD')?98:'')}"></label>`).join('')}

const zonePhysical={
 Z1:{name:'Z1',desc:'Injection Molding FC/BC',metric:'Z1',target:'Z1'},
 Z2A:{name:'Z2A',desc:'Carry Over',metric:'Z2A',target:'Z2A'},
 Z3:{name:'Z3',desc:'Demold',metric:'Z3_OUT',target:'Z3_OUT'},
 Z4:{name:'Z4',desc:'Hydration Module',metric:'Z4_OUT',target:'Z4_OUT'},
 Z5B:{name:'Z5',desc:'PP Supply',metric:'Z5_IN',target:'Z5_IN'},
 ALI:{name:'ALI',desc:'Lens Inspection & Primary Pkg',metric:'ALI_OUT',target:'ALI_OUT'},
 Z6:{name:'Z6',desc:'Loader Out',metric:'Z6_IN',target:'Z6_IN'}
};
let selectedStoryZone='Z4';
function alarmZoneKey(z){const x=String(z||'').toUpperCase().replace(/[^A-Z0-9]/g,'');if(x.includes('Z4'))return 'Z4';if(x.includes('Z3'))return 'Z3';if(x.includes('Z2'))return 'Z2A';if(x.includes('Z1'))return 'Z1';if(x.includes('Z5'))return 'Z5B';if(x.includes('ALI'))return 'ALI';if(x.includes('Z6'))return 'Z6';return null}
function zoneSnapshot(key,data,alarms){const cfg=zonePhysical[key],p=(data.periods||[])[0]||{},cols=p.columns||{},target=(data.hourlyTargets||{})[cfg.target],value=cfg.metric?cols[cfg.metric]:null,pct=(Number.isFinite(Number(value))&&Number(target)>0)?Number(value)/Number(target)*100:null;const now=Date.now();const za=(alarms||[]).filter(a=>alarmZoneKey(a.zone||a.location)===key);const active=za.filter(a=>{const end=Date.parse(a.end||a.clear||'');return !Number.isNaN(end)&&end>=now});const recent=za[0];let state='unknown',label='NOT INSTRUMENTED';if(cfg.metric){if(active.length){state='down';label='ACTIVE ALARM'}else if(pct==null){state='unknown';label='NO DATA'}else if(pct<70){state='critical';label='CRITICAL'}else if(pct<90){state='under';label='UNDERPERFORMING'}else if(pct<98){state='watch';label='NEAR TARGET'}else{state='healthy';label='HEALTHY'}}const trend=data.trend||{};if(cfg.metric&&key==='Z6'&&!active.length&&trend.direction==='improving'&&pct!=null&&pct<105){state='recover';label='RECOVERING'}return {key,cfg,value,target,pct,state,label,alarms:za,active,recent}}
function zoneArrow(data){const d=(data.trend||{}).direction;return d==='improving'?'▲':d==='declining'?'▼':'→'}
function zoneSeriesValue(period,z){if(!z||!z.cfg.metric)return null;const v=Number((period.columns||{})[z.cfg.metric]);const t=Number((lastData&&lastData.hourlyTargets||{})[z.cfg.target]||z.target);if(!Number.isFinite(v)||!Number.isFinite(t)||t<=0)return null;return v/t*100}
function loaderSeriesValue(period,data){const v=Number((period.columns||{}).Z6_IN),t=Number((data.hourlyTargets||{}).Z6_IN);return Number.isFinite(v)&&Number.isFinite(t)&&t>0?v/t*100:null}
function renderZoneAnalysis(z,data,alarms,actions){
 const svg=document.getElementById('zoneAnalysisChart'),title=document.getElementById('zoneAnalysisTitle'),status=document.getElementById('zoneAnalysisStatus'),insight=document.getElementById('zoneInsight');if(!svg||!insight)return;
 if(!z||!z.cfg.metric){title.textContent=z?z.cfg.name+' — '+z.cfg.desc:'Select a monitored zone';status.textContent='No mapped production point';svg.innerHTML='<text x="450" y="150" text-anchor="middle" fill="#94a3b8" font-size="16">This physical zone is not yet mapped to a production historian tag.</text>';insight.innerHTML='<div class="empty">Map this zone to a historian production tag to enable trend comparison.</div>';return}
 title.textContent=`${z.cfg.name} — ${z.cfg.desc} vs Loader Out`;status.textContent=`${z.pct==null?'—':z.pct.toFixed(1)+'%'} current`;
 const periods=(data.periods||[]).slice().reverse(),pts=[];for(const p of periods){pts.push({p,z:zoneSeriesValue(p,z),l:loaderSeriesValue(p,data)})}const valid=pts.flatMap(x=>[x.z,x.l]).filter(Number.isFinite);const ymax=Math.max(120,...valid.map(v=>Math.ceil(v/10)*10));const ymin=Math.min(0,...valid.map(v=>Math.floor(v/10)*10));const W=900,H=300,L=54,R=18,T=25,B=46,x=i=>L+(W-L-R)*(pts.length<=1?.5:i/(pts.length-1)),y=v=>T+(H-T-B)*(1-(v-ymin)/(ymax-ymin));let h='';
 for(let v=ymin;v<=ymax;v+=20){h+=`<line x1="${L}" y1="${y(v)}" x2="${W-R}" y2="${y(v)}" stroke="#263546" stroke-width="1"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" fill="#91a0b2" font-size="10">${v}%</text>`}h+=`<line x1="${L}" y1="${y(100)}" x2="${W-R}" y2="${y(100)}" stroke="#f0c84b" stroke-width="2" stroke-dasharray="7 6"/>`;
 function path(key){let d='',started=false;pts.forEach((q,i)=>{const v=q[key];if(!Number.isFinite(v)){started=false;return}d+=(started?' L ':'M ')+x(i).toFixed(1)+' '+y(v).toFixed(1);started=true});return d}
 h+=`<path d="${path('z')}" fill="none" stroke="#ff5b57" stroke-width="3"/><path d="${path('l')}" fill="none" stroke="#5aa2ff" stroke-width="3"/>`;pts.forEach((q,i)=>{if(Number.isFinite(q.z))h+=`<circle cx="${x(i)}" cy="${y(q.z)}" r="3.5" fill="#ff5b57"/>`;if(Number.isFinite(q.l))h+=`<rect x="${x(i)-3}" y="${y(q.l)-3}" width="6" height="6" fill="#5aa2ff"/>`;const label=(q.p.label||'').replace(' to ','–').replace(/:00 /g,' ');h+=`<text x="${x(i)}" y="${H-17}" text-anchor="middle" fill="#91a0b2" font-size="9">${esc(label.split(' ')[0])}</text>`});
 const starts=periods.map(p=>Date.parse(p.start));const minT=Math.min(...starts.filter(Number.isFinite)),maxT=Math.max(...starts.filter(Number.isFinite));function eventX(t){const ms=Date.parse(t);if(!Number.isFinite(ms)||!Number.isFinite(minT)||maxT===minT)return null;return L+(W-L-R)*((ms-minT)/(maxT-minT))}const za=(alarms||[]).filter(a=>alarmZoneKey(a.zone||a.location)===z.key);za.slice(0,8).forEach(a=>{const ex=eventX(a.start);if(ex!=null&&ex>=L&&ex<=W-R)h+=`<line x1="${ex}" y1="${T}" x2="${ex}" y2="${H-B}" stroke="#ef4444" stroke-dasharray="3 4"/><text x="${ex+3}" y="${T+11}" fill="#f87171" font-size="11">⚠</text>`});(actions||[]).filter(a=>alarmZoneKey(a.zone)===z.key||a.zone==='Line').slice(0,8).forEach(a=>{const ex=eventX(a.timestamp);if(ex!=null&&ex>=L&&ex<=W-R)h+=`<line x1="${ex}" y1="${T}" x2="${ex}" y2="${H-B}" stroke="#38bdf8" stroke-dasharray="3 4"/><text x="${ex+3}" y="${T+24}" fill="#7dd3fc" font-size="11">◆</text>`});svg.innerHTML=h;
 const recent=pts.slice(-3),old=pts.slice(-6,-3);function avg(arr,k){const a=arr.map(x=>x[k]).filter(Number.isFinite);return a.length?a.reduce((s,v)=>s+v,0)/a.length:null}const zr=avg(recent,'z'),zo=avg(old,'z'),lr=avg(recent,'l'),lo=avg(old,'l'),zt=zr!=null&&zo!=null?zr-zo:null,lt=lr!=null&&lo!=null?lr-lo:null;let prop='INSUFFICIENT DATA',cls='prop-watch',assessment='Continue monitoring the selected zone and Loader Out together.';if(zt!=null&&lt!=null){if(zt>=5&&lt>=2){prop='RECOVERY PROPAGATING';cls='prop-good';assessment='The selected zone and Loader Out are both improving. Allow stabilization unless a new alarm or reversal appears.'}else if(zt>=5&&lt<1){prop='RECOVERY NOT YET AT LOADER';cls='prop-watch';assessment='The selected zone is improving but Loader Out has not responded materially yet. Monitor for downstream propagation before making another adjustment.'}else if(zt<=-5&&lt<=-2){prop='DECLINE PROPAGATING';cls='prop-bad';assessment='Selected-zone deterioration is accompanied by Loader Out deterioration. Investigate the earliest upstream constraint and active alarms.'}else if(zr!=null&&zr>=98&&lr!=null&&lr>=98){prop='STABLE / ON TARGET';cls='prop-good';assessment='Both the selected zone and Loader Out are at target. Avoid unnecessary process changes.'}else{prop='MIXED RESPONSE';assessment='Zone and Loader Out trends are not moving together strongly enough to infer propagation.'}}
 const lastAlarm=za.length?new Date(za[0].start).toLocaleTimeString():'None',zoneNow=z.pct==null?'—':z.pct.toFixed(1)+'%',loaderNow=pts.length&&Number.isFinite(pts.at(-1).l)?pts.at(-1).l.toFixed(1)+'%':'—';
 insight.innerHTML=`<div class="selected-zone-title">Loader Out (Z6)</div><div class="metric-row"><span>Loader Out — Current</span><b class="${Number(loaderNow.replace('%',''))<90?'hero-bad':'hero-warn'}">${loaderNow}</b></div><div class="metric-row"><span>Loader Out — Trend (3 Hr)</span><b class="${lt!=null&&lt>=0?'hero-good':'hero-bad'}">${lt==null?'—':(lt>=0?'↑ +':'↓ ')+Math.abs(lt).toFixed(1)+' pts'}</b></div><div class="metric-row"><span>Selected Zone → Loader</span><b>${zt!=null&&lt!=null&&zt>0&&lt>0?'Response detected':'Monitoring'}</b></div><div class="metric-row"><span>Propagation Status</span><b class="${cls}">${prop}</b></div><div class="metric-row"><span>Assessment</span><b style="font-size:11px;line-height:1.4">${assessment}</b></div><div class="metric-row"><span>Confidence</span><b class="hero-warn">Medium</b></div>`;
 const cap=document.getElementById('zoneChartCaption');if(cap)cap.textContent=`${z.cfg.name} trend is shown against Loader Out so you can see whether upstream recovery or deterioration is propagating to the end of the line.`;
}
function renderZoneDetail(z,data,actions){
 const el=document.getElementById('zoneDetail');if(!z){el.innerHTML='<div class="empty">Select a zone</div>';return}
 const pct=z.pct==null?'—':z.pct.toFixed(1)+'%',value=z.value==null?'—':Math.round(z.value).toLocaleString(),target=z.target==null?'—':Math.round(z.target).toLocaleString(),trend=Number((data.trend||{}).changePct),badge=z.state==='healthy'?'HEALTHY':z.state==='recover'?'RECOVERING':(z.state==='down'||z.state==='critical')?'INTERVENE':z.state==='under'?'INVESTIGATE':'STABILIZE';
 document.getElementById('zoneAnalysisPanelTitle').textContent=`${z.cfg.name} — ${z.cfg.desc}`;
 el.innerHTML=`<div class="selected-zone-title">${esc(z.cfg.name)} — ${esc(z.cfg.desc)}</div><span class="action-badge action-${badge}">${badge}</span><div class="metric-row"><span>Current Hour</span><b class="${z.pct<90?'hero-bad':z.pct<98?'hero-warn':'hero-good'}">${pct}<br><small>${value} / ${target}</small></b></div><div class="metric-row"><span>3-Hour Trend</span><b class="${trend>=0?'hero-good':'hero-bad'}">${Number.isFinite(trend)?(trend>=0?'↑ +':'↓ ')+Math.abs(trend).toFixed(1)+'%':'—'}</b></div><div class="metric-row"><span>Active Alarms</span><b>${z.active.length}</b></div><div class="metric-row"><span>Last Alarm</span><b>${z.recent?new Date(z.recent.start).toLocaleTimeString():'None'}</b></div><div class="metric-row"><span>Recommendation</span><b class="recommend">${badge==='RECOVERING'||badge==='STABILIZE'?'STABILIZE':badge}</b></div>`;
}
function storyPct(v){return v==null||!Number.isFinite(Number(v))?'—':Number(v).toFixed(1)+'%'}
function storyHero(data){
 const current=(data.periods||[])[0]||{},z6=Number((current.columns||{}).Z6_IN),t=Number((data.hourlyTargets||{}).Z6_IN);
 const cur=(Number.isFinite(z6)&&t>0)?z6/t*100:null,goal=Number(data.shiftGoal||0);
 const actual=(data.periods||[]).reduce((sum,p)=>sum+(Number((p.columns||{}).Z6_IN)||0),0),gap=goal?actual-goal:null;
 document.getElementById('lineHero').innerHTML=`<div class="hero-cell"><span class="hero-label">Select Line (TAM)</span><span class="hero-value">${esc(data.selectedLine||document.getElementById('line').value)}</span></div><div class="hero-cell"><span class="hero-label">Shift</span><span class="hero-value" style="font-size:15px">Current 12-Hour Shift</span><div class="hero-sub">Hourly process analysis</div></div><div class="hero-cell"><span class="hero-label">Projected Attainment</span><span class="hero-value ${Number(data.projectedAttainment)<98?'hero-bad':'hero-good'}">${storyPct(data.projectedAttainment)}</span></div><div class="hero-cell"><span class="hero-label">Current Hour / Loader Out</span><span class="hero-value ${cur!=null&&cur<90?'hero-bad':cur!=null&&cur<98?'hero-warn':'hero-good'}">${Number.isFinite(z6)?Math.round(z6).toLocaleString():'—'} / ${t>0?Math.round(t).toLocaleString():'—'}</span><div class="hero-sub">${storyPct(cur)} of hourly target</div></div><div class="hero-cell"><span class="hero-label">Shift Goal</span><span class="hero-value">${goal?Math.round(goal).toLocaleString():'—'}</span></div><div class="hero-cell"><span class="hero-label">Shift Actual</span><span class="hero-value">${Math.round(actual).toLocaleString()}</span></div><div class="hero-cell"><span class="hero-label">Gap to Goal</span><span class="hero-value ${gap!=null&&gap<0?'hero-bad':'hero-good'}">${gap==null?'—':(gap>=0?'+':'')+Math.round(gap).toLocaleString()}</span></div>`;
}
function renderStoryTables(z,alarms,actions){
 const now=Date.now(),za=(alarms||[]).filter(a=>alarmZoneKey(a.zone||a.location)===z.key),active=za.filter(a=>{const e=Date.parse(a.end||a.clear||'');return Number.isFinite(e)&&e>=now}),recent=(alarms||[]).filter(a=>Date.parse(a.start)>=now-4*3600000).slice(0,8),acts=(actions||[]).filter(a=>alarmZoneKey(a.zone)===z.key||a.zone==='Line').slice(0,6);
 const row=a=>`<tr><td>${a.start?new Date(a.start).toLocaleTimeString():'—'}</td><td>${esc(a.zone||'—')}</td><td>${esc(a.alarm||a.classification||'Alarm')}</td><td>${a.durationMinutes!=null?Number(a.durationMinutes).toFixed(1)+'m':'—'}</td><td><span class="event-type">${esc(a.classification||'Alarm')}</span></td></tr>`;
 document.getElementById('activeZoneAlarmTable').innerHTML=active.length?`<table class="mini-table"><thead><tr><th>Time</th><th>Zone</th><th>Description</th><th>Duration</th><th>Type</th></tr></thead><tbody>${active.map(row).join('')}</tbody></table>`:'<div class="empty">✓ No active alarms</div>';
 document.getElementById('recentAlarmTable').innerHTML=recent.length?`<table class="mini-table"><thead><tr><th>Time</th><th>Zone</th><th>Description</th><th>Duration</th><th>Type</th></tr></thead><tbody>${recent.map(row).join('')}</tbody></table>`:'<div class="empty">No recent alarms</div>';
 document.getElementById('recentInterventionTable').innerHTML=acts.length?`<table class="mini-table"><thead><tr><th>Time</th><th>Zone</th><th>Action</th><th>Technician</th></tr></thead><tbody>${acts.map(a=>`<tr><td>${new Date(a.timestamp).toLocaleTimeString()}</td><td>${esc(a.zone||'—')}</td><td>${esc(a.action||'Action')}</td><td>${esc(a.technician||'—')}</td></tr>`).join('')}</tbody></table>`:'<div class="empty">No interventions logged for this zone</div>';
}

async function refreshLineStory(){const line=document.getElementById('line').value||'TAM01';const results=await Promise.allSettled([getJson('/api/data?line='+encodeURIComponent(line)),getJson('/api/alarms?line='+encodeURIComponent(line)),getJson('/api/interventions?line='+encodeURIComponent(line))]);if(results[0].status!=='fulfilled')throw results[0].reason;const data=results[0].value,alarmResp=results[1].status==='fulfilled'?results[1].value:{alarms:[]},actionResp=results[2].status==='fulfilled'?results[2].value:{actions:[]};const alarms=alarmResp.alarms||[],actions=actionResp.actions||[],zones=Object.keys(zonePhysical).map(k=>zoneSnapshot(k,data,alarms));document.getElementById('lineStoryTitle').textContent=line;storyHero(data);const monitored=zones.filter(z=>z.cfg.metric),down=zones.filter(z=>z.state==='down').length,under=zones.filter(z=>['critical','under'].includes(z.state)).length,healthy=zones.filter(z=>z.state==='healthy').length,recover=zones.filter(z=>z.state==='recover').length;document.getElementById('lineStoryMeta').textContent=`${monitored.length} monitored production points | ${alarms.length} alarm events`;const a=data.actionStatus||{};document.getElementById('lineSummary').innerHTML=`<div class="line-kpi"><span>Shift projection</span><b>${data.projectedAttainment==null?'—':Number(data.projectedAttainment).toFixed(1)+'%'}</b></div><div class="line-kpi"><span>Operational state</span><b><span class="action-badge action-${a.code||'NO_DATA'}">${esc(a.label||'NO DATA')}</span></b></div><div class="line-kpi"><span>Actively down</span><b>${down}</b></div><div class="line-kpi"><span>Underperforming</span><b>${under}</b></div><div class="line-kpi"><span>Healthy / recovering</span><b>${healthy} / ${recover}</b></div>`;
 const order=['Z1','Z2A','Z3','Z4','Z5B','ALI','Z6'];let html='';for(let oi=0;oi<order.length;oi++){const k=order[oi],z=zones.find(x=>x.key===k);if(!z)continue;const rate=z.pct==null?'—':z.pct.toFixed(1)+'%';if(oi>0)html+=`<div class="flow-link"></div>`;html+=`<button type="button" class="zone-card zone-${z.state}${selectedStoryZone===k?' selected':''}" data-zone="${k}" title="${escapeAttr(z.label)}"><span class="zone-trend">${zoneArrow(data)}</span><div class="zone-name">${esc(z.cfg.name)}</div><div class="zone-rate">${rate}</div><div class="zone-desc">${esc(z.cfg.desc)}</div><div class="zone-state">${esc(z.label)}${z.active.length?' · ALARM':''}</div></button>`}document.getElementById('lineSchematic').innerHTML=html;document.querySelectorAll('#lineSchematic .zone-card').forEach(b=>b.addEventListener('click',()=>{selectedStoryZone=b.dataset.zone;document.querySelectorAll('#lineSchematic .zone-card').forEach(x=>x.classList.toggle('selected',x.dataset.zone===selectedStoryZone));const chosen=zones.find(z=>z.key===selectedStoryZone);renderZoneDetail(chosen,data,actions);renderZoneAnalysis(chosen,data,alarms,actions);renderStoryTables(chosen,alarms,actions)}));const initialZone=zones.find(z=>z.key===selectedStoryZone)||zones.find(z=>z.cfg.metric);renderZoneDetail(initialZone,data,actions);renderZoneAnalysis(initialZone,data,alarms,actions);renderStoryTables(initialZone,alarms,actions);
 const eventRows=[];alarms.forEach(x=>eventRows.push({t:x.start,kind:'alarm',zone:alarmZoneKey(x.zone)||x.zone||'',text:x.alarm||x.classification||'Alarm'}));actions.forEach(x=>eventRows.push({t:x.timestamp,kind:'action',zone:x.zone||'',text:x.action||'Action'}));eventRows.sort((a,b)=>Date.parse(b.t)-Date.parse(a.t));document.getElementById('lineEvents').innerHTML=eventRows.length?eventRows.slice(0,12).map(e=>`<div class="line-event event-${e.kind}"><b>${e.kind==='alarm'?'⚠':'◆'} ${esc(e.zone)}</b> ${esc(e.text)}<div class="meta">${new Date(e.t).toLocaleString()}</div></div>`).join(''):'<div class="empty">No recent alarms or interventions</div>';
 let note='';const z4=zones.find(z=>z.key==='Z4'),z5=zones.find(z=>z.key==='Z5B'),z6=zones.find(z=>z.key==='Z6');if(z4&&z4.state==='down')note='Story: Zone 4 has an active alarm. Downstream performance should be interpreted as a likely consequence until Zone 4 recovers.';else if(data.trend&&data.trend.direction==='improving')note='Story: Current line trend is improving. Blue/amber zones indicate recovery or remaining constraints; allow stabilization where performance is propagating downstream.';else if(data.trend&&data.trend.direction==='declining')note='Story: Current line trend is declining. Focus on the earliest upstream zone that is under target or carrying an active root-cause alarm.';else note='Story: Current production is comparatively stable. Use zone colors to identify local constraints without disturbing healthy process areas.';document.getElementById('lineFlowNote').textContent=note;}
async function loadHistoricalRecord(){
 const line=document.getElementById('line').value||'TAM01',d=await getJson('/api/history-records?line='+encodeURIComponent(line)),r=d.record||{},box=document.getElementById('historyRecords');
 const rec=r.record,green=r.lastGreen,top=r.top10||[],dept=(d.department||{}).record;let h='';
 if(rec)h+=`<div class="metric-row"><span>🏆 ${esc(line)} shift record</span><b>${fmt(rec.value)}</b></div><div class="meta">${new Date(rec.end).toLocaleString()} · ${rec.attainment!=null?Number(rec.attainment).toFixed(1)+'% of current goal':''}</div>`;
 else h+='<div class="empty">Historical record cache has not been built yet. Use Shift Control → Rebuild historical records.</div>';
 if(green)h+=`<div class="metric-row"><span>Last known green shift</span><b>${fmt(green.value)}</b></div><div class="meta">${new Date(green.end).toLocaleString()}</div>`;
 if(dept)h+=`<div class="metric-row"><span>Department record</span><b>${esc(dept.line)} · ${fmt(dept.value)}</b></div>`;
 if(top.length){h+='<div style="margin-top:12px;font-weight:700">Top 10 completed shifts</div>'+top.map((x,i)=>`<div class="metric-row"><span>#${i+1} ${new Date(x.end).toLocaleDateString()}</span><b>${fmt(x.value)}</b></div>`).join('')}
 if(d.generatedAt)h+=`<div class="meta" style="margin-top:10px">Cache built ${new Date(d.generatedAt).toLocaleString()} · ${d.scanDays}-day scan</div>`;box.innerHTML=h;
}
async function pollHistoryBuild(){try{const d=await getJson('/api/history-records/status'),el=document.getElementById('historyBuildState');if(!el)return;el.textContent=d.running?`Scanning historian: ${d.completed}/${d.total}${d.currentLine?' · '+d.currentLine:''}`:d.error?'Last rebuild failed: '+d.error:d.finishedAt?'Last rebuild completed '+new Date(d.finishedAt).toLocaleString():'No rebuild running';if(d.running)setTimeout(pollHistoryBuild,1500)}catch(e){}}
async function refreshHistory(){
 const line=document.getElementById('line').value||'TAM01',d=await getJson('/api/history?line='+encodeURIComponent(line)+'&count=60'),rows=d.rows||[],svg=document.getElementById('historyChart'),sum=document.getElementById('historySummary');
 if(!rows.length){svg.innerHTML='<text x="500" y="210" text-anchor="middle" fill="#94a3b8" font-size="18">No completed shift history available</text>';sum.innerHTML='<div class="empty">No history available for '+esc(line)+'</div>';return}
 const W=1000,H=430,L=70,R=25,T=35,B=65,vals=rows.map(r=>Number(r.value)).filter(Number.isFinite),goal=Number(d.goal||0),min=Math.min(...vals,goal||Infinity)*.9,max=Math.max(...vals,goal||0)*1.08,x=i=>L+(W-L-R)*(rows.length<=1?.5:i/(rows.length-1)),y=v=>T+(H-T-B)*(1-(v-min)/(max-min||1));let h='';
 for(let i=0;i<=5;i++){const v=min+(max-min)*i/5;h+=`<line x1="${L}" y1="${y(v)}" x2="${W-R}" y2="${y(v)}" stroke="#263546"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" fill="#91a0b2" font-size="11">${Math.round(v).toLocaleString()}</text>`}
 if(goal>0)h+=`<line x1="${L}" y1="${y(goal)}" x2="${W-R}" y2="${y(goal)}" stroke="#f0c84b" stroke-width="2" stroke-dasharray="7 6"/><text x="${W-R-5}" y="${y(goal)-7}" text-anchor="end" fill="#f0c84b" font-size="11">Goal ${Math.round(goal).toLocaleString()}</text>`;
 let path='';rows.forEach((r,i)=>{const v=Number(r.value);path+=(i?' L ':'M ')+x(i)+' '+y(v);const dt=new Date(r.start);if(i%4===0||i===rows.length-1){const shift=dt.getHours()===6?'D':'N';h+=`<text x="${x(i)}" y="${H-28}" text-anchor="middle" fill="#91a0b2" font-size="10">${dt.toLocaleDateString(undefined,{month:'numeric',day:'numeric'})} ${shift}</text>`}});h+=`<path d="${path}" fill="none" stroke="#5aa2ff" stroke-width="3"/>`;rows.forEach((r,i)=>{const v=Number(r.value),ok=!goal||v>=goal;h+=`<circle cx="${x(i)}" cy="${y(v)}" r="5" fill="${ok?'#22c55e':'#ef4444'}"><title>${new Date(r.start).toLocaleString()} — ${Math.round(v).toLocaleString()} (${r.attainment==null?'—':Number(r.attainment).toFixed(1)+'%'})</title></circle>`});svg.innerHTML=h;
 const recent=n=>rows.slice(-n).map(r=>Number(r.value)).filter(Number.isFinite),avg=a=>a.length?a.reduce((s,v)=>s+v,0)/a.length:null,a5=avg(recent(5)),a14=avg(recent(14)),a20=avg(recent(20)),a30=avg(recent(60)),latest=rows.at(-1);let below=0,above=0;if(goal){for(let i=rows.length-1;i>=0;i--){if(Number(rows[i].value)<goal)below++;else break}for(let i=rows.length-1;i>=0;i--){if(Number(rows[i].value)>=goal)above++;else break}}
 const metric=(label,v)=>`<div class="metric-row"><span>${label}</span><b>${v==null?'—':Math.round(v).toLocaleString()}</b></div>`;sum.innerHTML=`<div class="selected-zone-title">${esc(line)}</div>${metric('Last completed shift',Number(latest.value))}${metric('5 Shift Average',a5)}${metric('14 Shift Average',a14)}${metric('20 Shift Average',a20)}${metric('30 Day Average',a30)}<div class="metric-row"><span>Goal</span><b>${goal?Math.round(goal).toLocaleString():'—'}</b></div><div class="metric-row"><span>Consecutive below goal</span><b class="${below?'hero-bad':'hero-good'}">${below}</b></div><div class="metric-row"><span>Consecutive above goal</span><b class="${above?'hero-good':''}">${above}</b></div><div class="meta" style="margin-top:12px">Source: ${esc(d.provider||'unknown')}</div>`;
 await loadHistoricalRecord();
}
document.querySelectorAll('[data-page]').forEach(btn=>btn.addEventListener('click',async()=>{document.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b===btn));document.querySelectorAll('.page').forEach(pg=>pg.classList.toggle('active',pg.id==='page-'+btn.dataset.page));if(btn.dataset.page==='trends'){try{await refreshTrendPage()}catch(e){}}if(btn.dataset.page==='history'){try{await refreshHistory()}catch(e){document.getElementById('historySummary').textContent='History unavailable: '+e.message}}if(btn.dataset.page==='shiftcontrol'){try{await loadCommunicationSettings()}catch(e){document.getElementById('emailControlState').textContent='Communication settings unavailable: '+e.message}}if(btn.dataset.page==='lineview'){try{await refreshLineStory()}catch(e){document.getElementById('lineFlowNote').textContent='Line story unavailable: '+e.message}}if(btn.dataset.page==='controls'){try{const h=await getJson('/api/health');document.getElementById('systemHealthReadOnly').innerHTML=`<b>Current source health</b><br>Production: ${h.production?.ok?'CONNECTED':'UNAVAILABLE'} — ${esc(h.production?.detail||'')}<br>Alarms: ${h.alarms?.ok?'CONNECTED':'UNAVAILABLE'} — ${esc(h.alarms?.detail||'')}<br><br><b>Write operations:</b> DISABLED<br><b>Email sending:</b> CONFIGURABLE IN SHIFT CONTROL (startup default OFF)<br><b>Manufacturing/source write operations:</b> DISABLED<br><b>Operational record entry:</b> DISABLED`;}catch(e){document.getElementById('systemHealthReadOnly').textContent='Health unavailable: '+e.message}}}));document.getElementById('performanceGroup')?.addEventListener('change',renderPeople);document.getElementById('zoneGroup')?.addEventListener('change',renderPeople);document.getElementById('targetLine')?.addEventListener('change',renderTargets);document.getElementById('addPerson')?.addEventListener('click',()=>{const name=document.getElementById('newName').value.trim(),email=document.getElementById('newEmail').value.trim();if(!email)return;recipientConfig.people.push({name:name||email.split('@')[0],email,enabled:true});document.getElementById('newName').value='';document.getElementById('newEmail').value='';renderPeople()});document.getElementById('saveEmailControl')?.addEventListener('click',async()=>{try{const enabled=document.getElementById('emailMasterEnabled').checked;await postJson('/api/settings/email-control',{enabled});document.getElementById('emailControlState').textContent=enabled?'Automatic email sending is ENABLED':'Automatic email sending is DISABLED — dashboard-only mode';document.getElementById('emailControlMsg').textContent='Saved'}catch(e){document.getElementById('emailControlMsg').textContent=e.message}});document.getElementById('addGroup')?.addEventListener('click',()=>{const name=document.getElementById('newGroupName').value.trim();if(!name)return;if(recipientConfig.groups[name]){document.getElementById('recipientMsg').textContent='That distribution list already exists';return}recipientConfig.groups[name]=[];document.getElementById('newGroupName').value='';for(const id of ['performanceGroup','zoneGroup']){const el=document.getElementById(id);el.innerHTML=Object.keys(recipientConfig.groups).map(g=>`<option>${g}</option>`).join('')}document.getElementById('performanceGroup').value=name;renderPeople();document.getElementById('recipientMsg').textContent='New list created locally — click Save recipients to keep it'});document.getElementById('deleteGroup')?.addEventListener('click',()=>{const name=document.getElementById('performanceGroup').value;if(!name||!recipientConfig.groups[name])return;if(Object.keys(recipientConfig.groups).length<=1){document.getElementById('recipientMsg').textContent='Keep at least one distribution list';return}delete recipientConfig.groups[name];const groups=Object.keys(recipientConfig.groups);recipientConfig.activePerformanceGroup=groups[0];if(!recipientConfig.groups[recipientConfig.activeZoneGroup])recipientConfig.activeZoneGroup=groups[0];for(const id of ['performanceGroup','zoneGroup']){const el=document.getElementById(id);el.innerHTML=groups.map(g=>`<option>${g}</option>`).join('')}document.getElementById('performanceGroup').value=recipientConfig.activePerformanceGroup;document.getElementById('zoneGroup').value=recipientConfig.activeZoneGroup;renderPeople();document.getElementById('recipientMsg').textContent='List removed locally — click Save recipients to keep it'});document.getElementById('saveRecipients')?.addEventListener('click',async()=>{try{collectPeople();await postJson('/api/settings/recipients',recipientConfig);document.getElementById('recipientMsg').textContent='Saved'}catch(e){document.getElementById('recipientMsg').textContent=e.message}});document.getElementById('saveLineStatus')?.addEventListener('click',async()=>{try{const lines={};document.querySelectorAll('[data-line-status]').forEach(el=>lines[el.dataset.lineStatus]=!!el.checked);await postJson('/api/settings/line-status',{lines});document.getElementById('lineStatusMsg').textContent='Saved — floor totals and alerts updated';await refresh()}catch(e){document.getElementById('lineStatusMsg').textContent=e.message}});document.getElementById('saveTargets')?.addEventListener('click',async()=>{try{const line=document.getElementById('targetLine').value,values={};document.querySelectorAll('[data-target]').forEach(el=>{const n=Number(el.value);if(Number.isFinite(n)&&n>=0)values[el.dataset.target]=n});await postJson('/api/settings/targets',{line,values});document.getElementById('targetMsg').textContent='Saved';await load()}catch(e){document.getElementById('targetMsg').textContent=e.message}});
document.getElementById('rebuildHistoryOnHistory')?.addEventListener('click',async()=>{try{const el=document.getElementById('historyBuildMsgOnHistory');el.textContent='Starting deep historical scan...';await postJson('/api/history-records/rebuild',{});el.textContent='Historical scan started. You can keep using the dashboard.';pollHistoryBuild()}catch(e){document.getElementById('historyBuildMsgOnHistory').textContent=e.message}});
document.getElementById('currentShiftDowntime')?.addEventListener('click',async()=>{const msg=document.getElementById('downtimeMsg'),out=document.getElementById('downtimeResults');try{msg.textContent='Calculating this shift...';const d=await getJson('/api/downtime-current-shift');msg.textContent=`This shift: ${d.totalDowntimeMinutes.toFixed(1)} total downtime min across ${d.eventCount} event(s)`;const lineRows=(d.byLine||[]).map(r=>`<tr><td>${r.line}</td><td>${r.minutes.toFixed(1)} min</td></tr>`).join('');const zoneRows=(d.byZone||[]).map(r=>`<tr><td>${r.lineZone}</td><td>${r.minutes.toFixed(1)} min</td></tr>`).join('');out.innerHTML=`<div class="meta">Shift start: ${new Date(d.shiftStart).toLocaleString()} • As of: ${new Date(d.asOf).toLocaleString()}</div><div class="settings-grid" style="margin-top:8px"><div><b>This Shift — By Line</b><table><tbody>${lineRows||'<tr><td>No detected downtime this shift</td></tr>'}</tbody></table></div><div><b>This Shift — By Line / Zone</b><table><tbody>${zoneRows||'<tr><td>No detected downtime this shift</td></tr>'}</tbody></table></div></div><p class="meta">${d.note}</p>`;}catch(e){msg.textContent=e.message;out.innerHTML='';}});
document.getElementById('compileDowntime')?.addEventListener('click',async()=>{const msg=document.getElementById('downtimeMsg'),out=document.getElementById('downtimeResults');try{msg.textContent='Compiling...';const days=document.getElementById('downtimeDays').value;const d=await getJson('/api/downtime-summary?days='+encodeURIComponent(days));msg.textContent=`${d.eventCount} recovered downtime event(s) in ${d.days} days`;const lineRows=(d.byLine||[]).map(r=>`<tr><td>${r.line}</td><td>${r.minutes.toFixed(1)} min</td></tr>`).join('');const zoneRows=(d.byZone||[]).map(r=>`<tr><td>${r.lineZone}</td><td>${r.minutes.toFixed(1)} min</td></tr>`).join('');out.innerHTML=`<div class="settings-grid"><div><b>By Line</b><table><tbody>${lineRows||'<tr><td>No recorded events</td></tr>'}</tbody></table></div><div><b>By Line / Zone</b><table><tbody>${zoneRows||'<tr><td>No recorded events</td></tr>'}</tbody></table></div></div><p class="meta">${d.note}</p>`;}catch(e){msg.textContent=e.message;out.innerHTML='';}});
document.getElementById('rebuildHistory')?.addEventListener('click',async()=>{try{document.getElementById('historyBuildMsg').textContent='Starting deep historical scan...';await postJson('/api/history-records/rebuild',{});document.getElementById('historyBuildMsg').textContent='Historical scan started. You can keep using the dashboard.';pollHistoryBuild()}catch(e){document.getElementById('historyBuildMsg').textContent=e.message}});
function selectLine(line){document.getElementById('line').value=line;load();loadOverview()}
document.getElementById('line').addEventListener('change',()=>{load();loadOverview();if(document.getElementById('page-lineview').classList.contains('active'))refreshLineStory().catch(()=>{});if(document.getElementById('page-history').classList.contains('active'))refreshHistory().catch(()=>{})});
async function safeRun(name,fn){try{return await fn()}catch(e){console.error(name,e);return null}}
async function refresh(){const meta=document.getElementById('meta');const core=await safeRun('production data',load);if(!core&&meta)meta.textContent='Production data failed to load — see browser console/server log';await Promise.allSettled([safeRun('overview',loadOverview),safeRun('management review',loadReviewTriggers),safeRun('zone alerts',loadZoneAlerts),safeRun('alert status',loadAlertStatus)])}
const actionTimeEl=document.getElementById('actionTime');if(actionTimeEl)actionTimeEl.value=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);refresh();setInterval(load,15000);setInterval(loadOverview,60000);setInterval(loadReviewTriggers,60000);setInterval(loadZoneAlerts,60000);setInterval(loadAlertStatus,60000);
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    def send_body(self, body, content_type="application/json", status=200):
        encoded = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        try:
            self.wfile.write(encoded)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass

    def json_response(self, payload, status=200):
        self.send_body(json.dumps(payload, default=str), "application/json; charset=utf-8", status)

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                return self.send_body(INDEX_HTML, "text/html; charset=utf-8")
            if parsed.path == "/api/mappings":
                return self.json_response(ALL_LINE_MAP)
            if parsed.path == "/api/overview":
                return self.json_response(all_lines_shift_overview() if CONFIG.get("provider") == "aveva-sql" else synthetic_all_lines_shift_overview())
            if parsed.path == "/api/review-triggers":
                return self.json_response(management_review_triggers() if CONFIG.get("provider") == "aveva-sql" else synthetic_management_review_triggers())
            if parsed.path == "/api/zone-alerts":
                if CONFIG.get("provider") != "aveva-sql":
                    return self.json_response({"generatedAt": datetime.now(timezone.utc).isoformat(), "alerts": [], "provider": "synthetic"})
                state = load_alert_state()
                alerts = [
                    value for value in state.get("zones", {}).values()
                    if value.get("alerted") and line_is_in_production(value.get("line"))
                ]
                alerts.sort(key=lambda row: (row.get("line", ""), row.get("zone", "")))
                return self.json_response({
                    "generatedAt": datetime.now(timezone.utc).isoformat(),
                    "alerts": alerts,
                })
            if parsed.path == "/api/alarms":
                line = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                data, alarms = combined_line_snapshot(line)
                return self.json_response({"line": line, "alarms": alarms, "generatedAt": datetime.now(timezone.utc).isoformat()})
            if parsed.path == "/api/story":
                line = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                data, alarms = combined_line_snapshot(line)
                return self.json_response(build_shift_story(line, data, alarms, []))
            if parsed.path == "/api/interventions":
                line = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                return self.json_response({"line": line, "actions": [], "visualizationOnly": True})
            if parsed.path == "/api/data":
                requested = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                return self.json_response(hourly_live_data(requested) if CONFIG.get("provider") == "aveva-sql" else synthetic_hourly_data(requested))
            if parsed.path == "/api/downtime-current-shift":
                return self.json_response(current_shift_downtime_summary())
            if parsed.path == "/api/downtime-summary":
                q = parse_qs(parsed.query)
                days = int(q.get("days", [30])[0])
                return self.json_response(compile_downtime_summary(days))
            if parsed.path == "/api/history":
                q = parse_qs(parsed.query)
                line = q.get("line", [next(iter(ALL_LINE_MAP))])[0]
                count = int(q.get("count", [60])[0])
                return self.json_response(shift_history_data(line, count))
            if parsed.path == "/api/history-records":
                line = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                return self.json_response(historical_record_summary(line))
            if parsed.path == "/api/history-records/status":
                return self.json_response(dict(HISTORY_SCAN_STATUS))
            if parsed.path == "/api/health":
                return self.json_response(connection_health())
            if parsed.path == "/api/compliance-boundary":
                return self.json_response({"applicationVersion": APP_VERSION, "visualizationOnly": VISUALIZATION_ONLY, "readOnly": True, "machineControl": False, "sourceModification": False, "productDisposition": False, "authoritativeRecord": False, "emailSending": True, "emailConfigurationOnly": True, "operationalRecordEntry": False})
            if parsed.path == "/api/history-records/rebuild":
                return self.json_response(start_historical_rebuild())
            if parsed.path == "/api/settings/email-control":
                config = load_alert_config()
                return self.json_response({"enabled": bool(config.get("enabled", False)), "transport": config.get("transport", "outlook")})
            if parsed.path == "/api/settings/recipients":
                return self.json_response(load_recipients_config())
            if parsed.path == "/api/settings/line-status":
                return self.json_response({"lines": load_line_status()})
            if parsed.path == "/api/settings/targets":
                return self.json_response({"targets": load_line_targets()})
            if parsed.path == "/api/alerts/status":
                config, state = load_alert_config(), load_alert_state()
                return self.json_response({"enabled": bool(config.get("enabled")), "transport": config.get("transport"), "lastRun": state.get("lastRun"), "lastZoneCheck": state.get("lastZoneCheck"), "lastError": state.get("lastError"), "activeZoneAlerts": [value for value in state.get("zones", {}).values() if value.get("alerted") and line_is_in_production(value.get("line"))]})
            return self.send_body("Not found", "text/plain; charset=utf-8", 404)
        except Exception as exc:
            traceback.print_exc()
            return self.json_response({"error": str(exc), "type": type(exc).__name__}, 500)

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            communication_paths = {"/api/settings/email-control", "/api/settings/recipients", "/api/settings/targets", "/api/settings/line-status", "/api/history-records/rebuild"}
            if VISUALIZATION_ONLY and parsed.path not in communication_paths:
                return self.json_response({"error": "Visualization-only mode: manufacturing/operational write operations are disabled", "readOnly": True}, 403)
            length = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(length).decode("utf-8")) if length else {}
            if parsed.path == "/api/alarms":
                line = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                data, alarms = combined_line_snapshot(line)
                return self.json_response({"line": line, "alarms": alarms, "generatedAt": datetime.now(timezone.utc).isoformat()})
            if parsed.path == "/api/story":
                line = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                data, alarms = combined_line_snapshot(line)
                return self.json_response(build_shift_story(line, data, alarms, []))
            if parsed.path == "/api/interventions":
                line = str(payload.get("line", ""))
                if line not in ALL_LINE_MAP:
                    raise ValueError("Invalid line")
                action_text = str(payload.get("action", "")).strip()
                if not action_text:
                    raise ValueError("Action is required")
                timestamp = str(payload.get("timestamp") or datetime.now().isoformat())
                try:
                    datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                except ValueError:
                    raise ValueError("Invalid action timestamp")
                actions = load_interventions()
                actions.append({"id": f"{int(time.time()*1000)}", "line": line, "zone": str(payload.get("zone", "Line"))[:40], "category": str(payload.get("category", "Other"))[:60], "action": action_text[:200], "technician": str(payload.get("technician", ""))[:100], "notes": str(payload.get("notes", ""))[:1000], "timestamp": timestamp, "createdAt": datetime.now(timezone.utc).isoformat()})
                save_interventions(actions[-2000:])
                return self.json_response({"ok": True})
            if parsed.path == "/api/history-records/rebuild":
                return self.json_response(start_historical_rebuild())
            if parsed.path == "/api/settings/email-control":
                raw = load_json(ALERTS_PATH, {})
                raw["enabled"] = bool(payload.get("enabled", False))
                atomic_write_json(ALERTS_PATH, raw)
                return self.json_response({"ok": True, "enabled": raw["enabled"]})
            if parsed.path == "/api/settings/recipients":
                if not isinstance(payload.get("people"), list) or not isinstance(payload.get("groups"), dict):
                    raise ValueError("Invalid recipient configuration")
                for person in payload["people"]:
                    email = str(person.get("email", "")).strip()
                    if "@" not in email:
                        raise ValueError(f"Invalid email address: {email}")
                    person["email"] = email
                atomic_write_json(RECIPIENTS_PATH, payload)
                return self.json_response({"ok": True})
            if parsed.path == "/api/settings/line-status":
                lines = payload.get("lines", {})
                if not isinstance(lines, dict):
                    raise ValueError("Invalid line status configuration")
                cleaned = {line: bool(lines.get(line, True)) for line in ALL_LINE_MAP}
                atomic_write_json(LINE_STATUS_PATH, cleaned)
                # Clear any persisted active zone alerts for lines removed from production.
                state = load_alert_state()
                active = {line for line, enabled in cleaned.items() if enabled}
                state["zones"] = {k:v for k,v in state.get("zones",{}).items() if v.get("line") in active}
                save_alert_state(state)
                return self.json_response({"ok": True, "lines": cleaned})
            if parsed.path == "/api/settings/targets":
                line = str(payload.get("line", ""))
                values = payload.get("values", {})
                if line not in ALL_LINE_MAP or not isinstance(values, dict):
                    raise ValueError("Invalid line or target values")
                targets = load_line_targets()
                current = dict(targets.get(line, {}))
                for key, value in values.items():
                    number = float(value)
                    if number < 0:
                        raise ValueError("Targets cannot be negative")
                    if "YIELD" in key and number > 100:
                        raise ValueError("Yield targets must be between 0 and 100 percent")
                    current[key] = int(number) if number.is_integer() else number
                targets[line] = current
                atomic_write_json(TARGETS_PATH, targets)
                return self.json_response({"ok": True, "line": line, "targets": current})
            return self.send_body("Not found", "text/plain; charset=utf-8", 404)
        except Exception as exc:
            traceback.print_exc()
            return self.json_response({"error": str(exc), "type": type(exc).__name__}, 400)

    def log_message(self, fmt, *args):
        print(f"[{datetime.now().isoformat(timespec='seconds')}] {fmt % args}")


if __name__ == "__main__":
    if VISUALIZATION_ONLY:
        print("VISUALIZATION-ONLY MODE: READ-ONLY MANUFACTURING DATA")
        print("Machine control: NONE | Source modification: NONE | Product disposition: NONE | Operational record creation: NONE")
        print("Communication settings are local to this dashboard and do not write to manufacturing source systems.")
    ALERT_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    startup_alerts = load_json(ALERTS_PATH, {})
    startup_alerts["enabled"] = False
    atomic_write_json(ALERTS_PATH, startup_alerts)
    print("Automatic email sending: OFF (startup safety default)")
    print("Testing configured data sources...")
    health = connection_health()
    print("Production historian:", "CONNECTED" if health["production"].get("ok") else "UNAVAILABLE", "-", health["production"].get("detail", ""))
    alarm_sources=health.get("alarms",{}).get("sources",{})
    if alarm_sources:
        for name,info in alarm_sources.items(): print(f"Alarm DB {name}:", "CONNECTED" if info.get("ok") else "UNAVAILABLE", "-", info.get("server", ""), info.get("database", ""))
    else:
        print("Alarm database:", "CONNECTED" if health["alarms"].get("ok") else "UNAVAILABLE", "-", health["alarms"].get("detail", ""))
    threading.Thread(target=alert_engine, name="heatmap-alert-engine", daemon=True).start()
    print(f"Open http://localhost:{PORT}")
    print(f"Alert configuration: {ALERTS_PATH}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
