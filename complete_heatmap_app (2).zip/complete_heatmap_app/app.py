import json
import os
import random
import smtplib
import ssl
import subprocess
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from html import escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config" / "config.json"
TARGETS_PATH = ROOT / "config" / "targets.json"
ALERTS_PATH = ROOT / "config" / "alerts.json"
ALERT_STATE_PATH = ROOT / "data" / "alert_state.json"


def load_json(path, default):
    try:
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        return value if isinstance(value, dict) else default
    except (OSError, json.JSONDecodeError):
        return default


DEFAULT_CONFIG = {
    "provider": "aveva-sql",
    "host": "127.0.0.1",
    "port": 8080,
    "historyHours": 12,
    "refreshSeconds": 60,
    "legacyLines": [1, 2, 5, 6, 7, 9, 10, 17, 18, 20],
    "flexLines": [24, 25, 26, 27, 28, 29, 30, 31, 32, 33],
    "sql": {
        "driver": os.getenv("WW_SQL_DRIVER", "ODBC Driver 18 for SQL Server"),
        "server": os.getenv("WW_SQL_SERVER", "visusjp3gthist.na.jnj.com"),
        "database": os.getenv("WW_SQL_DATABASE", "Runtime"),
        "usernameEnv": "WW_SQL_USER",
        "passwordEnv": "WW_SQL_PASSWORD",
    },
}

CONFIG = load_json(CONFIG_PATH, {})
if not CONFIG:
    CONFIG = json.loads(json.dumps(DEFAULT_CONFIG))
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(CONFIG, indent=2), encoding="utf-8")
else:
    merged = json.loads(json.dumps(DEFAULT_CONFIG))
    merged.update({key: value for key, value in CONFIG.items() if key != "sql"})
    merged["sql"].update(CONFIG.get("sql", {}))
    CONFIG = merged

HOST = str(CONFIG.get("host", "127.0.0.1"))
PORT = int(CONFIG.get("port", 8080))
HISTORY_HOURS = int(CONFIG.get("historyHours", 12))
REFRESH_SECONDS = int(CONFIG.get("refreshSeconds", 60))

YIELD_TARGETS = {
    "Z2A_YIELD": 98.0,
    "Z3_YIELD": 98.0,
    "Z4_YIELD": 98.0,
    "Z5_YIELD": 95.0,
    "ALI_YIELD": 90.0,
    "Z6_YIELD": 98.0,
    "LINE_YIELD": 90.0,
}

EXCLUDED_LINES = {
    "TAM03", "TAM04", "TAM08", "TAM11", "TAM12", "TAM13",
    "TAM14", "TAM15", "TAM16", "TAM19",
}

LEGACY_PREFIXES = {
    1: "A", 2: "B", 3: "C", 4: "D", 5: "E", 6: "F", 7: "G",
    8: "H", 9: "I", 10: "J", 15: "K", 16: "L", 17: "M",
    18: "N", 19: "O", 20: "P",
}

LEGACY_OVERRIDES = {}
FLEX_OVERRIDES = {
    26: {
        "ALI_IN": "L26_PLC3.EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.Out",
        "ALI_OUT": "L26_PLC3.EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
    },
    27: {
        "ALI_IN": "L27_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In",
        "ALI_OUT": "L27_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
    },
}


def legacy_tags(line_number):
    prefix = LEGACY_PREFIXES.get(line_number)
    if prefix is None:
        raise ValueError(f"No historian prefix defined for TAM{line_number:02d}")
    return {
        "Z1": f"{prefix}P0_GOODCOUNT1",
        "Z2A": f"{prefix}P0_GOODCOUNT2",
        "Z3_IN": f"{prefix}P0_GOODCOUNT6",
        "Z3_OUT": f"{prefix}P1_GOODCOUNT1",
        "Z4_OUT": f"{prefix}P1_GOODCOUNT3",
        "Z5_IN": f"{prefix}P2_INCOUNT2",
        "ALI_IN": f"{prefix}P2_INCOUNT3",
        "ALI_OUT": f"{prefix}P2_OUTCOUNT3",
        "Z6_IN": f"{prefix}P3_LOAD_IN_CNT",
    }


def transition_tags(line_number):
    if line_number not in (21, 22):
        raise ValueError("transition_tags supports TAM21/TAM22 only")
    p1 = f"L{line_number}_P1_Data."
    p3 = f"L{line_number}_P3_Data."
    p4 = f"L{line_number}_P4_Data."
    return {
        "Z1": p1 + "Crv_CountIMMStarts",
        "Z2A": p1 + "GoodCountInlay",
        "Z3_IN": p1 + "GoodCountCure",
        "Z3_OUT": p1 + "GoodCountDemold",
        "Z4_OUT": p1 + "GoodCountFCXfer",
        "Z5_IN": p3 + "InCountLensXfer",
        "ALI_IN": p3 + "OutCountLensXfer",
        "ALI_OUT": p3 + "OutCountDIRemoval",
        "Z6_IN": p4 + "OutCountLoader",
    }


def tam23_tags():
    return {
        "Z1": "SP0_GOODCOUNT1", "Z2A": "SP0_GOODCOUNT2",
        "Z3_IN": "SP0_GOODCOUNT6", "Z3_OUT": "SP1_GOODCOUNT1",
        "Z4_OUT": "SP1_GOODCOUNT3", "Z5_IN": "SP2_INCOUNT2",
        "ALI_IN": "SP2_INCOUNT3", "ALI_OUT": "SP2_OUTCOUNT3",
        "Z6_IN": "SP3_LOAD_IN_CNT",
    }


def flex_tags(line_number):
    p1 = f"L{line_number}_PLC1_"
    p2 = f"L{line_number}_PLC2_"
    p3 = f"L{line_number}_PLC3_"
    p4 = f"L{line_number}_PLC4_"
    if line_number >= 29:
        return {
            "Z1": p1 + "Global.StatsCnt_Z01.CurrS.Total.In",
            "Z2A": p1 + "Global.StatsCnt_Z02.CurrS.Total.In",
            "Z3_IN": p2 + "EM0312_Demold.StatsCnt.CurrS.Total.In",
            "Z3_OUT": p2 + "EM0312_Demold.StatsCnt.CurrS.Total.Out",
            "Z4_IN": p2 + "EM0332_FC_Transfer.StatsCnt.CurrS.Total.In",
            "Z4_OUT": p2 + "EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out",
            "Z5_IN": p3 + "EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In",
            "ALI_IN": p3 + "EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In",
            "ALI_OUT": p3 + "EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
            "Z6_IN": p4 + "EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In",
        }
    return {
        "Z1": p1 + "Global.StatsCnt_Z01.CurrS.Total.In",
        "Z2A": p1 + "Global.StatsCnt_Z02.CurrS.Total.In",
        "Z3_IN": p1 + "EM0304_WB_Demold.StatsCnt.CurrS.Total.In",
        "Z3_OUT": p1 + "EM0304_WB_Demold.StatsCnt.CurrS.Total.Out",
        "Z4_OUT": p1 + "EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out",
        "Z5_IN": p3 + "EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In",
        "ALI_IN": p3 + "EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.In",
        "ALI_OUT": p3 + "EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
        "Z6_IN": p4 + "EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In",
    }


def apply_overrides(tags, overrides, line_number):
    result = dict(tags)
    result.update(overrides.get(line_number, {}))
    return result


SUPPORTED_LEGACY_LINES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 16, 17, 18, 19, 20]
configured_legacy = {int(value) for value in CONFIG.get("legacyLines", SUPPORTED_LEGACY_LINES)}
legacy_numbers = [n for n in SUPPORTED_LEGACY_LINES if n in configured_legacy]
flex_numbers = [int(n) for n in CONFIG.get("flexLines", range(24, 34)) if int(n) >= 24]
LEGACY_MAP = {f"TAM{n:02d}": apply_overrides(legacy_tags(n), LEGACY_OVERRIDES, n) for n in legacy_numbers}
TRANSITION_MAP = {
    "TAM21": transition_tags(21), "TAM22": transition_tags(22), "TAM23": tam23_tags()
}
FLEX_MAP = {f"TAM{n:02d}": apply_overrides(flex_tags(n), FLEX_OVERRIDES, n) for n in flex_numbers}
ALL_LINE_MAP = {
    line: tags for line, tags in {**LEGACY_MAP, **TRANSITION_MAP, **FLEX_MAP}.items()
    if line not in EXCLUDED_LINES
}


def load_line_targets():
    return load_json(TARGETS_PATH, {})


def safe_yield(output_value, input_value):
    if not isinstance(input_value, (int, float)) or input_value == 0:
        return None
    if not isinstance(output_value, (int, float)):
        return None
    return round(output_value / input_value * 100.0, 2)


def counter_delta(start_value, end_value):
    if start_value is None or end_value is None:
        return None
    return end_value - start_value if end_value >= start_value else end_value


def calculate_columns(values):
    return {
        "Z1": values.get("Z1"),
        "Z2A_YIELD": safe_yield(values.get("Z2A"), values.get("Z1")),
        "Z2A": values.get("Z2A"),
        "Z3_IN": values.get("Z3_IN"),
        "Z3_YIELD": safe_yield(values.get("Z3_OUT"), values.get("Z3_IN")),
        "Z3_OUT": values.get("Z3_OUT"),
        "Z4_YIELD": safe_yield(values.get("Z4_OUT"), values.get("Z3_OUT")),
        "Z4_OUT": values.get("Z4_OUT"),
        "Z5_YIELD": safe_yield(values.get("Z5_IN"), values.get("Z4_OUT")),
        "Z5_IN": values.get("Z5_IN"),
        "ALI_IN": values.get("ALI_IN"),
        "ALI_YIELD": safe_yield(values.get("ALI_OUT"), values.get("ALI_IN")),
        "ALI_OUT": values.get("ALI_OUT"),
        "Z6_YIELD": safe_yield(values.get("Z6_IN"), values.get("ALI_OUT")),
        "Z6_IN": values.get("Z6_IN"),
        "LINE_YIELD": safe_yield(values.get("Z6_IN"), values.get("Z1")),
    }


def format_hour(value):
    return value.strftime("%#I:%M %p") if os.name == "nt" else value.strftime("%-I:%M %p")


def build_connection_string():
    sql = dict(CONFIG["sql"])
    sql["driver"] = os.getenv("WW_SQL_DRIVER", sql.get("driver", "ODBC Driver 18 for SQL Server"))
    sql["server"] = os.getenv("WW_SQL_SERVER", sql.get("server", ""))
    sql["database"] = os.getenv("WW_SQL_DATABASE", sql.get("database", "Runtime"))
    username_env = sql.get("usernameEnv", "WW_SQL_USER")
    password_env = sql.get("passwordEnv", "WW_SQL_PASSWORD")
    username = os.getenv(username_env)
    password = os.getenv(password_env)
    if not username or not password:
        raise RuntimeError(f"Set {username_env} and {password_env} before starting app.py")
    return (
        f"DRIVER={{{sql['driver']}}};SERVER={sql['server']};DATABASE={sql['database']};"
        f"UID={username};PWD={password};TrustServerCertificate=yes;"
    )


def query_live(cursor, tag):
    cursor.execute("SELECT TOP 1 DateTime, Value, Quality, QualityDetail FROM Runtime.dbo.AnalogLive WHERE TagName = ?", tag)
    row = cursor.fetchone()
    if row is None:
        return None
    return {"timestamp": row[0], "value": None if row[1] is None else float(row[1]), "quality": row[2], "qualityDetail": row[3]}


def query_delta_values(cursor, tag, start_time, end_time):
    cursor.execute("""
        SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory
        WHERE TagName = ? AND DateTime >= ? AND DateTime <= ?
          AND wwRetrievalMode = 'Delta'
        ORDER BY DateTime
    """, tag, start_time, end_time)
    return [(row[0], None if row[1] is None else float(row[1])) for row in cursor.fetchall()]


def query_boundaries(cursor, tag, start_time, end_time):
    cursor.execute("""
        SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory
        WHERE TagName = ? AND DateTime >= ? AND DateTime <= ?
          AND wwRetrievalMode = 'Cyclic' AND wwResolution = 3600000
        ORDER BY DateTime
    """, tag, start_time, end_time)
    return {row[0].replace(minute=0, second=0, microsecond=0): (None if row[1] is None else float(row[1])) for row in cursor.fetchall()}


def accumulated_counter_delta(samples):
    usable = [(stamp, value) for stamp, value in samples if isinstance(value, (int, float))]
    if len(usable) < 2:
        return None
    total = 0.0
    previous = usable[0][1]
    for _, current in usable[1:]:
        total += current - previous if current >= previous else current
        previous = current
    return round(total, 2)


def current_shift_start(now):
    six = now.replace(hour=6, minute=0, second=0, microsecond=0)
    eighteen = now.replace(hour=18, minute=0, second=0, microsecond=0)
    if now >= eighteen:
        return eighteen
    if now >= six:
        return six
    return six - timedelta(hours=12)


def query_loader_shift_metrics(cursor, loader_tag, now):
    shift_start = current_shift_start(now)
    previous_start = shift_start - timedelta(hours=12)
    last_shift = accumulated_counter_delta(query_delta_values(cursor, loader_tag, previous_start, shift_start))
    current_samples = query_delta_values(cursor, loader_tag, shift_start, now)
    live = query_live(cursor, loader_tag)
    effective_now = now
    if live and isinstance(live["value"], (int, float)):
        effective_now = live["timestamp"]
        if not current_samples or current_samples[-1][0] < live["timestamp"]:
            current_samples.append((live["timestamp"], live["value"]))
    actual = accumulated_counter_delta(current_samples)
    elapsed = max((effective_now - shift_start).total_seconds(), 0.0)
    projection = round(actual / elapsed * 43200, 2) if isinstance(actual, (int, float)) and elapsed > 0 else None
    return last_shift, actual, projection


def all_lines_shift_overview():
    import pyodbc
    now = datetime.now()
    targets = load_line_targets()
    rows = []
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for line, tags in ALL_LINE_MAP.items():
            goal = targets.get(line, {}).get("SHIFT_GOAL")
            last_shift = actual = projection = None
            error = None
            try:
                last_shift, actual, projection = query_loader_shift_metrics(cursor, tags["Z6_IN"], now)
            except Exception as exc:
                error = str(exc)
            attainment = gap = None
            if isinstance(projection, (int, float)) and isinstance(goal, (int, float)) and goal > 0:
                attainment = round(projection / goal * 100.0, 2)
                gap = round(projection - goal, 2)
            rows.append({"line": line, "lastShift": last_shift, "currentActual": actual, "currentProjection": projection, "goal": goal, "attainment": attainment, "gap": gap, "error": error})
    rows.sort(key=lambda row: (row["attainment"] is None, row["attainment"] if row["attainment"] is not None else 999999, row["line"]))
    return {"generatedAt": datetime.now(timezone.utc).isoformat(), "shiftStart": current_shift_start(now).isoformat(), "rows": rows}


def completed_shift_history(cursor, loader_tag, shift_start, count=60):
    history_start = shift_start - timedelta(hours=12 * count)
    boundaries = query_boundaries(cursor, loader_tag, history_start, shift_start)
    records = []
    for index in range(count):
        start = history_start + timedelta(hours=12 * index)
        total = 0.0
        valid = 0
        for hour_index in range(12):
            hour_start = start + timedelta(hours=hour_index)
            delta = counter_delta(boundaries.get(hour_start), boundaries.get(hour_start + timedelta(hours=1)))
            if isinstance(delta, (int, float)):
                total += delta
                valid += 1
        if valid == 12:
            records.append({"start": start, "end": start + timedelta(hours=12), "value": round(total, 2)})
    records.reverse()
    return records


def query_shift_summary(cursor, tags, now, shift_goal=None):
    loader_tag = tags.get("Z6_IN")
    if not loader_tag:
        return []
    shift_start = current_shift_start(now)
    samples = query_delta_values(cursor, loader_tag, shift_start, now)
    live = query_live(cursor, loader_tag)
    effective_now = now
    if live and isinstance(live["value"], (int, float)):
        effective_now = live["timestamp"]
        if not samples or samples[-1][0] < live["timestamp"]:
            samples.append((live["timestamp"], live["value"]))
    actual = accumulated_counter_delta(samples)
    elapsed = max((effective_now - shift_start).total_seconds(), 0.0)
    remaining = max(43200 - elapsed, 0.0)
    hourly_rate = round(actual / elapsed * 3600, 2) if isinstance(actual, (int, float)) and elapsed > 0 else None
    projected_remaining = round(actual / elapsed * remaining, 2) if isinstance(actual, (int, float)) and elapsed > 0 else None
    projected_total = round(actual + projected_remaining, 2) if isinstance(actual, (int, float)) and isinstance(projected_remaining, (int, float)) else None
    completed = completed_shift_history(cursor, loader_tag, shift_start, 60)

    def average_last(count):
        values = [row["value"] for row in completed[:count]]
        return round(sum(values) / len(values), 2) if values else None

    below = above = None
    if isinstance(shift_goal, (int, float)) and shift_goal > 0:
        below = 0
        for row in completed:
            if row["value"] < shift_goal:
                below += 1
            else:
                break
        above = 0
        for row in completed:
            if row["value"] >= shift_goal:
                above += 1
            else:
                break
    attainment = round(projected_total / shift_goal * 100, 2) if isinstance(projected_total, (int, float)) and isinstance(shift_goal, (int, float)) and shift_goal > 0 else None
    detail = f"{format_hour(shift_start)} to {format_hour(shift_start + timedelta(hours=12))}"
    if isinstance(actual, (int, float)) and isinstance(hourly_rate, (int, float)):
        detail += f" | Actual {round(actual):,} | Rate {round(hourly_rate):,}/hr"
    rows = [{"label": "Current Shift Projection", "shiftWindow": detail, "value": projected_total, "format": "count"}]
    if isinstance(shift_goal, (int, float)):
        rows += [
            {"label": "Shift Goal", "shiftWindow": "Configured Loader In goal", "value": shift_goal, "format": "count"},
            {"label": "Projected Attainment", "shiftWindow": "Projection versus shift goal", "value": attainment, "format": "percent"},
        ]
    rows += [
        {"label": "5 Shift Average", "shiftWindow": "Last 5 completed shifts", "value": average_last(5), "format": "count"},
        {"label": "14 Shift Average", "shiftWindow": "Last 14 completed shifts", "value": average_last(14), "format": "count"},
        {"label": "20 Shift Average", "shiftWindow": "Last 20 completed shifts", "value": average_last(20), "format": "count"},
        {"label": "Consecutive Shifts Below Goal", "shiftWindow": "Most recent completed shifts below configured goal", "value": below, "format": "integer"},
        {"label": "Consecutive Shifts Above Goal", "shiftWindow": "Most recent completed shifts meeting or exceeding configured goal", "value": above, "format": "integer"},
        {"label": "30 Day Average", "shiftWindow": "Last 60 completed shifts", "value": average_last(60), "format": "count"},
    ]
    return rows


def management_review_triggers():
    import pyodbc
    now = datetime.now()
    shift_start = current_shift_start(now)
    targets = load_line_targets()
    results = []
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for line, tags in ALL_LINE_MAP.items():
            goal = targets.get(line, {}).get("SHIFT_GOAL")
            loader_tag = tags.get("Z6_IN")
            if not isinstance(goal, (int, float)) or goal <= 0 or not loader_tag:
                continue
            try:
                completed = completed_shift_history(cursor, loader_tag, shift_start, 60)
            except Exception as exc:
                results.append({"tier": "Error", "line": line, "error": str(exc)})
                continue
            consecutive_red = 0
            for row in completed:
                if row["value"] < goal:
                    consecutive_red += 1
                else:
                    break
            if consecutive_red < 2 or not completed:
                continue
            tier = "Tier 3" if consecutive_red >= 8 else "Tier 2" if consecutive_red >= 5 else "Tier 1"
            last = completed[0]
            last_green = next((row for row in completed if row["value"] >= goal), None)
            results.append({
                "tier": tier, "line": line, "consecutiveRedShifts": consecutive_red,
                "lastCompletedShift": last["value"], "goal": goal,
                "gap": round(last["value"] - goal, 2),
                "lastKnownGreenShift": None if last_green is None else last_green["value"],
                "lastGreenEnd": None if last_green is None else last_green["end"].isoformat(),
            })
    tier_rank = {"Tier 3": 3, "Tier 2": 2, "Tier 1": 1, "Error": 0}
    results.sort(key=lambda row: (-tier_rank.get(row["tier"], 0), -row.get("consecutiveRedShifts", 0), row["line"]))
    return {"generatedAt": datetime.now(timezone.utc).isoformat(), "rows": results}


def hourly_live_data(selected_line):
    import pyodbc
    if selected_line not in ALL_LINE_MAP:
        raise ValueError(f"Unknown TAM line: {selected_line}")
    tags = ALL_LINE_MAP[selected_line]
    targets = load_line_targets().get(selected_line, {})
    now = datetime.now()
    current_hour = now.replace(minute=0, second=0, microsecond=0)
    first_boundary = current_hour - timedelta(hours=HISTORY_HOURS)
    boundaries, live_values, missing = {}, {}, []
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for key, tag in tags.items():
            boundaries[key] = query_boundaries(cursor, tag, first_boundary, current_hour)
            live_values[key] = query_live(cursor, tag)
            if not boundaries[key] and live_values[key] is None:
                missing.append(tag)
        summary = query_shift_summary(cursor, tags, now, targets.get("SHIFT_GOAL"))
    periods = []
    for offset in range(HISTORY_HOURS - 1, -1, -1):
        start = first_boundary + timedelta(hours=offset)
        end = start + timedelta(hours=1)
        values = {key: counter_delta(boundaries[key].get(start), boundaries[key].get(end)) for key in tags}
        periods.append({"label": f"{format_hour(start)} to {format_hour(end)}", "start": start.isoformat(), "end": end.isoformat(), "isLiveHour": False, "columns": calculate_columns(values)})
    live_metrics = {}
    live_end = now
    for key in tags:
        record = live_values[key]
        value = None if record is None else record["value"]
        if record and record["timestamp"] > live_end:
            live_end = record["timestamp"]
        live_metrics[key] = counter_delta(boundaries[key].get(current_hour), value)
    periods.insert(0, {"label": "Current Hour", "start": current_hour.isoformat(), "end": live_end.isoformat(), "isLiveHour": True, "columns": calculate_columns(live_metrics)})
    return {
        "provider": "aveva-sql-hourly", "generatedAt": datetime.now(timezone.utc).isoformat(),
        "selectedLine": selected_line, "availableLines": list(ALL_LINE_MAP),
        "historyHours": HISTORY_HOURS, "refreshSeconds": REFRESH_SECONDS,
        "targets": YIELD_TARGETS, "hourlyTargets": targets, "shiftGoal": targets.get("SHIFT_GOAL"),
        "tags": tags, "missingTags": missing, "periods": periods, "shiftSummary": summary,
    }


def synthetic_hourly_data(selected_line):
    if selected_line not in ALL_LINE_MAP:
        selected_line = next(iter(ALL_LINE_MAP))
    targets = load_line_targets().get(selected_line, {})
    now = datetime.now()
    current_hour = now.replace(minute=0, second=0, microsecond=0)
    periods = []
    for offset in range(HISTORY_HOURS):
        start = current_hour - timedelta(hours=offset + 1)
        z1 = random.randint(10000, 11200)
        values = {"Z1": z1, "Z2A": int(z1 * .98), "Z3_IN": int(z1 * .96)}
        values.update({"Z3_OUT": int(values["Z3_IN"] * .98), "Z4_OUT": int(values["Z3_IN"] * .96)})
        values.update({"Z5_IN": int(values["Z4_OUT"] * .96), "ALI_IN": int(values["Z4_OUT"] * .95)})
        values.update({"ALI_OUT": int(values["ALI_IN"] * .90), "Z6_IN": int(values["ALI_IN"] * .88)})
        periods.append({"label": f"{format_hour(start)} to {format_hour(start + timedelta(hours=1))}", "start": start.isoformat(), "end": (start + timedelta(hours=1)).isoformat(), "isLiveHour": False, "columns": calculate_columns(values)})
    periods.insert(0, dict(periods[0], label="Current Hour", isLiveHour=True))
    return {"provider": "synthetic-hourly", "generatedAt": datetime.now(timezone.utc).isoformat(), "selectedLine": selected_line, "availableLines": list(ALL_LINE_MAP), "historyHours": HISTORY_HOURS, "refreshSeconds": REFRESH_SECONDS, "targets": YIELD_TARGETS, "hourlyTargets": targets, "shiftGoal": targets.get("SHIFT_GOAL"), "tags": ALL_LINE_MAP[selected_line], "missingTags": [], "periods": periods, "shiftSummary": []}


DEFAULT_ALERT_CONFIG = {
    "enabled": False,
    "transport": "outlook",
    "fromAddress": "",
    "performanceRecipients": [],
    "zoneRecipients": [],
    "performanceThresholdPercent": 95.0,
    "performanceStartHourIntoShift": 2,
    "zoneIdleMinutes": 15,
    "zoneCheckMinutes": 5,
    "zoneKeys": ["Z1", "Z2A", "Z3_OUT", "Z4_OUT", "Z5_IN", "ALI_OUT", "Z6_IN"],
    "sendRecoveryEmails": True,
    "smtp": {"host": "", "port": 587, "startTls": True, "usernameEnv": "ALERT_SMTP_USER", "passwordEnv": "ALERT_SMTP_PASSWORD"},
}


def load_alert_config():
    config = dict(DEFAULT_ALERT_CONFIG)
    raw = load_json(ALERTS_PATH, {})
    config.update({key: value for key, value in raw.items() if key != "smtp"})
    smtp = dict(DEFAULT_ALERT_CONFIG["smtp"])
    smtp.update(raw.get("smtp", {}))
    config["smtp"] = smtp
    return config


def load_alert_state():
    state = load_json(ALERT_STATE_PATH, {})
    state.setdefault("performanceSent", {})
    state.setdefault("zones", {})
    state.setdefault("lastRun", None)
    state.setdefault("lastError", None)
    return state


def save_alert_state(state):
    ALERT_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = ALERT_STATE_PATH.with_suffix(".tmp")
    temp.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")
    temp.replace(ALERT_STATE_PATH)


def send_outlook_email(recipients, subject, body, is_html=False):
    script = r'''
$ErrorActionPreference = 'Stop'
$outlook = New-Object -ComObject Outlook.Application
$mail = $outlook.CreateItem(0)
$mail.To = $env:HEATMAP_MAIL_TO
$mail.Subject = $env:HEATMAP_MAIL_SUBJECT
if ($env:HEATMAP_MAIL_IS_HTML -eq '1') { $mail.HTMLBody = $env:HEATMAP_MAIL_BODY } else { $mail.Body = $env:HEATMAP_MAIL_BODY }
$mail.Send()
'''
    env = os.environ.copy()
    env.update({"HEATMAP_MAIL_TO": ";".join(recipients), "HEATMAP_MAIL_SUBJECT": subject, "HEATMAP_MAIL_BODY": body, "HEATMAP_MAIL_IS_HTML": "1" if is_html else "0"})
    subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", script], check=True, capture_output=True, text=True, env=env)


def send_smtp_email(config, recipients, subject, body, is_html=False):
    smtp = config["smtp"]
    message = EmailMessage()
    message["Subject"], message["From"], message["To"] = subject, config.get("fromAddress") or os.getenv("ALERT_FROM_ADDRESS", ""), ", ".join(recipients)
    if is_html:
        message.set_content("This message contains an HTML manufacturing performance table.")
        message.add_alternative(body, subtype="html")
    else:
        message.set_content(body)
    username = os.getenv(smtp.get("usernameEnv", "ALERT_SMTP_USER"), "")
    password = os.getenv(smtp.get("passwordEnv", "ALERT_SMTP_PASSWORD"), "")
    with smtplib.SMTP(smtp["host"], int(smtp.get("port", 587)), timeout=30) as client:
        if smtp.get("startTls", True):
            client.starttls(context=ssl.create_default_context())
        if username:
            client.login(username, password)
        client.send_message(message)


def send_email(config, recipients, subject, body, is_html=False):
    recipients = [str(item).strip() for item in recipients if str(item).strip()]
    if not recipients:
        raise RuntimeError("No recipients configured for alert")
    if config.get("transport", "outlook").lower() == "smtp":
        send_smtp_email(config, recipients, subject, body, is_html)
    else:
        send_outlook_email(recipients, subject, body, is_html)


def performance_alert_due(now, config, state):
    if (now - current_shift_start(now)).total_seconds() / 3600 < float(config.get("performanceStartHourIntoShift", 2)):
        return None
    key = now.replace(minute=0, second=0, microsecond=0).isoformat()
    return None if key in state["performanceSent"] else key


def run_performance_alert(now, config, state):
    key = performance_alert_due(now, config, state)
    if key is None:
        return
    overview = all_lines_shift_overview()
    threshold = float(config.get("performanceThresholdPercent", 95.0))
    goal_rows = [row for row in overview["rows"] if isinstance(row.get("goal"), (int, float)) and row["goal"] > 0]
    total_goal = sum(row["goal"] for row in goal_rows)
    total_projection = sum(row["currentProjection"] if isinstance(row.get("currentProjection"), (int, float)) else 0 for row in goal_rows)
    overall_attainment = total_projection / total_goal * 100 if total_goal else None
    overall_gap = total_projection - total_goal if total_goal else None
    low = sorted([row for row in goal_rows if isinstance(row.get("attainment"), (int, float)) and row["attainment"] < threshold], key=lambda row: (row["attainment"], row["line"]))
    if not low:
        state["performanceSent"][key] = {"sent": False, "reason": "No lines below threshold"}
        save_alert_state(state)
        return
    count = lambda value: f"{round(value):,}" if isinstance(value, (int, float)) else "No data"
    pct = lambda value: f"{value:.1f}%" if isinstance(value, (int, float)) else "No data"
    gap = lambda value: f"{round(value):+,}" if isinstance(value, (int, float)) else "No data"
    rows = "".join(f'''<tr style="background:{'#fff2f2' if row['attainment'] < 90 else '#fff9db'}"><td>{escape(row['line'])}</td><td>{count(row['currentProjection'])}</td><td>{count(row['goal'])}</td><td>{pct(row['attainment'])}</td><td>{gap(row['gap'])}</td></tr>''' for row in low)
    overall_color = "#16a34a" if overall_attainment and overall_attainment >= 98 else "#eab308" if overall_attainment and overall_attainment >= 95 else "#dc2626"
    html = f'''<html><body style="font-family:Segoe UI,Arial"><h2>3GT Manufacturing Shift Projection Alert</h2><p><b>Generated:</b> {now:%Y-%m-%d %I:%M %p}<br><b>Shift:</b> {current_shift_start(now):%I:%M %p} to {(current_shift_start(now)+timedelta(hours=12)):%I:%M %p}<br><b>Threshold:</b> below {threshold:.1f}%</p><table style="border-collapse:collapse;width:100%"><tr><td style="padding:12px;border:1px solid #ccc"><b>Overall Projection</b><br>{count(total_projection)}</td><td style="padding:12px;border:1px solid #ccc"><b>Overall Goal</b><br>{count(total_goal)}</td><td style="padding:12px;border:1px solid #ccc;background:{overall_color};color:white"><b>Overall Attainment</b><br>{pct(overall_attainment)}</td><td style="padding:12px;border:1px solid #ccc"><b>Overall Gap</b><br>{gap(overall_gap)}</td></tr></table><h3>All Lines Below {threshold:.1f}% ({len(low)})</h3><table style="border-collapse:collapse;width:100%"><tr style="background:#1f4e78;color:white"><th>Line</th><th>Projection</th><th>Goal</th><th>Attainment</th><th>Gap</th></tr>{rows}</table></body></html>'''
    send_email(config, config.get("performanceRecipients", []), f"3GT Shift Alert: {len(low)} line(s) below {threshold:.0f}% | Overall {pct(overall_attainment)}", html, True)
    state["performanceSent"][key] = {"sent": True, "lines": [row["line"] for row in low], "overallProjection": total_projection, "overallGoal": total_goal, "overallAttainment": overall_attainment}
    for old_key in sorted(state["performanceSent"])[:-72]:
        state["performanceSent"].pop(old_key, None)
    save_alert_state(state)


def zone_activity(cursor, tag, now, minutes):
    start = now - timedelta(minutes=minutes)
    cursor.execute("""
        SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory
        WHERE TagName = ? AND DateTime >= ? AND DateTime <= ?
          AND wwRetrievalMode = 'Cyclic' AND wwResolution = 60000
        ORDER BY DateTime
    """, tag, start, now)
    samples = [(row[0], None if row[1] is None else float(row[1])) for row in cursor.fetchall()]
    live = query_live(cursor, tag)
    if live and isinstance(live["value"], (int, float)) and (not samples or samples[-1][0] < live["timestamp"]):
        samples.append((live["timestamp"], live["value"]))
    return {"delta": accumulated_counter_delta(samples), "start": start, "end": now}


def run_zone_alerts(now, config, state):
    import pyodbc
    minutes = int(config.get("zoneIdleMinutes", 15))
    if (now - current_shift_start(now)).total_seconds() < minutes * 60:
        return
    with pyodbc.connect(build_connection_string(), timeout=15, autocommit=True) as connection:
        cursor = connection.cursor()
        for line, tags in ALL_LINE_MAP.items():
            for zone in config.get("zoneKeys", DEFAULT_ALERT_CONFIG["zoneKeys"]):
                tag = tags.get(zone)
                if not tag:
                    continue
                key = f"{line}|{zone}"
                try:
                    activity = zone_activity(cursor, tag, now, minutes)
                except Exception as exc:
                    state["zones"].setdefault(key, {})["lastError"] = str(exc)
                    continue
                delta, prior = activity["delta"], state["zones"].get(key, {})
                if delta is None:
                    state["zones"][key] = {**prior, "line": line, "zone": zone, "tag": tag, "dataAvailable": False, "lastChecked": now.isoformat()}
                    continue
                idle = delta <= 0
                if idle and not prior.get("alerted"):
                    body = f"3GT Heatmap zone inactivity alert\n\nLine: {line}\nZone: {zone}\nTag: {tag}\nProduction in last {minutes} minutes: {delta:,.0f}\nWindow: {activity['start']:%I:%M %p} to {activity['end']:%I:%M %p}"
                    send_email(config, config.get("zoneRecipients", []), f"3GT Zone Alert: {line} {zone} produced zero lenses for {minutes} minutes", body)
                    state["zones"][key] = {"line": line, "zone": zone, "tag": tag, "alerted": True, "idleSince": activity["start"].isoformat(), "lastChecked": now.isoformat(), "lastDelta": delta}
                elif not idle and prior.get("alerted"):
                    if config.get("sendRecoveryEmails", True):
                        send_email(config, config.get("zoneRecipients", []), f"3GT Zone Recovery: {line} {zone} production resumed", f"Production resumed.\n\nLine: {line}\nZone: {zone}\nTag: {tag}\nProduction in latest {minutes} minutes: {delta:,.0f}")
                    state["zones"][key] = {"line": line, "zone": zone, "tag": tag, "alerted": False, "recovered": now.isoformat(), "lastChecked": now.isoformat(), "lastDelta": delta}
                else:
                    state["zones"][key] = {**prior, "line": line, "zone": zone, "tag": tag, "alerted": bool(prior.get("alerted") and idle), "lastChecked": now.isoformat(), "lastDelta": delta}
    save_alert_state(state)


def alert_engine():
    state = load_alert_state()
    while True:
        config = load_alert_config()
        now = datetime.now()
        if config.get("enabled", False) and CONFIG.get("provider") == "aveva-sql":
            try:
                run_performance_alert(now, config, state)
                last = state.get("lastZoneCheck")
                if not last or now - datetime.fromisoformat(last) >= timedelta(minutes=int(config.get("zoneCheckMinutes", 5))):
                    run_zone_alerts(now, config, state)
                    state["lastZoneCheck"] = now.isoformat()
                state["lastRun"], state["lastError"] = now.isoformat(), None
            except Exception as exc:
                traceback.print_exc()
                state["lastRun"], state["lastError"] = now.isoformat(), f"{type(exc).__name__}: {exc}"
            save_alert_state(state)
        time.sleep(60)


INDEX_HTML = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>3GT Hourly Heatmap</title>
<style>
:root{--bg:#101318;--panel:#171c24;--head:#303030;--grid:#3b424c;--text:#eee;--muted:#aeb5bf;--green:#04e51b;--yellow:#fff000;--red:#ff1212;--nodata:#4a586d;--period:#202a38}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;background:var(--bg);color:var(--text);font-family:Segoe UI,Arial,sans-serif}body{display:flex;flex-direction:column;overflow:hidden}header{height:78px;flex:0 0 78px;background:#262626;padding:10px 12px}h1{font-size:20px;margin:0}.controls{display:flex;gap:14px;align-items:center;margin-top:8px}.meta{font-size:12px;color:var(--muted)}select{background:#162238;color:white;border:1px solid #64748b;padding:6px 10px}.wrap{flex:1;min-height:0;padding:8px;display:grid;grid-template-rows:minmax(170px,24vh) minmax(280px,1fr) minmax(145px,20vh) minmax(135px,18vh);gap:8px;overflow:hidden}.panel{min-height:0;display:flex;flex-direction:column;overflow:hidden;border:1px solid var(--grid);background:var(--panel)}.panel-title{height:34px;flex:0 0 34px;padding:7px 8px;font-size:16px;font-weight:600;border-bottom:1px solid var(--grid)}.scroll{flex:1;min-height:0;overflow:auto}#main-content{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:8px}table{border-collapse:collapse;width:100%;table-layout:fixed}th,td{border:1px solid var(--grid);padding:5px;text-align:right;white-space:nowrap}thead th{position:sticky;top:0;background:var(--head);z-index:5}.left,.period{text-align:left}.period{background:var(--period);font-weight:600}.green{background:var(--green);color:#102010}.yellow,.count{background:var(--yellow);color:#222}.red{background:var(--red);color:white}.nodata{background:var(--nodata)}#overview{min-width:900px}#heatmap{width:100%;table-layout:fixed}#heatmap th,#heatmap td{font-size:10px;padding:1px 2px;overflow:hidden;text-overflow:ellipsis}#heatmap th:first-child,#heatmap td:first-child{width:128px}#zoneAlerts{min-width:980px}.zone-alert-row{background:#4c1515;color:#fff}.zone-alert-line{font-weight:700;color:#7dd3fc;cursor:pointer;text-align:left}.overview-line{color:#7dd3fc;font-weight:700;cursor:pointer;text-align:left}.overview-selected{outline:2px solid #6ee7ff;outline-offset:-2px}.gap-positive{color:#86efac}.gap-negative{color:#fca5a5}.summary-sub{display:block;font-size:10px;opacity:.75;margin-top:2px}#summary th:first-child,#summary td:first-child{width:62%}#reviewTriggers{min-width:1100px}.tier1{background:#fef3c7;color:#111}.tier2{background:#fed7aa;color:#111}.tier3{background:#fecaca;color:#111;font-weight:700}.empty{text-align:center;padding:18px;color:var(--muted)}
</style></head><body>
<header><h1>3GT TAM Hour-by-Hour Zone Flow Heatmap</h1><div class="controls"><label>Line <select id="line"></select></label><span id="meta" class="meta">Loading...</span><span id="alert-meta" class="meta">Alerts loading...</span></div></header>
<div class="wrap">
<section class="panel"><div class="panel-title">All Lines Loader Shift Performance <span id="overview-meta" class="meta"></span></div><div class="scroll"><table id="overview"></table></div></section>
<section id="main-content"><div class="panel"><div class="panel-title">Selected Line Hourly Performance</div><div class="scroll"><table id="heatmap"></table></div></div><aside class="panel"><div class="panel-title">Shift Performance Summary</div><div class="scroll"><table id="summary"></table></div></aside></section>
<section class="panel"><div class="panel-title">Management Review Triggers <span class="meta">Tier 1: 2-4 red shifts | Tier 2: 5-7 | Tier 3: 8+</span></div><div class="scroll"><table id="reviewTriggers"></table></div></section>
<section class="panel"><div class="panel-title">Active Zone Alerts <span id="zone-alert-meta" class="meta">Loading...</span></div><div class="scroll"><table id="zoneAlerts"></table></div></section>
</div>
<script>
const cols=[['PERIOD','Period','period'],['Z1','Z1','count'],['Z2A_YIELD','Z2A Yield','yield'],['Z2A','Z2A','count'],['Z3_IN','Z3 In','count'],['Z3_YIELD','Z3 Yield','yield'],['Z3_OUT','Z3 Out','count'],['Z4_YIELD','Z4 Yield','yield'],['Z4_OUT','Z4 Out','count'],['Z5_YIELD','Z5 Yield','yield'],['Z5_IN','Z5 In','count'],['ALI_IN','ALI In','count'],['ALI_YIELD','ALI Yield','yield'],['ALI_OUT','ALI Out','count'],['Z6_YIELD','Z6 Yield','yield'],['Z6_IN','Z6 In','count'],['LINE_YIELD','Line Yield','yield']];
let targets={},hourlyTargets={};
function fmt(v,type='count'){if(v==null)return'No data';return type==='yield'?Number(v).toFixed(2)+'%':Math.round(v).toLocaleString()}
function attainmentClass(v){if(v==null||!Number.isFinite(Number(v)))return'nodata';if(Number(v)>98)return'green';if(Number(v)>=95)return'yellow';return'red'}
function classStyle(c){if(c==='green')return'background:#04e51b;color:#102010';if(c==='yellow')return'background:#fff000;color:#222';if(c==='red')return'background:#ff1212;color:#fff';if(c==='nodata')return'background:#4a586d;color:#fff';return'background:#fff000;color:#222'}
function effectiveTarget(k,p){const n=Number(hourlyTargets[k]);if(!Number.isFinite(n)||n<=0)return null;if(!p.isLiveHour)return n;return n*Math.min(Math.max((new Date(p.end)-new Date(p.start))/3600000,0),1)}
function cellClass(k,v,p,type){if(v==null)return'nodata';if(type==='yield'){const t=targets[k]??98;return v>=t?'green':v>=t-3?'yellow':'red'}const t=effectiveTarget(k,p);return t==null?'count':attainmentClass(v/t*100)}
function escapeAttr(value){return String(value??'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function cellTip(k,v,p,type){if(v==null)return'No data';if(type==='yield'){const target=Number(targets[k]??98);return `Yield: ${fmt(v,type)} | Target: ${target.toFixed(1)}%`}const target=effectiveTarget(k,p);if(target==null||target<=0)return `Actual: ${fmt(v)} | Target not set`;const attainment=Number(v)/target*100;return `Actual: ${fmt(v)} | Target: ${Math.round(target).toLocaleString()} | Attainment: ${attainment.toFixed(1)}%`}
function gapText(v){if(v==null)return'No data';const n=Math.round(v);return`${n>0?'+':''}${n.toLocaleString()}`}
async function getJson(url){const r=await fetch(url,{cache:'no-store'});const d=await r.json();if(!r.ok||d.error)throw new Error(d.error||'Request failed');return d}
async function loadOverview(){const d=await getJson('/api/overview');let h='<thead><tr><th>Line</th><th>Last Shift</th><th>Current Projection</th><th>Goal</th><th>Attainment</th><th>Gap</th></tr></thead><tbody>';for(const r of d.rows){const c=attainmentClass(r.attainment);const lc=attainmentClass(r.lastShift!=null&&Number(r.goal)>0?r.lastShift/r.goal*100:null);const selected=r.line===document.getElementById('line').value?' overview-selected':'';h+=`<tr class="${selected}"><td class="overview-line" onclick="selectLine('${r.line}')">${r.line}</td><td style="${classStyle(lc)}">${fmt(r.lastShift)}</td><td style="${classStyle(c)}">${fmt(r.currentProjection)}</td><td>${fmt(r.goal)}</td><td style="${classStyle(c)}">${r.attainment==null?'No goal':Number(r.attainment).toFixed(1)+'%'}</td><td class="${r.gap!=null&&r.gap>=0?'gap-positive':'gap-negative'}">${gapText(r.gap)}</td></tr>`}document.getElementById('overview').innerHTML=h+'</tbody>';document.getElementById('overview-meta').textContent=`Updated ${new Date(d.generatedAt).toLocaleTimeString()} | lowest attainment first`}
async function load(){const sel=document.getElementById('line');const selected=sel.value||'TAM01';const d=await getJson('/api/data?line='+encodeURIComponent(selected));targets=d.targets||{};hourlyTargets=d.hourlyTargets||{};if(!sel.options.length){d.availableLines.forEach(x=>sel.add(new Option(x,x)));sel.value=d.selectedLine}document.getElementById('meta').textContent=`${d.provider} | ${d.historyHours} completed hours + current hour | missing ${d.missingTags.length}`;let h='<thead><tr>'+cols.map(x=>`<th>${x[1]}</th>`).join('')+'</tr></thead><tbody>';for(const p of d.periods){h+='<tr>';for(const [k,label,type] of cols){if(type==='period'){h+=`<td class="period">${p.label}</td>`;continue}const v=p.columns[k],c=cellClass(k,v,p,type),tip=cellTip(k,v,p,type);h+=`<td style="${classStyle(c)}" title="${escapeAttr(tip)}">${fmt(v,type)}</td>`}h+='</tr>'}document.getElementById('heatmap').innerHTML=h+'</tbody>';let s='<thead><tr><th>Metric</th><th>Loader In / Goal</th></tr></thead><tbody>';for(const r of d.shiftSummary||[]){let c=r.label==='Projected Attainment'?attainmentClass(r.value):r.label==='Current Shift Projection'&&Number(d.shiftGoal)>0?attainmentClass(r.value/d.shiftGoal*100):['5 Shift Average','14 Shift Average','20 Shift Average','30 Day Average'].includes(r.label)&&Number(d.shiftGoal)>0?attainmentClass(r.value/d.shiftGoal*100):r.label==='Consecutive Shifts Below Goal'?(Number(r.value)===0?'green':'red'):r.label==='Consecutive Shifts Above Goal'?(Number(r.value)>0?'green':'red'):'count';s+=`<tr><td class="period">${r.label}<span class="summary-sub">${r.shiftWindow||''}</span></td><td style="${classStyle(c)}">${r.format==='percent'&&r.value!=null?Number(r.value).toFixed(1)+'%':fmt(r.value)}</td></tr>`}document.getElementById('summary').innerHTML=s+'</tbody>'}
async function loadReviewTriggers(){try{const d=await getJson('/api/review-triggers');let h='<thead><tr><th>Tier</th><th>Line</th><th>Consecutive Red Shifts</th><th>Last Completed Shift</th><th>Goal</th><th>Gap</th><th>Last Known Green Shift</th><th>Last Green End</th></tr></thead><tbody>';if(!d.rows.length)h+='<tr><td colspan="8" class="empty">No lines currently meet a management review trigger.</td></tr>';for(const r of d.rows){if(r.tier==='Error'){h+=`<tr><td>Error</td><td>${r.line}</td><td colspan="6" class="left">${r.error}</td></tr>`;continue}const cls=r.tier==='Tier 3'?'tier3':r.tier==='Tier 2'?'tier2':'tier1';h+=`<tr class="${cls}"><td>${r.tier}</td><td class="left">${r.line}</td><td>${r.consecutiveRedShifts}</td><td>${fmt(r.lastCompletedShift)}</td><td>${fmt(r.goal)}</td><td>${gapText(r.gap)}</td><td>${fmt(r.lastKnownGreenShift)}</td><td>${r.lastGreenEnd?new Date(r.lastGreenEnd).toLocaleString():'Never in available history'}</td></tr>`}document.getElementById('reviewTriggers').innerHTML=h+'</tbody>'}catch(e){document.getElementById('reviewTriggers').innerHTML=`<tr><td class="empty">${e.message}</td></tr>`}}
async function loadZoneAlerts(){try{const d=await getJson('/api/zone-alerts');const alerts=Array.isArray(d.alerts)?d.alerts:[];let h='<thead><tr><th>Line</th><th>Zone</th><th>Historian Tag</th><th>Idle Since</th><th>Last Checked</th><th>Last Delta</th></tr></thead><tbody>';if(!alerts.length)h+='<tr><td colspan="6" class="empty">No active zone alerts</td></tr>';for(const r of alerts){h+=`<tr class="zone-alert-row"><td class="zone-alert-line" onclick="selectLine('${r.line}')">${r.line??'Unknown'}</td><td>${r.zone??'Unknown'}</td><td class="left" title="${escapeAttr(r.tag??'')}">${r.tag??'Unknown'}</td><td>${r.idleSince?new Date(r.idleSince).toLocaleString():'Unknown'}</td><td>${r.lastChecked?new Date(r.lastChecked).toLocaleString():'Unknown'}</td><td>${r.lastDelta==null?'No data':fmt(r.lastDelta)}</td></tr>`}document.getElementById('zoneAlerts').innerHTML=h+'</tbody>';document.getElementById('zone-alert-meta').textContent=`${alerts.length} active | Updated ${new Date(d.generatedAt).toLocaleTimeString()}`}catch(e){document.getElementById('zoneAlerts').innerHTML=`<tr><td class="empty">${e.message}</td></tr>`;document.getElementById('zone-alert-meta').textContent='Unavailable'}}
async function loadAlertStatus(){try{const d=await getJson('/api/alerts/status');const active=Array.isArray(d.activeZoneAlerts)?d.activeZoneAlerts.length:0;document.getElementById('alert-meta').textContent=`Alerts ${d.enabled?'enabled':'disabled'} | Active zone alerts ${active}${d.lastError?' | ERROR: '+d.lastError:''}`}catch(e){document.getElementById('alert-meta').textContent='Alert status unavailable: '+e.message}}
function selectLine(line){document.getElementById('line').value=line;load();loadOverview()}
document.getElementById('line').addEventListener('change',()=>{load();loadOverview()});
async function refresh(){try{await Promise.all([load(),loadOverview(),loadReviewTriggers(),loadZoneAlerts(),loadAlertStatus()])}catch(e){document.getElementById('meta').textContent=e.message}}
refresh();setInterval(load,15000);setInterval(loadOverview,60000);setInterval(loadReviewTriggers,60000);setInterval(loadZoneAlerts,60000);setInterval(loadAlertStatus,60000);
</script></body></html>'''


class Handler(BaseHTTPRequestHandler):
    def send_body(self, body, content_type="application/json", status=200):
        encoded = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        try:
            self.wfile.write(encoded)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            pass

    def json_response(self, payload, status=200):
        self.send_body(json.dumps(payload, default=str), "application/json; charset=utf-8", status)

    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                return self.send_body(INDEX_HTML, "text/html; charset=utf-8")
            if parsed.path == "/api/mappings":
                return self.json_response(ALL_LINE_MAP)
            if parsed.path == "/api/overview":
                return self.json_response(all_lines_shift_overview())
            if parsed.path == "/api/review-triggers":
                return self.json_response(management_review_triggers())
            if parsed.path == "/api/zone-alerts":
                state = load_alert_state()
                alerts = [
                    value for value in state.get("zones", {}).values()
                    if value.get("alerted")
                ]
                alerts.sort(key=lambda row: (row.get("line", ""), row.get("zone", "")))
                return self.json_response({
                    "generatedAt": datetime.now(timezone.utc).isoformat(),
                    "alerts": alerts,
                })
            if parsed.path == "/api/data":
                requested = parse_qs(parsed.query).get("line", [next(iter(ALL_LINE_MAP))])[0]
                return self.json_response(hourly_live_data(requested) if CONFIG.get("provider") == "aveva-sql" else synthetic_hourly_data(requested))
            if parsed.path == "/api/alerts/status":
                config, state = load_alert_config(), load_alert_state()
                return self.json_response({"enabled": bool(config.get("enabled")), "transport": config.get("transport"), "lastRun": state.get("lastRun"), "lastZoneCheck": state.get("lastZoneCheck"), "lastError": state.get("lastError"), "activeZoneAlerts": [value for value in state.get("zones", {}).values() if value.get("alerted")]})
            return self.send_body("Not found", "text/plain; charset=utf-8", 404)
        except Exception as exc:
            traceback.print_exc()
            return self.json_response({"error": str(exc), "type": type(exc).__name__}, 500)

    def log_message(self, fmt, *args):
        print(f"[{datetime.now().isoformat(timespec='seconds')}] {fmt % args}")


if __name__ == "__main__":
    ALERT_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    threading.Thread(target=alert_engine, name="heatmap-alert-engine", daemon=True).start()
    print(f"Open http://localhost:{PORT}")
    print(f"Alert configuration: {ALERTS_PATH}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
