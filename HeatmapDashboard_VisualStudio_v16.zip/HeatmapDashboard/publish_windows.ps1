$ErrorActionPreference = 'Stop'
$project = "$PSScriptRoot\src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj"
$output = "$PSScriptRoot\publish\win-x64"
dotnet test "$PSScriptRoot\HeatmapDashboard.sln" -c Release
dotnet publish $project -c Release -r win-x64 --self-contained true -o $output
Write-Host "Published to $output"
