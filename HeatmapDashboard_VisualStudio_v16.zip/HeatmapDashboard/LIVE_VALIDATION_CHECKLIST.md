# Live validation checklist

## Build and startup

- [ ] Solution restores and builds with zero errors.
- [ ] All automated tests pass.
- [ ] Demo profile loads every page without historian access.
- [ ] Live profile reports the intended production and alarm servers.
- [ ] Automatic email is OFF immediately after startup.

## Tag and production validation

- [ ] Compare every line/tag mapping with the approved Python v15.2 package.
- [ ] Confirm TAM02, TAM06, and TAM27 corrected overrides.
- [ ] Compare current-hour and completed-hour values for at least one Legacy and one FLEX line.
- [ ] Compare current shift actual, projection, target, and attainment.
- [ ] Confirm Current Rate, Trend, and Action populate in All Lines.

## Alarm validation

- [ ] Compare a 24-hour alarm query for one Legacy and one FLEX line.
- [ ] Confirm Legacy priority 500 is excluded.
- [ ] Confirm Zones 7–10 are excluded.
- [ ] Confirm yellow-reviewed alarms classify Verified Non-Stopping.
- [ ] Confirm door/zone-stop cascades classify Operator Access or Suppressed Access Consequence.
- [ ] Confirm 453 fail-to-retract and 517 cylinder faults remain actionable root causes.

## Downtime and email validation

- [ ] Compare selected-zone downtime against raw one-minute cyclic samples.
- [ ] Verify the minimum sustained idle threshold is five minutes.
- [ ] Confirm out-of-production lines are excluded.
- [ ] Send test emails only to the developer/test recipient list.
- [ ] Verify recovery email reports event and cumulative line-shift downtime.
- [ ] Verify the 5:00 PM report covers exactly 6:00 AM–5:00 PM.
- [ ] Verify the 5:00 PM report cannot send twice for the same date.
- [ ] Re-enable the approved distribution list only after test completion.

## History and management review

- [ ] Compare the newest 60 completed shifts for a known line.
- [ ] Confirm history renders oldest-to-newest, left-to-right.
- [ ] Confirm last green and record calculations.
- [ ] Confirm a line remains on review after more than two red shifts.
- [ ] Confirm removal requires its 20-shift average to meet/exceed goal.
