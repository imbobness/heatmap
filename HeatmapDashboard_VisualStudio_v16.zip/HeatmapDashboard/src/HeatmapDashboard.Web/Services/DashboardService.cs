using System.Text.Json.Nodes;
using HeatmapDashboard.Web.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace HeatmapDashboard.Web.Services;

public sealed class DashboardService(
    IHistorianService historian,
    ConfigurationStore store,
    IOptions<DashboardOptions> options,
    IMemoryCache cache)
{
    private readonly DashboardOptions _options = options.Value;

    public async Task<object> GetLineDataAsync(string requestedLine, CancellationToken cancellationToken = default)
    {
        var maps = store.LoadLineTags();
        var line = maps.ContainsKey(requestedLine) ? requestedLine : maps.Keys.First();
        var tags = maps[line];
        var targets = TargetValues(line);
        var now = DateTime.Now;
        var currentHour = new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0);
        var firstBoundary = currentHour.AddHours(-_options.HistoryHours);
        var hourly = await historian.GetHistoryAsync(tags.Values, firstBoundary, currentHour, "Cyclic", 3_600_000, cancellationToken);
        var live = await historian.GetLiveValuesAsync(tags.Values, cancellationToken);
        var periods = new List<object>();

        var liveValues = new Dictionary<string, double?>();
        foreach (var mapping in tags)
        {
            var samples = hourly.GetValueOrDefault(mapping.Value) ?? Array.Empty<HistorianSample>();
            var boundary = samples.LastOrDefault(x => x.Timestamp <= currentHour)?.Value;
            liveValues[mapping.Key] = CounterDelta(boundary, live.GetValueOrDefault(mapping.Value)?.Value);
        }
        periods.Add(Period("Current Hour", currentHour, now, true, liveValues));

        for (var offset = 1; offset <= _options.HistoryHours; offset++)
        {
            var start = currentHour.AddHours(-offset);
            var end = start.AddHours(1);
            var values = new Dictionary<string, double?>();
            foreach (var mapping in tags)
            {
                var samples = hourly.GetValueOrDefault(mapping.Value) ?? Array.Empty<HistorianSample>();
                values[mapping.Key] = CounterDelta(
                    samples.LastOrDefault(x => x.Timestamp <= start)?.Value,
                    samples.LastOrDefault(x => x.Timestamp <= end)?.Value);
            }
            periods.Add(Period($"{start:h tt} to {end:h tt}", start, end, false, values));
        }

        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var loader = tags.GetValueOrDefault("Z6_IN");
        var shiftHistory = string.IsNullOrWhiteSpace(loader)
            ? new Dictionary<string, IReadOnlyList<HistorianSample>>()
            : await historian.GetHistoryAsync([loader], shiftStart.AddDays(-30), now, "Delta", null, cancellationToken);
        IReadOnlyList<HistorianSample> loaderSamples = string.IsNullOrWhiteSpace(loader)
            ? Array.Empty<HistorianSample>() : shiftHistory.GetValueOrDefault(loader) ?? Array.Empty<HistorianSample>();
        var actual = DeltaInWindow(loaderSamples, shiftStart, now);
        var elapsedHours = Math.Max((now - shiftStart).TotalHours, 1d / 60);
        var projection = Math.Round(actual / elapsedHours * 12, 2);
        var goal = targets.GetValueOrDefault("SHIFT_GOAL");
        var attainment = goal > 0 ? Math.Round(projection / goal * 100, 2) : (double?)null;
        var completed = CompletedShifts(loaderSamples, shiftStart, 60);
        var trend = Trend(periods, targets);
        var summary = ShiftSummary(completed, actual, projection, attainment, goal, shiftStart);
        var missing = tags.Where(x => !(hourly.GetValueOrDefault(x.Value)?.Count > 0) && !live.ContainsKey(x.Value)).Select(x => x.Value).ToList();

        return new
        {
            provider = historian.IsLive ? "aveva-sql-hourly" : "synthetic-hourly",
            generatedAt = DateTimeOffset.Now,
            selectedLine = line,
            availableLines = maps.Keys,
            historyHours = _options.HistoryHours,
            refreshSeconds = _options.RefreshSeconds,
            targets = new { },
            hourlyTargets = targets,
            shiftGoal = goal,
            tags,
            missingTags = missing,
            periods,
            shiftSummary = summary,
            trend,
            actionStatus = ActionStatus(trend, attainment),
            projectedAttainment = attainment
        };
    }

    public async Task<object> GetOverviewAsync(CancellationToken cancellationToken = default)
    {
        if (cache.TryGetValue("overview", out object? cached) && cached is not null) return cached;
        var now = DateTime.Now;
        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var maps = store.LoadLineTags().Where(x => store.LineIsInProduction(x.Key)).ToList();
        var loaderTags = maps.Select(x => x.Value.GetValueOrDefault("Z6_IN")).Where(x => !string.IsNullOrWhiteSpace(x)).Cast<string>().ToList();
        var samples = await historian.GetHistoryAsync(loaderTags, shiftStart.AddHours(-12), now, "Delta", null, cancellationToken);
        var targets = store.LoadTargets();
        var rows = new List<object>();
        foreach (var entry in maps)
        {
            var tag = entry.Value.GetValueOrDefault("Z6_IN");
            IReadOnlyList<HistorianSample> series = tag is null
                ? Array.Empty<HistorianSample>() : samples.GetValueOrDefault(tag) ?? Array.Empty<HistorianSample>();
            var goal = targets[entry.Key]?["SHIFT_GOAL"]?.GetValue<double?>() ?? 0;
            var actual = DeltaInWindow(series, shiftStart, now);
            var lastShift = DeltaInWindow(series, shiftStart.AddHours(-12), shiftStart);
            var elapsedHours = Math.Max((now - shiftStart).TotalHours, 1d / 60);
            var projection = Math.Round(actual / elapsedHours * 12, 2);
            var currentRate = RateForMinutes(series, now.AddMinutes(-60), now);
            var priorRate = RateForMinutes(series, now.AddMinutes(-120), now.AddMinutes(-60));
            var required = goal > 0 ? goal / 12 : 0;
            var attainment = goal > 0 ? Math.Round(projection / goal * 100, 2) : (double?)null;
            var rateAttainment = required > 0 ? Math.Round(currentRate / required * 100, 2) : (double?)null;
            var trendChange = priorRate > 0 ? Math.Round((currentRate - priorRate) / priorRate * 100, 2) : (double?)null;
            var direction = trendChange is null ? "unknown" : trendChange >= 5 ? "improving" : trendChange <= -5 ? "declining" : "stable";
            var trend = new TrendResult("", direction, currentRate, priorRate, trendChange, rateAttainment, "", []);
            rows.Add(new
            {
                line = entry.Key, lastShift, currentActual = actual, currentProjection = projection, goal,
                attainment, gap = goal > 0 ? projection - goal : (double?)null, error = (string?)null,
                currentRate, requiredHourlyRate = required, currentRateAttainment = rateAttainment,
                trendDirection = direction, trendChange, action = ActionStatus(trend, attainment)
            });
        }
        var result = new { generatedAt = DateTimeOffset.Now, shiftStart, rows = rows.OrderBy(x => ReadDouble(x, "attainment")).ToList(), provider = historian.IsLive ? "aveva-sql" : "synthetic-demo" };
        cache.Set("overview", result, TimeSpan.FromSeconds(20));
        return result;
    }

    public async Task<object> GetHistoryAsync(string line, int count = 60, CancellationToken cancellationToken = default)
    {
        count = Math.Clamp(count, 5, 120);
        var maps = store.LoadLineTags();
        if (!maps.TryGetValue(line, out var tags) || !tags.TryGetValue("Z6_IN", out var loader))
            throw new ArgumentException($"No Loader Out historian tag mapped for {line}");
        var now = DateTime.Now;
        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var history = await historian.GetHistoryAsync([loader], shiftStart.AddHours(-12 * count), shiftStart, "Delta", null, cancellationToken);
        var completed = CompletedShifts(history.GetValueOrDefault(loader) ?? Array.Empty<HistorianSample>(), shiftStart, count);
        var goal = TargetValues(line).GetValueOrDefault("SHIFT_GOAL");
        return new
        {
            line, goal,
            rows = completed.Select(x => new { start = x.Start, end = x.End, value = x.Value, attainment = goal > 0 ? Math.Round(x.Value / goal * 100, 2) : (double?)null }),
            provider = historian.IsLive ? "aveva-sql" : "synthetic-history"
        };
    }

    public async Task<object> GetZoneDowntimeAsync(string line, string zone, CancellationToken cancellationToken = default)
    {
        var maps = store.LoadLineTags();
        if (!maps.TryGetValue(line, out var tags) || !tags.TryGetValue(zone, out var tag))
            throw new ArgumentException($"No production counter mapped for {line} {zone}");
        var now = DateTime.Now;
        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var end = now < shiftStart.AddHours(12) ? now : shiftStart.AddHours(12);
        var threshold = store.LoadAlerts()["dailyDowntimeMinimumIdleMinutes"]?.GetValue<double?>() ?? 5;
        var history = await historian.GetHistoryAsync([tag], shiftStart, end, "Cyclic", 60_000, cancellationToken);
        var metric = ShiftMath.NoIncrementSummary(history.GetValueOrDefault(tag) ?? Array.Empty<HistorianSample>(), shiftStart, end, threshold);
        return new
        {
            line, zone, tag, shiftStart, windowEnd = end, minimumIdleMinutes = threshold,
            bars = ShiftMath.HourlyBars(shiftStart, end, metric.Intervals),
            totalDowntimeMinutes = metric.DowntimeMinutes, metric.EventCount, metric.LongestStopMinutes,
            metric.CoveragePercent, metric.CurrentStatus, provider = historian.IsLive ? "aveva-sql" : "synthetic"
        };
    }

    public async Task<IReadOnlyList<ZoneDowntimeRow>> GetDowntimeRowsAsync(
        DateTime start, DateTime end, double minimumIdleMinutes, CancellationToken cancellationToken = default)
    {
        var maps = store.LoadLineTags().Where(x => store.LineIsInProduction(x.Key)).ToList();
        var ownership = maps.SelectMany(line => line.Value
                .Where(zone => !IsExcludedZone(zone.Key))
                .Select(zone => (line: line.Key, zone: zone.Key, tag: zone.Value)))
            .Where(x => !string.IsNullOrWhiteSpace(x.tag)).ToList();
        var history = await historian.GetHistoryAsync(ownership.Select(x => x.tag), start, end, "Cyclic", 60_000, cancellationToken);
        return ownership.Select(x =>
        {
            var metric = ShiftMath.NoIncrementSummary(history.GetValueOrDefault(x.tag) ?? Array.Empty<HistorianSample>(), start, end, minimumIdleMinutes);
            return new ZoneDowntimeRow(x.line, x.zone, x.tag, metric.DowntimeMinutes, metric.EventCount,
                metric.LongestStopMinutes, metric.Production, metric.CoveragePercent, metric.CurrentStatus);
        }).ToList();
    }

    public async Task<object> GetReviewTriggersAsync(CancellationToken cancellationToken = default)
    {
        var rows = new List<object>();
        foreach (var line in store.ActiveLines())
        {
            var historyObject = await GetHistoryAsync(line, 120, cancellationToken);
            var values = ReadHistoryRows(historyObject);
            var goal = TargetValues(line).GetValueOrDefault("SHIFT_GOAL");
            var review = ManagementReviewState(values, goal);
            if (!review.OnReview) continue;
            var lastGreenIndex = values.Select((value, index) => (value, index)).LastOrDefault(x => x.value >= goal);
            rows.Add(new
            {
                tier = review.Tier, line, consecutiveRedShifts = review.ConsecutiveRed,
                twentyShiftAverage = review.Average20, twentyShiftGap = review.Average20 - goal,
                reviewStatus = "REMAINS ON REVIEW — 20 shift average must meet goal",
                lastCompletedShift = values.LastOrDefault(), goal, gap = values.LastOrDefault() - goal,
                lastKnownGreenShift = lastGreenIndex.value,
                lastGreenEnd = lastGreenIndex.value >= goal ? ShiftMath.CurrentShiftStart(DateTime.Now).AddHours(-12 * (values.Count - lastGreenIndex.index - 1)) : (DateTime?)null
            });
        }
        return new { generatedAt = DateTimeOffset.Now, rows };
    }

    private Dictionary<string, double> TargetValues(string line)
    {
        var target = store.LoadTargets()[line] as JsonObject;
        return target?.Where(x => x.Value is JsonValue)
            .ToDictionary(x => x.Key, x => x.Value!.GetValue<double>(), StringComparer.OrdinalIgnoreCase) ?? new Dictionary<string, double>();
    }

    private static object Period(string label, DateTime start, DateTime end, bool live, Dictionary<string, double?> values) =>
        new { label, start, end, isLiveHour = live, columns = CalculateColumns(values) };

    private static Dictionary<string, double?> CalculateColumns(IReadOnlyDictionary<string, double?> value) => new()
    {
        ["Z1"] = value.GetValueOrDefault("Z1"), ["Z2A"] = value.GetValueOrDefault("Z2A"),
        ["Z2A_YIELD"] = Yield(value.GetValueOrDefault("Z2A"), value.GetValueOrDefault("Z1")),
        ["Z3_IN"] = value.GetValueOrDefault("Z3_IN"), ["Z3_OUT"] = value.GetValueOrDefault("Z3_OUT"),
        ["Z3_YIELD"] = Yield(value.GetValueOrDefault("Z3_OUT"), value.GetValueOrDefault("Z3_IN")),
        ["Z4_OUT"] = value.GetValueOrDefault("Z4_OUT"), ["Z4_YIELD"] = Yield(value.GetValueOrDefault("Z4_OUT"), value.GetValueOrDefault("Z3_OUT")),
        ["Z5_IN"] = value.GetValueOrDefault("Z5_IN"), ["Z5_YIELD"] = Yield(value.GetValueOrDefault("Z5_IN"), value.GetValueOrDefault("Z4_OUT")),
        ["ALI_IN"] = value.GetValueOrDefault("ALI_IN"), ["ALI_OUT"] = value.GetValueOrDefault("ALI_OUT"),
        ["ALI_YIELD"] = Yield(value.GetValueOrDefault("ALI_OUT"), value.GetValueOrDefault("ALI_IN")),
        ["Z6_IN"] = value.GetValueOrDefault("Z6_IN"), ["Z6_YIELD"] = Yield(value.GetValueOrDefault("Z6_IN"), value.GetValueOrDefault("ALI_OUT")),
        ["LINE_YIELD"] = Yield(value.GetValueOrDefault("Z6_IN"), value.GetValueOrDefault("Z1"))
    };

    private static double? Yield(double? output, double? input) => output.HasValue && input > 0 ? Math.Round(output.Value / input.Value * 100, 2) : null;
    private static double? CounterDelta(double? start, double? end) => start.HasValue && end.HasValue ? Math.Max(0, end.Value - start.Value) : null;
    private static double DeltaInWindow(IReadOnlyList<HistorianSample> samples, DateTime start, DateTime end) =>
        ShiftMath.AccumulatedCounterDelta(samples.Where(x => x.Timestamp >= start && x.Timestamp <= end));
    private static double RateForMinutes(IReadOnlyList<HistorianSample> samples, DateTime start, DateTime end) =>
        Math.Round(DeltaInWindow(samples, start, end) / Math.Max((end - start).TotalHours, 1d / 60), 2);
    private static bool IsExcludedZone(string zone) => new[] { "Z7", "Z8", "Z9", "Z10" }.Any(x => zone.StartsWith(x, StringComparison.OrdinalIgnoreCase));

    private sealed record CompletedShift(DateTime Start, DateTime End, double Value);
    private static List<CompletedShift> CompletedShifts(IReadOnlyList<HistorianSample> samples, DateTime shiftStart, int count)
    {
        var output = new List<CompletedShift>();
        for (var index = count; index >= 1; index--)
        {
            var start = shiftStart.AddHours(-12 * index);
            var end = start.AddHours(12);
            output.Add(new(start, end, DeltaInWindow(samples, start, end)));
        }
        return output;
    }

    private sealed record TrendResult(string Status, string Direction, double RecentAverage, double? PriorAverage, double? ChangePercent, double? TargetAttainmentPercent, string Message, IReadOnlyList<double> Series);
    private static TrendResult Trend(IEnumerable<object> periodObjects, IReadOnlyDictionary<string, double> targets)
    {
        var values = periodObjects.Skip(1).Select(x => ReadColumn(x, "Z6_IN")).Where(x => x.HasValue).Select(x => x!.Value).ToList();
        if (values.Count == 0) return new("No data", "unknown", 0, null, null, null, "No completed hourly loader data yet.", []);
        var recent = values.Take(3).ToList();
        var prior = values.Skip(3).Take(3).ToList();
        var recentAverage = recent.Average();
        var priorAverage = prior.Count > 0 ? prior.Average() : (double?)null;
        var change = priorAverage > 0 ? (recentAverage - priorAverage.Value) / priorAverage.Value * 100 : (double?)null;
        var direction = change is null ? "stable" : change >= 5 ? "improving" : change <= -5 ? "declining" : "stable";
        var target = targets.GetValueOrDefault("Z6_IN");
        return new(direction == "improving" ? "Recovering" : direction == "declining" ? "Declining" : "Stabilizing", direction,
            Math.Round(recentAverage, 2), priorAverage is null ? null : Math.Round(priorAverage.Value, 2), change is null ? null : Math.Round(change.Value, 2),
            target > 0 ? Math.Round(recentAverage / target * 100, 2) : null,
            direction == "improving" ? "Recent output is improving." : direction == "declining" ? "Recent output is deteriorating; investigate the active constraint." : "Recent output is relatively stable.",
            values.Take(8).Reverse().ToList());
    }

    private static object ActionStatus(TrendResult trend, double? projected)
    {
        var current = trend.TargetAttainmentPercent;
        if (trend.Direction == "unknown" || current is null) return new { code = "NO_DATA", label = "NO DATA", priority = 5, message = "Not enough data." };
        if (trend.Direction == "declining" && (current < 95 || projected < 95)) return new { code = "INTERVENE", label = "INTERVENE", priority = 1, message = "Performance is below expectation and deteriorating." };
        if (trend.Direction == "declining") return new { code = "INVESTIGATE", label = "INVESTIGATE", priority = 2, message = "Check for an emerging constraint." };
        if (trend.Direction == "improving" && current < 98) return new { code = "RECOVERING", label = "RECOVERING", priority = 3, message = "Continue monitoring recovery." };
        if (current >= 98 && projected < 95) return new { code = "STABILIZE", label = "STABILIZE", priority = 4, message = "Current rate recovered; allow stabilization." };
        if (trend.Direction == "stable" && current < 95) return new { code = "INVESTIGATE", label = "INVESTIGATE", priority = 2, message = "Performance remains below target." };
        return new { code = "HEALTHY", label = "HEALTHY", priority = 5, message = "Performance and trend are acceptable." };
    }

    private static List<object> ShiftSummary(List<CompletedShift> completed, double actual, double projection, double? attainment, double goal, DateTime shiftStart)
    {
        double? Average(int count) => completed.TakeLast(count).Select(x => x.Value).DefaultIfEmpty().Average();
        var below = completed.AsEnumerable().Reverse().TakeWhile(x => x.Value < goal).Count();
        var above = completed.AsEnumerable().Reverse().TakeWhile(x => x.Value >= goal).Count();
        return
        [
            new { label = "Current Shift Projection", shiftWindow = $"{shiftStart:h tt} to {shiftStart.AddHours(12):h tt} | Actual {actual:N0}", value = (double?)projection, format = "count" },
            new { label = "Shift Goal", shiftWindow = "Configured Loader In goal", value = (double?)goal, format = "count" },
            new { label = "Projected Attainment", shiftWindow = "Projection versus shift goal", value = attainment, format = "percent" },
            new { label = "5 Shift Average", shiftWindow = "Last 5 completed shifts", value = Average(5), format = "count" },
            new { label = "14 Shift Average", shiftWindow = "Last 14 completed shifts", value = Average(14), format = "count" },
            new { label = "20 Shift Average", shiftWindow = "Last 20 completed shifts", value = Average(20), format = "count" },
            new { label = "Consecutive Shifts Below Goal", shiftWindow = "Completed shifts below goal", value = (double?)below, format = "integer" },
            new { label = "Consecutive Shifts Above Goal", shiftWindow = "Completed shifts at/above goal", value = (double?)above, format = "integer" },
            new { label = "30 Day Average", shiftWindow = "Last 60 completed shifts", value = Average(60), format = "count" }
        ];
    }

    private static double? ReadColumn(object period, string key)
    {
        var columns = period.GetType().GetProperty("columns")?.GetValue(period) as IReadOnlyDictionary<string, double?>;
        return columns?.GetValueOrDefault(key);
    }
    private static double ReadDouble(object value, string property) => Convert.ToDouble(value.GetType().GetProperty(property)?.GetValue(value) ?? double.MaxValue);
    private static IReadOnlyList<double> ReadHistoryRows(object value)
    {
        var rows = value.GetType().GetProperty("rows")?.GetValue(value) as IEnumerable<object>;
        return rows?.Select(x => Convert.ToDouble(x.GetType().GetProperty("value")?.GetValue(x) ?? 0)).ToList() ?? new List<double>();
    }

    private sealed record ReviewState(bool OnReview, string? Tier, int ConsecutiveRed, double Average20);
    private static ReviewState ManagementReviewState(IReadOnlyList<double> values, double goal)
    {
        var onReview = false;
        var redRun = 0;
        for (var index = 0; index < values.Count; index++)
        {
            redRun = values[index] < goal ? redRun + 1 : 0;
            if (!onReview && redRun >= 2) onReview = true;
            if (onReview && index >= 19 && values.Skip(index - 19).Take(20).Average() >= goal) onReview = false;
        }
        var currentRed = values.Reverse().TakeWhile(x => x < goal).Count();
        var average20 = values.Count >= 20 ? values.TakeLast(20).Average() : 0;
        var tier = currentRed >= 8 ? "Tier 3" : currentRed >= 5 ? "Tier 2" : currentRed >= 2 ? "Tier 1" : "Recovery";
        return new(onReview, onReview ? tier : null, currentRed, Math.Round(average20, 2));
    }
}
