using HeatmapDashboard.Web.Models;

namespace HeatmapDashboard.Web.Services;

public sealed class SyntheticHistorianService : IHistorianService
{
    public bool IsLive => false;

    public Task<IReadOnlyDictionary<string, LiveTagValue>> GetLiveValuesAsync(
        IEnumerable<string> sourceTags, CancellationToken cancellationToken = default)
    {
        var now = DateTime.Now;
        IReadOnlyDictionary<string, LiveTagValue> result = sourceTags.Distinct().ToDictionary(
            tag => tag, tag => new LiveTagValue(now, SyntheticValue(tag, now), 192, "Good"));
        return Task.FromResult(result);
    }

    public Task<IReadOnlyDictionary<string, IReadOnlyList<HistorianSample>>> GetHistoryAsync(
        IEnumerable<string> sourceTags, DateTime start, DateTime end, string retrievalMode,
        int? resolutionMilliseconds = null, CancellationToken cancellationToken = default)
    {
        var step = TimeSpan.FromMilliseconds(resolutionMilliseconds ?? 60_000);
        if (retrievalMode.Equals("Delta", StringComparison.OrdinalIgnoreCase)) step = TimeSpan.FromMinutes(1);
        var result = new Dictionary<string, IReadOnlyList<HistorianSample>>(StringComparer.OrdinalIgnoreCase);
        foreach (var tag in sourceTags.Distinct())
        {
            var points = new List<HistorianSample>();
            for (var stamp = start; stamp <= end; stamp += step)
                points.Add(new(stamp, SyntheticValue(tag, stamp)));
            result[tag] = points;
        }
        return Task.FromResult((IReadOnlyDictionary<string, IReadOnlyList<HistorianSample>>)result);
    }

    public Task<(bool Ok, string Detail)> CheckHealthAsync(CancellationToken cancellationToken = default) =>
        Task.FromResult((true, "Synthetic demo provider"));

    private static double SyntheticValue(string tag, DateTime stamp)
    {
        var seed = Math.Abs(StringComparer.OrdinalIgnoreCase.GetHashCode(tag)) % 4000;
        var shift = ShiftMath.CurrentShiftStart(stamp);
        var minutes = Math.Max(0, (stamp - shift).TotalMinutes);
        var rate = 55 + seed % 35;
        var stopCycle = (int)(minutes / 60) % 6;
        var stoppedMinutes = stopCycle == 2 ? Math.Min(18, Math.Max(0, minutes % 60 - 20)) : 0;
        return seed * 1000 + Math.Max(0, minutes - stoppedMinutes) * rate;
    }
}
