using System.Text.Json;
using System.Text.Json.Nodes;

namespace HeatmapDashboard.Web.Services;

public sealed class ConfigurationStore
{
    private readonly string _configurationDirectory;
    private readonly string _dataDirectory;
    private readonly SemaphoreSlim _writeLock = new(1, 1);
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true, WriteIndented = true };

    public ConfigurationStore(IHostEnvironment environment)
    {
        _configurationDirectory = Path.Combine(environment.ContentRootPath, "Configuration");
        _dataDirectory = Path.Combine(environment.ContentRootPath, "data");
        Directory.CreateDirectory(_configurationDirectory);
        Directory.CreateDirectory(_dataDirectory);
    }

    public IReadOnlyDictionary<string, IReadOnlyDictionary<string, string>> LoadLineTags() =>
        Read(ConfigPath("line-tags.json"), new Dictionary<string, Dictionary<string, string>>())
            .ToDictionary(x => x.Key, x => (IReadOnlyDictionary<string, string>)x.Value, StringComparer.OrdinalIgnoreCase);

    public JsonObject LoadTargets() => ReadObject(ConfigPath("targets.json"));
    public JsonObject LoadRecipients() => ReadObject(ConfigPath("recipients.json"));
    public JsonObject LoadAlerts() => ReadObject(ConfigPath("alerts.json"));
    public JsonObject LoadLineStatus() => ReadObject(ConfigPath("line_status.json"));
    public JsonObject LoadValidatedAlarmRules() => ReadObject(ConfigPath("validated_alarm_rules.json"));
    public JsonObject LoadAlertState() => ReadObject(DataPath("alert_state.json"));
    public JsonObject LoadHistoricalRecords() => ReadObject(DataPath("historical_records.json"));

    public bool LineIsInProduction(string line)
    {
        var status = LoadLineStatus();
        return status[line]?.GetValue<bool?>() ?? true;
    }

    public IEnumerable<string> ActiveLines() => LoadLineTags().Keys.Where(LineIsInProduction);

    public async Task SaveTargetsAsync(JsonObject value) => await WriteAsync(ConfigPath("targets.json"), value);
    public async Task SaveRecipientsAsync(JsonObject value) => await WriteAsync(ConfigPath("recipients.json"), value);
    public async Task SaveAlertsAsync(JsonObject value) => await WriteAsync(ConfigPath("alerts.json"), value);
    public async Task SaveLineStatusAsync(JsonObject value) => await WriteAsync(ConfigPath("line_status.json"), value);
    public async Task SaveAlertStateAsync(JsonObject value) => await WriteAsync(DataPath("alert_state.json"), value);
    public async Task SaveHistoricalRecordsAsync(JsonObject value) => await WriteAsync(DataPath("historical_records.json"), value);

    public IReadOnlyList<string> ResolveRecipients(string purpose)
    {
        var recipients = LoadRecipients();
        var groupKey = purpose.Equals("zone", StringComparison.OrdinalIgnoreCase)
            ? "activeZoneGroup" : "activePerformanceGroup";
        var group = recipients[groupKey]?.GetValue<string>() ?? string.Empty;
        var groups = recipients["groups"] as JsonObject;
        var people = recipients["people"] as JsonArray;
        var enabled = (people ?? new JsonArray())
            .OfType<JsonObject>()
            .Where(x => x["enabled"]?.GetValue<bool?>() ?? true)
            .Select(x => x["email"]?.GetValue<string>() ?? string.Empty)
            .Where(x => x.Length > 0)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        return (groups?[group] as JsonArray ?? new JsonArray())
            .Select(x => x?.GetValue<string>() ?? string.Empty)
            .Where(x => enabled.Contains(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private string ConfigPath(string name) => Path.Combine(_configurationDirectory, name);
    private string DataPath(string name) => Path.Combine(_dataDirectory, name);

    private static T Read<T>(string path, T fallback)
    {
        try { return JsonSerializer.Deserialize<T>(File.ReadAllText(path), JsonOptions) ?? fallback; }
        catch { return fallback; }
    }

    private static JsonObject ReadObject(string path)
    {
        try { return JsonNode.Parse(File.ReadAllText(path)) as JsonObject ?? new JsonObject(); }
        catch { return new JsonObject(); }
    }

    private async Task WriteAsync(string path, JsonObject value)
    {
        await _writeLock.WaitAsync();
        try
        {
            var temporary = path + ".tmp";
            await File.WriteAllTextAsync(temporary, value.ToJsonString(JsonOptions));
            File.Move(temporary, path, true);
        }
        finally { _writeLock.Release(); }
    }
}
