using HeatmapDashboard.Web.Models;

namespace HeatmapDashboard.Web.Services;

public static class ShiftMath
{
    public static DateTime CurrentShiftStart(DateTime value)
    {
        var local = DateTime.SpecifyKind(value, DateTimeKind.Unspecified);
        if (local.Hour >= 18) return local.Date.AddHours(18);
        if (local.Hour >= 6) return local.Date.AddHours(6);
        return local.Date.AddDays(-1).AddHours(18);
    }

    public static double CounterDelta(double? start, double? end)
    {
        if (start is null || end is null) return 0;
        return Math.Max(0, end.Value - start.Value);
    }

    public static double AccumulatedCounterDelta(IEnumerable<HistorianSample> samples)
    {
        var usable = samples.Where(x => x.Value.HasValue).OrderBy(x => x.Timestamp).ToList();
        double total = 0;
        for (var i = 1; i < usable.Count; i++)
        {
            var delta = usable[i].Value!.Value - usable[i - 1].Value!.Value;
            total += delta >= 0 ? delta : Math.Max(0, usable[i].Value.Value);
        }
        return total;
    }

    public static DowntimeMetric NoIncrementSummary(
        IEnumerable<HistorianSample> source,
        DateTime windowStart,
        DateTime windowEnd,
        double minimumIdleMinutes = 5,
        double maximumSampleGapSeconds = 150)
    {
        var samples = source
            .Where(x => x.Timestamp >= windowStart && x.Timestamp <= windowEnd && x.Value.HasValue)
            .OrderBy(x => x.Timestamp)
            .ToList();

        if (samples.Count < 2)
            return new(0, 0, 0, 0, 0, "NO DATA", null, null, []);

        var minimum = TimeSpan.FromMinutes(minimumIdleMinutes);
        var intervals = new List<DowntimeInterval>();
        DateTime? idleStart = null;
        double production = 0;
        double coveredSeconds = 0;

        for (var i = 1; i < samples.Count; i++)
        {
            var previous = samples[i - 1];
            var current = samples[i];
            var gap = (current.Timestamp - previous.Timestamp).TotalSeconds;
            if (gap <= 0 || gap > maximumSampleGapSeconds)
            {
                if (idleStart.HasValue && previous.Timestamp - idleStart.Value >= minimum)
                    intervals.Add(new(idleStart.Value, previous.Timestamp));
                idleStart = null;
                continue;
            }

            coveredSeconds += gap;
            var delta = current.Value!.Value - previous.Value!.Value;
            if (delta > 0 || (delta < 0 && current.Value.Value > 0))
            {
                production += delta >= 0 ? delta : current.Value.Value;
                if (idleStart.HasValue && previous.Timestamp - idleStart.Value >= minimum)
                    intervals.Add(new(idleStart.Value, previous.Timestamp));
                idleStart = null;
            }
            else if (!idleStart.HasValue)
            {
                idleStart = previous.Timestamp;
            }
        }

        var last = samples[^1];
        if (idleStart.HasValue && last.Timestamp - idleStart.Value >= minimum)
            intervals.Add(new(idleStart.Value, last.Timestamp));

        var latestAge = (windowEnd - last.Timestamp).TotalSeconds;
        var currentlyIdle = idleStart.HasValue && latestAge <= maximumSampleGapSeconds && last.Timestamp - idleStart.Value >= minimum;
        var windowSeconds = Math.Max(1, (windowEnd - windowStart).TotalSeconds);
        return new(
            Math.Round(intervals.Sum(x => x.Minutes), 1),
            intervals.Count,
            Math.Round(intervals.Select(x => x.Minutes).DefaultIfEmpty().Max(), 1),
            Math.Round(production, 1),
            Math.Round(Math.Min(100, coveredSeconds / windowSeconds * 100), 1),
            currentlyIdle ? "STOPPED" : "RUNNING",
            intervals.FirstOrDefault()?.Start,
            currentlyIdle ? null : intervals.LastOrDefault()?.End,
            intervals);
    }

    public static IReadOnlyList<HourlyDowntimeBar> HourlyBars(
        DateTime start, DateTime end, IReadOnlyList<DowntimeInterval> intervals)
    {
        var bars = new List<HourlyDowntimeBar>();
        for (var bucket = start; bucket < end; bucket = bucket.AddHours(1))
        {
            var bucketEnd = bucket.AddHours(1) < end ? bucket.AddHours(1) : end;
            var overlaps = intervals
                .Where(x => x.Start < bucketEnd && x.End > bucket)
                .Select(x => new DowntimeInterval(x.Start > bucket ? x.Start : bucket, x.End < bucketEnd ? x.End : bucketEnd))
                .ToList();
            bars.Add(new(bucket, bucketEnd, bucket.ToString("h tt"), Math.Round(overlaps.Sum(x => x.Minutes), 1),
                intervals.Count(x => x.Start >= bucket && x.Start < bucketEnd)));
        }
        return bars;
    }
}
