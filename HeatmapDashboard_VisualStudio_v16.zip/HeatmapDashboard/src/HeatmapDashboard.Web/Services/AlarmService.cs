using System.Data.Odbc;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using HeatmapDashboard.Web.Models;
using Microsoft.Extensions.Options;

namespace HeatmapDashboard.Web.Services;

public sealed partial class AlarmService(ConfigurationStore store, IOptions<DashboardOptions> dashboardOptions, ILogger<AlarmService> logger)
{
    private readonly DashboardOptions _dashboard = dashboardOptions.Value;

    public async Task<IReadOnlyList<AlarmEvent>> GetAlarmsAsync(string line, int hours = 24, CancellationToken cancellationToken = default)
    {
        if (!_dashboard.IsLive) return Synthetic(line);
        var legacy = QueryLegacyAsync(line, hours, cancellationToken);
        var flex = QueryFlexAsync(line, hours, cancellationToken);
        var results = await Task.WhenAll(Safe(legacy, "Legacy"), Safe(flex, "Flex"));
        return Classify(results.SelectMany(x => x).OrderBy(x => x.Start).ToList(), 120)
            .Where(x => !x.ExcludedFromAnalysis).OrderByDescending(x => x.Start).ToList();
    }

    public async Task<object> HealthAsync(CancellationToken cancellationToken = default)
    {
        if (!_dashboard.IsLive) return new { ok = true, detail = "Synthetic alarm provider", sources = new { } };
        var legacy = await CheckConnectionAsync("Legacy", LegacyConnection(), cancellationToken);
        var flex = await CheckConnectionAsync("Flex", FlexConnection(), cancellationToken);
        return new { ok = legacy.ok || flex.ok, detail = $"Legacy: {legacy.detail}; Flex: {flex.detail}", sources = new { legacy, flex } };
    }

    private async Task<List<MutableAlarm>> QueryLegacyAsync(string line, int hours, CancellationToken token)
    {
        var rows = new List<MutableAlarm>();
        await using var connection = new OdbcConnection(LegacyConnection());
        await connection.OpenAsync(token);
        await using var command = connection.CreateCommand();
        command.CommandTimeout = 90;
        command.CommandText = """
            SELECT TOP 10000 LoggingNode, GroupName, Comment, Priority,
                   OriginationTime, ReturnTime, TagName, AlarmType
            FROM WWALMDB.dbo.[3GTAlarms]
            WHERE OriginationTime >= DATEADD(HOUR, ?, GETDATE())
              AND Priority >= 1 AND Priority <> 500
              AND RIGHT(RTRIM(CAST(LoggingNode AS varchar(128))), 2) = ?
            ORDER BY OriginationTime DESC
            """;
        command.Parameters.Add(new OdbcParameter { Value = -Math.Clamp(hours, 1, 8760) });
        command.Parameters.Add(new OdbcParameter { Value = line[^2..] });
        await using var reader = await command.ExecuteReaderAsync(token);
        while (await reader.ReadAsync(token))
        {
            var start = reader.GetDateTime(4);
            var end = reader.IsDBNull(5) ? (DateTime?)null : reader.GetDateTime(5);
            rows.Add(new("3GT", "Legacy 3GT", line, Convert.ToString(reader.GetValue(1)) ?? "", Convert.ToString(reader.GetValue(2)) ?? "",
                Convert.ToString(reader.GetValue(6)) ?? "", start, end, end.HasValue ? Math.Max(0, (end.Value - start).TotalSeconds) : 0, true));
        }
        return rows;
    }

    private async Task<List<MutableAlarm>> QueryFlexAsync(string line, int hours, CancellationToken token)
    {
        var rows = new List<MutableAlarm>();
        await using var connection = new OdbcConnection(FlexConnection());
        await connection.OpenAsync(token);
        await using var command = connection.CreateCommand();
        command.CommandTimeout = 90;
        command.CommandText = """
            SELECT TOP 10000 LoggingNode, SourceName, Message, Severity, Priority,
                   AlarmStartTimeStamp, AlarmEndTimeStamp, Acked
            FROM RWAEDB.dbo.FLEXALARMS
            WHERE AlarmStartTimeStamp >= DATEADD(HOUR, ?, GETDATE())
              AND Severity >= 740
              AND RIGHT(RTRIM(CAST(LoggingNode AS varchar(128))), 2) = ?
            ORDER BY AlarmStartTimeStamp DESC
            """;
        command.Parameters.Add(new OdbcParameter { Value = -Math.Clamp(hours, 1, 8760) });
        command.Parameters.Add(new OdbcParameter { Value = line[^2..] });
        await using var reader = await command.ExecuteReaderAsync(token);
        while (await reader.ReadAsync(token))
        {
            var start = reader.GetDateTime(5);
            var end = reader.IsDBNull(6) ? (DateTime?)null : reader.GetDateTime(6);
            var acked = !reader.IsDBNull(7) && Convert.ToBoolean(reader.GetValue(7));
            var source = Convert.ToString(reader.GetValue(1)) ?? "";
            rows.Add(new("FLEX", "Flex", line, source, Convert.ToString(reader.GetValue(2)) ?? "", source,
                start, end, end.HasValue ? Math.Max(0, (end.Value - start).TotalSeconds) : 0, acked));
        }
        return rows;
    }

    private IReadOnlyList<AlarmEvent> Classify(List<MutableAlarm> records, int cascadeSeconds)
    {
        var rules = store.LoadValidatedAlarmRules();
        var nonstop = Identities(rules, "exactNonStopping");
        var downstream = Identities(rules, "exactDownstreamSymptoms");
        var access = Identities(rules, "exactOperatorAccess");
        var roots = Identities(rules, "exactEquipmentRootCause");
        var excludedZones = (rules["excludedZones"] as JsonArray ?? new JsonArray())
            .Select(x => Regex.Match(x?.GetValue<string>() ?? "", @"\d{1,2}"))
            .Where(x => x.Success).Select(x => int.Parse(x.Value)).ToHashSet();

        foreach (var record in records)
        {
            var id = $"{record.SourceCode}|{record.Line}|{record.Tag}";
            var zoneNumber = ZoneNumberRegex().Match($"{record.Zone} {record.Tag}");
            if (nonstop.Contains(id) || zoneNumber.Success && excludedZones.Contains(int.Parse(zoneNumber.Groups[1].Value)))
            {
                record.Classification = nonstop.Contains(id) ? "Verified Non-Stopping" : "Excluded Zone";
                record.Nuisance = true;
                record.Excluded = true;
            }
            else if (roots.Contains(id) || RootOverrideRegex().IsMatch($"{record.Alarm} {record.Tag}"))
                record.Classification = "Confirmed Root Cause";
            else if (downstream.Contains(id) || DownstreamOverrideRegex().IsMatch($"{record.Alarm} {record.Tag}"))
            {
                record.Classification = "Downstream Symptom";
                record.Nuisance = true;
            }
            else if (access.Contains(id) || AccessRegex().IsMatch($"{record.Alarm} {record.Tag}"))
                record.Classification = "Operator Access";
            else
                record.Classification = "Root-cause Candidate";
        }

        var episodes = records.Where(x => x.Classification == "Operator Access")
            .Select(x => (x.Start, End: (x.End ?? x.Start).AddSeconds(cascadeSeconds))).ToList();
        foreach (var record in records.Where(x => !x.Excluded && x.Classification is not "Operator Access" and not "Confirmed Root Cause"))
        {
            if (!episodes.Any(x => record.Start >= x.Start && record.Start <= x.End)) continue;
            record.Classification = "Suppressed Access Consequence";
            record.Nuisance = true;
        }

        return records.Select(x => new AlarmEvent(x.SourceSystem, x.Line, x.Zone, x.Alarm, x.Tag, x.Start, x.End,
            x.DurationSeconds, x.Acked, x.Classification, x.Nuisance, x.Excluded)).ToList();
    }

    private static HashSet<string> Identities(JsonObject rules, string name) =>
        (rules[name] as JsonArray ?? new JsonArray()).Select(x => x?.GetValue<string>() ?? "").Where(x => x.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);

    private async Task<List<MutableAlarm>> Safe(Task<List<MutableAlarm>> query, string name)
    {
        try { return await query; }
        catch (Exception ex) { logger.LogWarning(ex, "{AlarmSource} alarm query failed", name); return []; }
    }

    private async Task<(bool ok, string detail)> CheckConnectionAsync(string name, string connectionString, CancellationToken token)
    {
        try { await using var connection = new OdbcConnection(connectionString); await connection.OpenAsync(token); return (true, "Connected"); }
        catch (Exception ex) { logger.LogWarning(ex, "{Name} health check failed", name); return (false, ex.Message); }
    }

    private string LegacyConnection() => AlarmConnection("LEGACY_ALARM_SERVER", "visusjp3gtalarm.jaxprod.local", "LEGACY_ALARM_DATABASE", "WWALMDB");
    private string FlexConnection() => AlarmConnection("FLEX_ALARM_SERVER", "visusjpflxalarm.jaxprod.local", "FLEX_ALARM_DATABASE", "RWAEDB");
    private static string AlarmConnection(string serverVariable, string fallbackServer, string databaseVariable, string fallbackDatabase)
    {
        var driver = Environment.GetEnvironmentVariable("ALARM_SQL_DRIVER") ?? "SQL Server";
        var user = Environment.GetEnvironmentVariable("ALARM_SQL_USER") ?? "wwUser";
        var password = Environment.GetEnvironmentVariable("ALARM_SQL_PASSWORD") ?? throw new InvalidOperationException("Set ALARM_SQL_PASSWORD.");
        return $"Driver={{{driver}}};Server={Environment.GetEnvironmentVariable(serverVariable) ?? fallbackServer};Database={Environment.GetEnvironmentVariable(databaseVariable) ?? fallbackDatabase};UID={user};PWD={password};Connection Timeout=15;";
    }

    private static IReadOnlyList<AlarmEvent> Synthetic(string line)
    {
        var start = DateTime.Now.AddMinutes(-42);
        return
        [
            new("Synthetic Alarm DB", line, "Z4", "Z4 servo position deviation", "DEMO_Z4", start, start.AddMinutes(11), 660, true, "Root-cause Candidate", false, false),
            new("Synthetic Alarm DB", line, "Z4", "Z4 controller fault", "DEMO_Z4", start.AddMinutes(2), start.AddMinutes(10), 480, true, "Downstream Symptom", true, false),
            new("Synthetic Alarm DB", line, "Z4", "Zone Stop Pushbutton Actuated", "DEMO_Z4", start.AddMinutes(25), start.AddMinutes(29), 240, true, "Operator Access", false, false),
            new("Synthetic Alarm DB", line, "Z4", "Controller not enabled", "DEMO_Z4", start.AddMinutes(26), start.AddMinutes(29), 180, true, "Suppressed Access Consequence", true, false)
        ];
    }

    private sealed class MutableAlarm(string sourceCode, string sourceSystem, string line, string zone, string alarm, string tag,
        DateTime start, DateTime? end, double durationSeconds, bool acked)
    {
        public string SourceCode { get; } = sourceCode; public string SourceSystem { get; } = sourceSystem;
        public string Line { get; } = line; public string Zone { get; } = zone; public string Alarm { get; } = alarm; public string Tag { get; } = tag;
        public DateTime Start { get; } = start; public DateTime? End { get; } = end; public double DurationSeconds { get; } = durationSeconds; public bool Acked { get; } = acked;
        public string Classification { get; set; } = "Root-cause Candidate"; public bool Nuisance { get; set; } public bool Excluded { get; set; }
    }

    [GeneratedRegex(@"(?:\bZ(?:ONE)?|[_\s])0?(\d{1,2})(?:[A-Z]?\b|_)", RegexOptions.IgnoreCase)] private static partial Regex ZoneNumberRegex();
    [GeneratedRegex(@"453CL.*fail\s+to\s+retract|517CL.*fail\s+to\s+(?:extend|retract)", RegexOptions.IgnoreCase)] private static partial Regex RootOverrideRegex();
    [GeneratedRegex(@"\b(?:210|216)SRV\b.*guard|no[- ]?increment|no[- ]?move", RegexOptions.IgnoreCase)] private static partial Regex DownstreamOverrideRegex();
    [GeneratedRegex(@"zone\s*stop|zstop|guard\s*(door|open)|safety\s*guard|light\s*curtain|door\s*open", RegexOptions.IgnoreCase)] private static partial Regex AccessRegex();
}
