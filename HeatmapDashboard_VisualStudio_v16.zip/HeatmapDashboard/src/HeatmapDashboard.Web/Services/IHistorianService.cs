using HeatmapDashboard.Web.Models;

namespace HeatmapDashboard.Web.Services;

public interface IHistorianService
{
    bool IsLive { get; }
    Task<IReadOnlyDictionary<string, LiveTagValue>> GetLiveValuesAsync(IEnumerable<string> tags, CancellationToken cancellationToken = default);
    Task<IReadOnlyDictionary<string, IReadOnlyList<HistorianSample>>> GetHistoryAsync(
        IEnumerable<string> tags, DateTime start, DateTime end, string retrievalMode, int? resolutionMilliseconds = null,
        CancellationToken cancellationToken = default);
    Task<(bool Ok, string Detail)> CheckHealthAsync(CancellationToken cancellationToken = default);
}
