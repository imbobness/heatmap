using System.Text.Json.Nodes;

namespace HeatmapDashboard.Web.Services;

public sealed class HistoricalRecordService(
    DashboardService dashboard,
    ConfigurationStore store,
    ILogger<HistoricalRecordService> logger)
{
    private readonly object _gate = new();
    private Task? _worker;
    public HistoryBuildStatus Status { get; private set; } = new();

    public object Start()
    {
        lock (_gate)
        {
            if (_worker is { IsCompleted: false }) return new { started = false, running = true };
            Status = new() { Running = true, StartedAt = DateTimeOffset.Now, Total = store.LoadLineTags().Count };
            _worker = Task.Run(RebuildAsync);
            return new { started = true, running = true };
        }
    }

    public object Summary(string line)
    {
        var cache = store.LoadHistoricalRecords();
        var lines = cache["lines"] as JsonObject ?? new JsonObject();
        return new
        {
            line,
            record = lines[line],
            department = cache["department"],
            generatedAt = cache["generatedAt"],
            scanDays = cache["scanDays"]
        };
    }

    private async Task RebuildAsync()
    {
        try
        {
            var outputLines = new JsonObject();
            JsonObject? departmentRecord = null;
            foreach (var line in store.LoadLineTags().Keys)
            {
                Status.CurrentLine = line;
                var data = await dashboard.GetHistoryAsync(line, 120);
                var json = JsonSerializerHelper.ToObject(data);
                var rows = json["rows"] as JsonArray ?? new JsonArray();
                var ranked = rows.OfType<JsonObject>().OrderByDescending(x => x["value"]?.GetValue<double?>() ?? 0).ToList();
                var record = ranked.FirstOrDefault();
                var goal = json["goal"]?.GetValue<double?>() ?? 0;
                var lastGreen = rows.OfType<JsonObject>().LastOrDefault(x => (x["value"]?.GetValue<double?>() ?? 0) >= goal);
                var lineResult = new JsonObject
                {
                    ["record"] = record?.DeepClone(),
                    ["lastGreen"] = lastGreen?.DeepClone(),
                    ["top10"] = new JsonArray(ranked.Take(10).Select(x => x.DeepClone()).ToArray())
                };
                outputLines[line] = lineResult;
                if (record is not null && (departmentRecord is null || (record["value"]?.GetValue<double?>() ?? 0) > (departmentRecord["value"]?.GetValue<double?>() ?? 0)))
                {
                    departmentRecord = record.DeepClone() as JsonObject;
                    if (departmentRecord is not null) departmentRecord["line"] = line;
                }
                Status.Completed++;
            }
            await store.SaveHistoricalRecordsAsync(new JsonObject
            {
                ["version"] = 1, ["lines"] = outputLines,
                ["department"] = new JsonObject { ["record"] = departmentRecord },
                ["generatedAt"] = DateTimeOffset.Now.ToString("O"), ["scanDays"] = 60
            });
            Status.Running = false; Status.CurrentLine = null; Status.FinishedAt = DateTimeOffset.Now;
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Historical record rebuild failed");
            Status.Running = false; Status.Error = ex.Message; Status.FinishedAt = DateTimeOffset.Now;
        }
    }
}

public sealed class HistoryBuildStatus
{
    public bool Running { get; set; }
    public int Completed { get; set; }
    public int Total { get; set; }
    public string? CurrentLine { get; set; }
    public DateTimeOffset? StartedAt { get; set; }
    public DateTimeOffset? FinishedAt { get; set; }
    public string? Error { get; set; }
}

internal static class JsonSerializerHelper
{
    public static JsonObject ToObject(object value) =>
        JsonNode.Parse(System.Text.Json.JsonSerializer.Serialize(value, new System.Text.Json.JsonSerializerOptions
        { PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase })) as JsonObject ?? new JsonObject();
}
