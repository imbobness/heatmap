using System.Diagnostics;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.Json.Nodes;

namespace HeatmapDashboard.Web.Services;

public sealed class EmailService(ILogger<EmailService> logger)
{
    public async Task SendAsync(JsonObject config, IReadOnlyList<string> recipients, string subject, string body, bool html, CancellationToken token)
    {
        if (recipients.Count == 0) throw new InvalidOperationException("No enabled recipients are configured.");
        var transport = config["transport"]?.GetValue<string>() ?? "outlook";
        if (transport.Equals("smtp", StringComparison.OrdinalIgnoreCase))
            await SendSmtpAsync(config, recipients, subject, body, html, token);
        else
            await SendOutlookAsync(recipients, subject, body, html, token);
    }

    private static async Task SendOutlookAsync(IReadOnlyList<string> recipients, string subject, string body, bool html, CancellationToken token)
    {
        const string script = """
            $ErrorActionPreference = 'Stop'
            $outlook = New-Object -ComObject Outlook.Application
            $mail = $outlook.CreateItem(0)
            $mail.To = $env:HEATMAP_MAIL_TO
            $mail.Subject = $env:HEATMAP_MAIL_SUBJECT
            if ($env:HEATMAP_MAIL_IS_HTML -eq '1') { $mail.HTMLBody = $env:HEATMAP_MAIL_BODY } else { $mail.Body = $env:HEATMAP_MAIL_BODY }
            $mail.Send()
            """;
        var start = new ProcessStartInfo("powershell")
        {
            UseShellExecute = false, RedirectStandardError = true, CreateNoWindow = true
        };
        start.ArgumentList.Add("-NoProfile");
        start.ArgumentList.Add("-NonInteractive");
        start.ArgumentList.Add("-Command");
        start.ArgumentList.Add(script);
        start.Environment["HEATMAP_MAIL_TO"] = string.Join(';', recipients);
        start.Environment["HEATMAP_MAIL_SUBJECT"] = subject;
        start.Environment["HEATMAP_MAIL_BODY"] = body;
        start.Environment["HEATMAP_MAIL_IS_HTML"] = html ? "1" : "0";
        using var process = Process.Start(start) ?? throw new InvalidOperationException("Could not start PowerShell Outlook transport.");
        await process.WaitForExitAsync(token);
        if (process.ExitCode != 0) throw new InvalidOperationException(await process.StandardError.ReadToEndAsync(token));
    }

    private async Task SendSmtpAsync(JsonObject config, IReadOnlyList<string> recipients, string subject, string body, bool html, CancellationToken token)
    {
        var smtp = config["smtp"] as JsonObject ?? new JsonObject();
        var host = smtp["host"]?.GetValue<string>() ?? throw new InvalidOperationException("SMTP host is not configured.");
        var port = smtp["port"]?.GetValue<int?>() ?? 587;
        using var message = new MailMessage { Subject = subject, Body = body, IsBodyHtml = html, BodyEncoding = Encoding.UTF8 };
        message.From = new MailAddress(config["fromAddress"]?.GetValue<string>() ?? "heatmap@localhost");
        foreach (var recipient in recipients) message.To.Add(recipient);
        using var client = new SmtpClient(host, port) { EnableSsl = smtp["startTls"]?.GetValue<bool?>() ?? true };
        var usernameName = smtp["usernameEnv"]?.GetValue<string>() ?? "ALERT_SMTP_USER";
        var passwordName = smtp["passwordEnv"]?.GetValue<string>() ?? "ALERT_SMTP_PASSWORD";
        var username = Environment.GetEnvironmentVariable(usernameName);
        if (!string.IsNullOrWhiteSpace(username)) client.Credentials = new NetworkCredential(username, Environment.GetEnvironmentVariable(passwordName));
        logger.LogInformation("Sending {Subject} to {RecipientCount} recipients", subject, recipients.Count);
        await client.SendMailAsync(message, token);
    }
}
