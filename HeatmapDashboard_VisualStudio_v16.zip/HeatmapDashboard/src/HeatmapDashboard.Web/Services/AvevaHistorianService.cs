using System.Data.Odbc;
using HeatmapDashboard.Web.Models;
using Microsoft.Extensions.Options;

namespace HeatmapDashboard.Web.Services;

public sealed class AvevaHistorianService(IOptions<DashboardOptions> options, ILogger<AvevaHistorianService> logger) : IHistorianService
{
    private readonly DashboardOptions _options = options.Value;
    public bool IsLive => true;

    public async Task<IReadOnlyDictionary<string, LiveTagValue>> GetLiveValuesAsync(
        IEnumerable<string> sourceTags, CancellationToken cancellationToken = default)
    {
        var tags = sourceTags.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var result = new Dictionary<string, LiveTagValue>(StringComparer.OrdinalIgnoreCase);
        if (tags.Count == 0) return result;

        await using var connection = new OdbcConnection(BuildConnectionString());
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = $"""
            SELECT DateTime, TagName, Value, Quality, QualityDetail
            FROM Runtime.dbo.AnalogLive
            WHERE TagName IN ({string.Join(',', tags.Select(_ => "?"))})
            """;
        AddParameters(command, tags.Cast<object>());
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var tag = reader.GetString(1);
            result[tag] = new(
                reader.IsDBNull(0) ? null : reader.GetDateTime(0),
                reader.IsDBNull(2) ? null : Convert.ToDouble(reader.GetValue(2)),
                reader.IsDBNull(3) ? null : Convert.ToInt32(reader.GetValue(3)),
                reader.IsDBNull(4) ? null : Convert.ToString(reader.GetValue(4)));
        }
        return result;
    }

    public async Task<IReadOnlyDictionary<string, IReadOnlyList<HistorianSample>>> GetHistoryAsync(
        IEnumerable<string> sourceTags, DateTime start, DateTime end, string retrievalMode,
        int? resolutionMilliseconds = null, CancellationToken cancellationToken = default)
    {
        var tags = sourceTags.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var grouped = tags.ToDictionary(x => x, _ => new List<HistorianSample>(), StringComparer.OrdinalIgnoreCase);
        if (tags.Count == 0) return grouped.ToDictionary(x => x.Key, x => (IReadOnlyList<HistorianSample>)x.Value);

        var resolutionClause = resolutionMilliseconds.HasValue ? " AND wwResolution = ?" : string.Empty;
        await using var connection = new OdbcConnection(BuildConnectionString());
        await connection.OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandTimeout = 90;
        command.CommandText = $"""
            SELECT DateTime, TagName, Value
            FROM Runtime.dbo.AnalogHistory
            WHERE TagName IN ({string.Join(',', tags.Select(_ => "?"))})
              AND DateTime >= ? AND DateTime <= ?
              AND wwRetrievalMode = ?{resolutionClause}
            ORDER BY DateTime, TagName
            """;
        AddParameters(command, tags.Cast<object>().Concat([start, end, retrievalMode]));
        if (resolutionMilliseconds.HasValue) AddParameters(command, [resolutionMilliseconds.Value]);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            var tag = reader.GetString(1);
            if (!grouped.TryGetValue(tag, out var list)) continue;
            list.Add(new(reader.GetDateTime(0), reader.IsDBNull(2) ? null : Convert.ToDouble(reader.GetValue(2))));
        }
        return grouped.ToDictionary(x => x.Key, x => (IReadOnlyList<HistorianSample>)x.Value, StringComparer.OrdinalIgnoreCase);
    }

    public async Task<(bool Ok, string Detail)> CheckHealthAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            await using var connection = new OdbcConnection(BuildConnectionString());
            await connection.OpenAsync(cancellationToken);
            return (true, $"Connected to {_options.Historian.Server}/{_options.Historian.Database}");
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Historian health check failed");
            return (false, ex.Message);
        }
    }

    private string BuildConnectionString()
    {
        var h = _options.Historian;
        var driver = Environment.GetEnvironmentVariable("WW_SQL_DRIVER") ?? h.Driver;
        var server = Environment.GetEnvironmentVariable("WW_SQL_SERVER") ?? h.Server;
        var database = Environment.GetEnvironmentVariable("WW_SQL_DATABASE") ?? h.Database;
        var builder = new OdbcConnectionStringBuilder
        {
            ["Driver"] = $"{{{driver.Trim('{', '}')}}}",
            ["Server"] = server,
            ["Database"] = database,
            ["TrustServerCertificate"] = h.TrustServerCertificate ? "yes" : "no",
            ["Encrypt"] = h.Encrypt ? "yes" : "no"
        };
        var username = Environment.GetEnvironmentVariable(h.UsernameEnvironmentVariable);
        var password = Environment.GetEnvironmentVariable(h.PasswordEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(username))
        {
            if (string.IsNullOrWhiteSpace(password)) throw new InvalidOperationException($"Set {h.PasswordEnvironmentVariable}.");
            builder["UID"] = username;
            builder["PWD"] = password;
        }
        else
        {
            builder["Trusted_Connection"] = h.TrustedConnection ? "yes" : "no";
        }
        return builder.ConnectionString;
    }

    private static void AddParameters(OdbcCommand command, IEnumerable<object> values)
    {
        foreach (var value in values) command.Parameters.Add(new OdbcParameter { Value = value });
    }
}
