using System.Net;
using System.Text;
using System.Text.Json.Nodes;
using HeatmapDashboard.Web.Models;
using HeatmapDashboard.Web.Services;
using Microsoft.Extensions.Options;

namespace HeatmapDashboard.Web.Workers;

public sealed class NotificationWorker(
    ConfigurationStore store,
    DashboardService dashboard,
    IHistorianService historian,
    EmailService email,
    IOptions<DashboardOptions> dashboardOptions,
    ILogger<NotificationWorker> logger) : BackgroundService
{
    private readonly DashboardOptions _dashboardOptions = dashboardOptions.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMinutes(1));
        do
        {
            try { await RunOnceAsync(DateTime.Now, stoppingToken); }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested) { break; }
            catch (Exception ex) { logger.LogError(ex, "Notification worker failed"); await SaveErrorAsync(ex); }
        } while (await timer.WaitForNextTickAsync(stoppingToken));
    }

    public async Task RunOnceAsync(DateTime now, CancellationToken token = default)
    {
        var config = store.LoadAlerts();
        if (!(config["enabled"]?.GetValue<bool?>() ?? false) || !_dashboardOptions.IsLive) return;
        await RunPerformanceAlertAsync(now, config, token);
        await RunDailyDowntimeSummaryAsync(now, config, token);
        await RunZoneAlertsAsync(now, config, token);
    }

    private async Task RunPerformanceAlertAsync(DateTime now, JsonObject config, CancellationToken token)
    {
        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var startHour = config["performanceStartHourIntoShift"]?.GetValue<int?>() ?? 2;
        if (now < shiftStart.AddHours(startHour)) return;
        var key = now.ToString("yyyy-MM-ddTHH:00:00");
        var state = store.LoadAlertState();
        state["performanceSent"] ??= new JsonObject();
        if (state["performanceSent"]?[key] is not null) return;

        var overview = JsonSerializerHelper.ToObject(await dashboard.GetOverviewAsync(token));
        var rows = overview["rows"] as JsonArray ?? new JsonArray();
        var threshold = config["performanceThresholdPercent"]?.GetValue<double?>() ?? 95;
        var low = rows.OfType<JsonObject>().Where(x => (x["attainment"]?.GetValue<double?>() ?? 100) < threshold).ToList();
        if (low.Count == 0) return;
        var projection = rows.OfType<JsonObject>().Sum(x => x["currentProjection"]?.GetValue<double?>() ?? 0);
        var goal = rows.OfType<JsonObject>().Sum(x => x["goal"]?.GetValue<double?>() ?? 0);
        var overall = goal > 0 ? projection / goal * 100 : 0;
        var table = string.Join("", low.Select(x => $"<tr><td>{WebUtility.HtmlEncode(x["line"]?.GetValue<string>())}</td><td>{x["attainment"]?.GetValue<double?>():N1}%</td><td>{x["currentProjection"]?.GetValue<double?>():N0}</td><td>{x["goal"]?.GetValue<double?>():N0}</td></tr>"));
        var body = $"<html><body style='font-family:Segoe UI,Arial'><h2>3GT Shift Performance Alert</h2><p><b>Overall projected attainment:</b> {overall:N1}%</p><table><tr><th>Line</th><th>Attainment</th><th>Projection</th><th>Goal</th></tr>{table}</table><p style='color:#666'>Dashboard projection only; not an authoritative manufacturing record.</p></body></html>";
        await email.SendAsync(config, store.ResolveRecipients("performance"), $"3GT Shift Alert: {low.Count} line(s) below {threshold:N0}% | Overall {overall:N1}%", body, true, token);
        var sent = state["performanceSent"] as JsonObject ?? new JsonObject();
        sent[key] = new JsonObject { ["sent"] = true, ["lines"] = new JsonArray(low.Select(x => JsonValue.Create(x["line"]?.GetValue<string>())).ToArray()), ["overallAttainment"] = overall };
        state["performanceSent"] = sent.DeepClone();
        await store.SaveAlertStateAsync(state);
    }

    private async Task RunZoneAlertsAsync(DateTime now, JsonObject config, CancellationToken token)
    {
        var state = store.LoadAlertState();
        var checkMinutes = config["zoneCheckMinutes"]?.GetValue<int?>() ?? 5;
        if (DateTime.TryParse(state["lastZoneCheck"]?.GetValue<string>(), out var last) && now - last < TimeSpan.FromMinutes(checkMinutes)) return;
        var idleMinutes = config["zoneIdleMinutes"]?.GetValue<int?>() ?? 15;
        if (now - ShiftMath.CurrentShiftStart(now) < TimeSpan.FromMinutes(idleMinutes)) return;
        var configuredZones = (config["zoneKeys"] as JsonArray ?? new JsonArray()).Select(x => x?.GetValue<string>() ?? "").ToHashSet(StringComparer.OrdinalIgnoreCase);
        var maps = store.LoadLineTags().Where(x => store.LineIsInProduction(x.Key)).ToList();
        var owners = maps.SelectMany(line => line.Value.Where(x => configuredZones.Contains(x.Key)).Select(x => (line: line.Key, zone: x.Key, tag: x.Value))).ToList();
        var history = await historian.GetHistoryAsync(owners.Select(x => x.tag), now.AddMinutes(-idleMinutes), now, "Delta", null, token);
        var zones = state["zones"] as JsonObject ?? new JsonObject();
        foreach (var owner in owners)
        {
            var samples = history.GetValueOrDefault(owner.tag) ?? Array.Empty<HistorianSample>();
            var delta = ShiftMath.AccumulatedCounterDelta(samples);
            var key = $"{owner.line}|{owner.zone}";
            var prior = zones[key] as JsonObject ?? new JsonObject();
            var alerted = prior["alerted"]?.GetValue<bool?>() ?? false;
            var idle = samples.Count >= 2 && delta <= 0;
            if (idle && !alerted)
            {
                await email.SendAsync(config, store.ResolveRecipients("zone"), $"3GT Zone Alert: {owner.line} {owner.zone} produced zero lenses for {idleMinutes} minutes",
                    $"3GT Heatmap zone inactivity alert\n\nLine: {owner.line}\nZone: {owner.zone}\nTag: {owner.tag}\nProduction in last {idleMinutes} minutes: {delta:N0}\nWindow: {now.AddMinutes(-idleMinutes):h:mm tt} to {now:h:mm tt}", false, token);
                zones[key] = new JsonObject { ["line"] = owner.line, ["zone"] = owner.zone, ["tag"] = owner.tag, ["alerted"] = true,
                    ["idleSince"] = now.AddMinutes(-idleMinutes).ToString("O"), ["lastChecked"] = now.ToString("O"), ["lastDelta"] = delta };
            }
            else if (!idle && alerted)
            {
                var idleSince = DateTime.TryParse(prior["idleSince"]?.GetValue<string>(), out var parsed) ? parsed : now.AddMinutes(-idleMinutes);
                var downtime = Math.Max(0, (now - idleSince).TotalMinutes);
                if (config["sendRecoveryEmails"]?.GetValue<bool?>() ?? true)
                    await email.SendAsync(config, store.ResolveRecipients("zone"), $"3GT Zone Recovery: {owner.line} {owner.zone} production resumed",
                        $"Production resumed.\n\nLine: {owner.line}\nZone: {owner.zone}\nTag: {owner.tag}\nDetected stop began: {idleSince:yyyy-MM-dd h:mm tt}\nRecovery detected: {now:yyyy-MM-dd h:mm tt}\nDetected zone downtime: {downtime:N1} minutes\n\nHistorian-derived counter inactivity; not a CMMS-validated event.", false, token);
                zones[key] = new JsonObject { ["line"] = owner.line, ["zone"] = owner.zone, ["tag"] = owner.tag, ["alerted"] = false,
                    ["recovered"] = now.ToString("O"), ["lastChecked"] = now.ToString("O"), ["lastDelta"] = delta };
            }
            else
            {
                prior["line"] = owner.line; prior["zone"] = owner.zone; prior["tag"] = owner.tag; prior["alerted"] = alerted && idle;
                prior["lastChecked"] = now.ToString("O"); prior["lastDelta"] = delta; zones[key] = prior;
            }
        }
        state["zones"] = zones.DeepClone(); state["lastZoneCheck"] = now.ToString("O");
        await store.SaveAlertStateAsync(state);
    }

    public static bool DailySummaryDue(DateTime now, JsonObject config, JsonObject state)
    {
        if (!(config["dailyDowntimeSummaryEnabled"]?.GetValue<bool?>() ?? true)) return false;
        var hour = config["dailyDowntimeSummaryHour"]?.GetValue<int?>() ?? 17;
        var minute = config["dailyDowntimeSummaryMinute"]?.GetValue<int?>() ?? 0;
        var sendAt = now.Date.AddHours(hour).AddMinutes(minute);
        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var alreadySent = state["dailySummarySent"]?[shiftStart.Date.ToString("yyyy-MM-dd")] is not null;
        return now >= sendAt && shiftStart.Hour == 6 && !alreadySent;
    }

    private async Task RunDailyDowntimeSummaryAsync(DateTime now, JsonObject config, CancellationToken token)
    {
        var state = store.LoadAlertState();
        state["dailySummarySent"] ??= new JsonObject();
        if (!DailySummaryDue(now, config, state)) return;

        var hour = config["dailyDowntimeSummaryHour"]?.GetValue<int?>() ?? 17;
        var minute = config["dailyDowntimeSummaryMinute"]?.GetValue<int?>() ?? 0;
        var shiftStart = ShiftMath.CurrentShiftStart(now);
        var sendAt = now.Date.AddHours(hour).AddMinutes(minute);
        var minimumIdle = config["dailyDowntimeMinimumIdleMinutes"]?.GetValue<double?>() ?? 5;
        var rows = await dashboard.GetDowntimeRowsAsync(shiftStart, sendAt, minimumIdle, token);
        var proxyZone = config["lineDowntimeZone"]?.GetValue<string>() ?? "Z6_IN";
        var lineRows = rows.Where(x => x.Zone.Equals(proxyZone, StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Line).ToList();
        var totalMinutes = lineRows.Sum(x => x.DowntimeMinutes);
        var subject = $"3GT Day-Shift Downtime Summary: {shiftStart:yyyy-MM-dd} | {totalMinutes:N0} line-minutes";
        var body = BuildDailySummaryHtml(shiftStart, sendAt, minimumIdle, proxyZone, lineRows, rows);
        await email.SendAsync(config, store.ResolveRecipients("performance"), subject, body, true, token);

        var sent = state["dailySummarySent"] as JsonObject ?? new JsonObject();
        sent[shiftStart.Date.ToString("yyyy-MM-dd")] = new JsonObject
        {
            ["sentAt"] = now.ToString("O"), ["windowStart"] = shiftStart.ToString("O"), ["windowEnd"] = sendAt.ToString("O"),
            ["lineDowntimeMinutes"] = totalMinutes, ["lines"] = lineRows.Count, ["zoneRows"] = rows.Count
        };
        foreach (var old in sent.OrderBy(x => x.Key).Take(Math.Max(0, sent.Count - 45)).Select(x => x.Key).ToList()) sent.Remove(old);
        state["dailySummarySent"] = sent.DeepClone();
        state["lastRun"] = now.ToString("O");
        state["lastError"] = null;
        await store.SaveAlertStateAsync(state);
    }

    public static string BuildDailySummaryHtml(DateTime start, DateTime end, double threshold, string proxyZone,
        IReadOnlyList<ZoneDowntimeRow> lines, IReadOnlyList<ZoneDowntimeRow> zones)
    {
        static string E(string value) => WebUtility.HtmlEncode(value);
        static string N(double value, int decimals = 1) => value.ToString($"N{decimals}");
        static string Color(string status) => status == "STOPPED" ? "#dc2626" : status == "RUNNING" ? "#16a34a" : "#64748b";
        static string Row(ZoneDowntimeRow row, bool includeZone) => $"<tr><td>{E(row.Line)}</td>{(includeZone ? $"<td>{E(row.Zone)}</td>" : "")}<td>{N(row.DowntimeMinutes)}</td><td>{row.EventCount}</td><td>{N(row.LongestStopMinutes)}</td><td>{N(row.Production, 0)}</td><td>{N(row.CoveragePercent)}%</td><td style='color:{Color(row.CurrentStatus)};font-weight:bold'>{E(row.CurrentStatus)}</td></tr>";
        var lineHtml = string.Join("", lines.Select(x => Row(x, false)));
        var zoneHtml = string.Join("", zones.OrderBy(x => x.Line).ThenBy(x => x.Zone).Select(x => Row(x, true)));
        return $"""
            <html><body style='font-family:Segoe UI,Arial'>
            <h2>3GT Day-Shift Downtime Summary</h2>
            <p><b>Window:</b> {start:yyyy-MM-dd h:mm tt} to {end:h:mm tt}<br>
            <b>Method:</b> counter unchanged for at least {threshold:g} consecutive minutes<br>
            <b>Line downtime proxy:</b> {E(proxyZone)}</p>
            <h3>By Line</h3><table style='border-collapse:collapse;width:100%'><tr style='background:#1f4e78;color:white'><th>Line</th><th>Downtime min</th><th>Stops</th><th>Longest min</th><th>Production</th><th>Data coverage</th><th>At 5 PM</th></tr>{lineHtml}</table>
            <h3>By Zone</h3><p><i>Zone downtime overlaps and must not be summed as line downtime.</i></p>
            <table style='border-collapse:collapse;width:100%'><tr style='background:#1f4e78;color:white'><th>Line</th><th>Zone</th><th>Downtime min</th><th>Stops</th><th>Longest min</th><th>Production</th><th>Data coverage</th><th>At 5 PM</th></tr>{zoneHtml}</table>
            <p style='color:#666'>Historian-derived no-increment analysis; not a CMMS-validated downtime record. Planned downtime is not excluded until a reliable exclusion source is configured.</p>
            </body></html>
            """;
    }

    private async Task SaveErrorAsync(Exception exception)
    {
        try { var state = store.LoadAlertState(); state["lastError"] = exception.Message; await store.SaveAlertStateAsync(state); }
        catch { /* avoid recursive worker failure */ }
    }
}
