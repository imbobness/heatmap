using System.Text.Json.Nodes;
using HeatmapDashboard.Web.Models;
using HeatmapDashboard.Web.Workers;

namespace HeatmapDashboard.Tests;

public sealed class NotificationWorkerTests
{
    private static JsonObject Config() => new()
    {
        ["dailyDowntimeSummaryEnabled"] = true,
        ["dailyDowntimeSummaryHour"] = 17,
        ["dailyDowntimeSummaryMinute"] = 0
    };

    [Fact]
    public void SummaryDoesNotRunBeforeFivePm()
    {
        Assert.False(NotificationWorker.DailySummaryDue(new DateTime(2026, 9, 3, 16, 59, 0), Config(), new JsonObject()));
    }

    [Fact]
    public void SummaryRunsAtFiveAndCanCatchUp()
    {
        Assert.True(NotificationWorker.DailySummaryDue(new DateTime(2026, 9, 3, 17, 0, 0), Config(), new JsonObject()));
        Assert.True(NotificationWorker.DailySummaryDue(new DateTime(2026, 9, 3, 17, 45, 0), Config(), new JsonObject()));
    }

    [Fact]
    public void SuccessfulDatePreventsDuplicate()
    {
        var state = new JsonObject { ["dailySummarySent"] = new JsonObject { ["2026-09-03"] = new JsonObject() } };
        Assert.False(NotificationWorker.DailySummaryDue(new DateTime(2026, 9, 3, 17, 5, 0), Config(), state));
    }

    [Fact]
    public void EmailClearlySeparatesLineAndZoneDowntime()
    {
        var row = new ZoneDowntimeRow("TAM01", "Z6_IN", "TAG", 42, 2, 30, 1000, 100, "RUNNING");
        var html = NotificationWorker.BuildDailySummaryHtml(new DateTime(2026, 9, 3, 6, 0, 0),
            new DateTime(2026, 9, 3, 17, 0, 0), 5, "Z6_IN", [row], [row]);
        Assert.Contains("By Line", html);
        Assert.Contains("By Zone", html);
        Assert.Contains("must not be summed", html);
        Assert.Contains("Planned downtime is not excluded", html);
    }
}
