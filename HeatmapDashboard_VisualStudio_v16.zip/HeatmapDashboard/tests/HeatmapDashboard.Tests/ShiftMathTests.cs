using HeatmapDashboard.Web.Models;
using HeatmapDashboard.Web.Services;

namespace HeatmapDashboard.Tests;

public sealed class ShiftMathTests
{
    [Theory]
    [InlineData(2026, 9, 3, 5, 2026, 9, 2, 18)]
    [InlineData(2026, 9, 3, 6, 2026, 9, 3, 6)]
    [InlineData(2026, 9, 3, 17, 2026, 9, 3, 6)]
    [InlineData(2026, 9, 3, 18, 2026, 9, 3, 18)]
    public void CurrentShiftStartUsesSixToSixBoundaries(int y, int m, int d, int hour, int ey, int em, int ed, int eh)
    {
        Assert.Equal(new DateTime(ey, em, ed, eh, 0, 0), ShiftMath.CurrentShiftStart(new DateTime(y, m, d, hour, 0, 0)));
    }

    [Fact]
    public void NoIncrementSummaryFindsSustainedStopAndProduction()
    {
        var start = new DateTime(2026, 9, 3, 6, 0, 0);
        var samples = new List<HistorianSample>();
        for (var minute = 0; minute <= 15; minute++)
        {
            var value = minute <= 3 ? minute : minute <= 10 ? 3 : minute - 7;
            samples.Add(new(start.AddMinutes(minute), value));
        }
        var metric = ShiftMath.NoIncrementSummary(samples, start, start.AddMinutes(15), 5);
        Assert.Single(metric.Intervals);
        Assert.Equal(7, metric.DowntimeMinutes);
        Assert.Equal(1, metric.EventCount);
        Assert.Equal("RUNNING", metric.CurrentStatus);
        Assert.True(metric.Production > 0);
    }

    [Fact]
    public void HourlyBarsAllocateOverlapWithoutDoubleCounting()
    {
        var start = new DateTime(2026, 9, 3, 6, 0, 0);
        var bars = ShiftMath.HourlyBars(start, start.AddHours(2),
            [new DowntimeInterval(start.AddMinutes(50), start.AddMinutes(70))]);
        Assert.Equal(2, bars.Count);
        Assert.Equal(10, bars[0].DowntimeMinutes);
        Assert.Equal(10, bars[1].DowntimeMinutes);
    }
}
