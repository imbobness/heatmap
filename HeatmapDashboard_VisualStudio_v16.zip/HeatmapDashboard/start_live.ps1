$ErrorActionPreference = 'Stop'
$env:Dashboard__Mode = 'Live'
dotnet run --project "$PSScriptRoot\src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj" --urls http://localhost:8787
