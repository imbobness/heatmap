# EZHoist Power BI Starter Kit

This kit converts the supplied `complete_heatmap_app_v13_19_historian_downtime` logic into a Power BI Desktop model. It does not contain passwords and it does not write to the historian, alarm databases, machines, CMMS, or production records.

## Recommended model

Use a composite model:

| Table | Source | Storage mode | Purpose |
|---|---|---|---|
| `FactLive` | `01_Historian_Live_DirectQuery.sql` | DirectQuery | Latest values, source health, staleness |
| `FactRecent` | `02_Historian_Recent_48h_DirectQuery.sql` | DirectQuery | Current shift, hourly trends, rate, yield |
| `FactShiftHistory` | `03_Completed_Shift_History_Import.sql` | Import | Last 60 days of completed shifts |
| `FactDowntime` | `04_Historian_Downtime_Intervals_DirectQuery.sql` | DirectQuery | 15+ minute no-increment intervals |
| `FactLegacyAlarms` | `05_Legacy_Alarms_DirectQuery.sql` | DirectQuery | Legacy alarms |
| `FactFlexAlarms` | `06_FLEX_Alarms_DirectQuery.sql` | DirectQuery | FLEX alarms |
| `DimLine`, `DimTag`, `DimTarget` | supplied M or CSV | Import | Configuration and relationships |

The current-shift pages can refresh every five minutes while Power BI Desktop remains open. Completed-shift history stays imported so every visual does not repeatedly scan 60 days of historian data.

## Build steps

1. Open Power BI Desktop while connected to the plant network.
2. Select **Get data > SQL Server**.
3. Use historian server `10.74.51.114` and database `Runtime`.
4. Select **DirectQuery**. Open **Advanced options**, paste `SQL/01_Historian_Live_DirectQuery.sql`, and name the table `FactLive`.
5. Repeat with `SQL/02_Historian_Recent_48h_DirectQuery.sql` as `FactRecent` and `SQL/04_Historian_Downtime_Intervals_DirectQuery.sql` as `FactDowntime`.
6. Add `SQL/03_Completed_Shift_History_Import.sql` as `FactShiftHistory`, choosing **Import**.
7. In **Transform data > New source > Blank query > Advanced Editor**, paste each of `PowerQuery/DimLine.m`, `DimTag.m`, and `DimTarget.m`.
8. Add the two alarm servers separately if your SQL account can access them. Append the two alarm tables only after their column types match.
9. Create a blank Measures table and add the expressions in `DAX/Measures.dax` one measure at a time.
10. Import `Config/EZHoist_PowerBI_Theme.json` from **View > Themes > Browse for themes**.
11. On near-live pages, open page formatting and set **Page refresh > Automatic > 5 minutes**.

## Credentials

Use your approved read-only SQL identity in Power BI's Data source settings. Do not place a username or password in M, DAX, SQL files, or the PBIX. Every coworker opening the PBIX must have network access and approved permissions for each source.

## Desktop-only sharing limitation

Power BI Desktop does not host a centrally refreshed report. You can share the PBIX, but each recipient must open it locally and authenticate to the historian/alarm databases. Static PDF or PowerPoint exports can be shared without database access, but they are not interactive or live.

To provide one centrally hosted report later, publish to Power BI Service and configure a standard on-premises data gateway. Report sharing generally requires Power BI Pro/PPU for authors and viewers unless the workspace is on Premium/Fabric capacity.

## Important validation checks

- Confirm historian timestamps are local Eastern time rather than UTC before validating 06:00/18:00 shift boundaries.
- Verify all counter tags against the current approved Canary/AVEVA mapping before release.
- The source application maps TAM20 with a `P` legacy prefix. Earlier migration work identified TAM20 as `S`; validate this specific line before commissioning.
- Keep TAM04, TAM15, and TAM16 disabled until their mappings are confirmed.
- Keep TAM32 and TAM33 excluded from current fleet totals because the supplied line-status file marks them out of production.
- Historian no-increment downtime is an analytical estimate. CMMS remains the validated downtime source.
- Alarm zones 7 through 10 are excluded from output-related alarm analytics.
- Severity and priority remain metadata; they are not proof that an alarm stopped production.

## Performance precautions

- Start with five-minute automatic page refresh. Do not use one-minute refresh until the Recent and Downtime queries are timed on the production historian.
- Keep the current DirectQuery window at 48 hours.
- Use the imported shift-history table for 30-/60-day charts.
- Avoid placing more than four high-cardinality DirectQuery visuals on one page.
- Use a single Line slicer and synchronized Date/Shift slicers instead of separate SQL queries per visual.

## Power BI native-query compatibility

The SQL files are intentionally written without `WITH` common-table expressions and without trailing semicolons. Power BI DirectQuery wraps native SQL in an outer query; CTEs or a final semicolon can produce errors such as `Incorrect syntax near WITH` or `Incorrect syntax near ')'`.

Test `01_Historian_Live_DirectQuery.sql` first. Only proceed to the 48-hour and downtime queries after the live query loads successfully.

AVEVA's `INSQL` linked provider requires at least one literal historian tag in every `AnalogHistory` request. The history SQL files therefore include an explicit `h.TagName IN (...)` predicate inside the historian scan in addition to the tag-map join. Do not remove that predicate; a join by itself may not be pushed down to INSQL and produces `History queries must contain at least one valid tagname`.
