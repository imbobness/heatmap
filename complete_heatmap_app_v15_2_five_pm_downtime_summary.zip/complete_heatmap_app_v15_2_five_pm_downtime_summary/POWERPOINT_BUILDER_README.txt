MOI 30-Day Zone Trend Deck Generator v2

Each manufacturing-line slide now includes:
- 5 Shift Average
- 14 Shift Average
- 20 Shift Average
- 30 Day Average
- Shift Target
- Average Deviation from Target
- Mean

The trend graph remains Zone 1 In vs Zone 6 Out / Loader Out over the last 30 days
(60 completed 12-hour shifts).

Average Deviation is signed:
  positive = average production above target
  negative = average production below target

The 20 Shift Average card turns green when it meets/exceeds shift target and red
when it remains below target.

Usage:
1. Put generate_30_day_zone_trend_deck.py beside app.py.
2. Run:
       python generate_30_day_zone_trend_deck.py

Optional:
       python generate_30_day_zone_trend_deck.py --lines TAM01,TAM02,TAM18
       python generate_30_day_zone_trend_deck.py --synthetic
