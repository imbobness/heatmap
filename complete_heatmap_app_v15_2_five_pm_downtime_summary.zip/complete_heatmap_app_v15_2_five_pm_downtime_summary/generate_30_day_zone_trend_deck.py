"""
generate_30_day_zone_trend_deck.py

Creates a PowerPoint deck with one 30-day trend slide per manufacturing line,
comparing Zone 1 In vs Zone 6 Out / Loader Out.

Place this file in the same folder as app.py from the MOI dashboard and run:

    python generate_30_day_zone_trend_deck.py

Optional examples:

    python generate_30_day_zone_trend_deck.py --days 30 --out reports/zone_trends.pptx
    python generate_30_day_zone_trend_deck.py --lines TAM01,TAM02,TAM18
    python generate_30_day_zone_trend_deck.py --include-out-of-production
    python generate_30_day_zone_trend_deck.py --synthetic

Live mode uses the same Wonderware / AVEVA read-only connection and tag map as app.py.
This script does not write to Wonderware, Canary, Ignition, alarm databases, PLCs,
recipes, setpoints, CMMS, or any source system. It only creates a local .pptx file.
"""

from __future__ import annotations

import argparse
import importlib
import math
import os
import random
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

try:
    import matplotlib.pyplot as plt
except Exception as exc:
    raise SystemExit(
        "Missing matplotlib. Install with: python -m pip install matplotlib\n"
        f"Original error: {exc}"
    )

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN
    from pptx.enum.shapes import MSO_SHAPE
except Exception as exc:
    raise SystemExit(
        "Missing python-pptx. Install with: python -m pip install python-pptx\n"
        f"Original error: {exc}"
    )


APP = importlib.import_module("app")

# Zone-key aliases. The dashboard currently uses Z6_IN as the Loader Out counter
# on many lines, so Z6_IN is intentionally included in Z6_OUT_KEYS.
Z1_IN_KEYS = ("Z1_IN", "Z1", "Z1_OUT", "Z1_GOOD", "Z1_GOODCOUNT")
Z6_OUT_KEYS = ("Z6_OUT", "Z6_IN", "LOADER_OUT", "LOADER", "LOADER_OUTCOUNT", "ALI_OUT")


def resolve_tag(line: str, keys: Iterable[str]) -> Tuple[Optional[str], Optional[str]]:
    tags = APP.ALL_LINE_MAP.get(line, {})
    for key in keys:
        value = tags.get(key)
        if value:
            return key, value
    return None, None


def active_lines(include_out_of_production: bool = False) -> List[str]:
    lines = sorted(APP.ALL_LINE_MAP.keys())
    if include_out_of_production:
        return lines

    if hasattr(APP, "active_production_lines"):
        try:
            return sorted(APP.active_production_lines())
        except Exception:
            pass

    return lines


def current_shift_start(now: datetime) -> datetime:
    if hasattr(APP, "current_shift_start"):
        return APP.current_shift_start(now)

    six = now.replace(hour=6, minute=0, second=0, microsecond=0)
    eighteen = now.replace(hour=18, minute=0, second=0, microsecond=0)
    if now >= eighteen:
        return eighteen
    if now >= six:
        return six
    return six - timedelta(hours=12)


def shift_label(start: datetime) -> str:
    # D/N based on the shift-start hour.
    code = "D" if start.hour == 6 else "N"
    return f"{start.month}/{start.day} {code}"


def query_shift_total(cursor: Any, tag: str, start: datetime, end: datetime) -> Optional[float]:
    samples = APP.query_delta_values(cursor, tag, start, end)
    total = APP.accumulated_counter_delta(samples)
    if isinstance(total, (int, float)):
        return float(total)
    return None


def live_series_for_tag(cursor: Any, tag: str, shift_start: datetime, shift_count: int) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    # Build oldest -> newest.
    for idx in range(shift_count - 1, -1, -1):
        end = shift_start - timedelta(hours=12 * idx)
        start = end - timedelta(hours=12)

        try:
            value = query_shift_total(cursor, tag, start, end)
            err = None
        except Exception as exc:
            value = None
            err = str(exc)

        rows.append({
            "start": start,
            "end": end,
            "label": shift_label(start),
            "value": value,
            "error": err,
        })

    return rows


def synthetic_series(line: str, metric: str, shift_start: datetime, shift_count: int, goal: float) -> List[Dict[str, Any]]:
    seed = sum(ord(c) for c in f"{line}-{metric}") + 1776
    rng = random.Random(seed)
    base = goal * (0.95 if metric == "z6" else 1.06)
    rows = []
    drift = rng.uniform(-0.004, 0.004)

    for idx in range(shift_count - 1, -1, -1):
        end = shift_start - timedelta(hours=12 * idx)
        start = end - timedelta(hours=12)
        drift += rng.uniform(-0.012, 0.012)
        value = max(0, base * (1 + drift + rng.uniform(-0.08, 0.08)))
        rows.append({
            "start": start,
            "end": end,
            "label": shift_label(start),
            "value": round(value, 2),
            "error": None,
        })
    return rows


def safe_avg(values: Iterable[Optional[float]]) -> Optional[float]:
    nums = [v for v in values if isinstance(v, (int, float)) and not math.isnan(v)]
    return round(sum(nums) / len(nums), 2) if nums else None



def rolling_avg(rows: List[Dict[str, Any]], n: int) -> Optional[float]:
    """Average of the most recent n valid completed shifts."""
    values = [float(r["value"]) for r in rows if isinstance(r.get("value"), (int, float))]
    if not values:
        return None
    recent = values[-n:]
    return round(sum(recent) / len(recent), 2)


def mean_value(rows: List[Dict[str, Any]]) -> Optional[float]:
    """Arithmetic mean of all valid shifts in the requested reporting window."""
    return safe_avg(r.get("value") for r in rows)


def average_deviation(rows: List[Dict[str, Any]], target: float) -> Optional[float]:
    """
    Mean signed deviation from shift target over the requested window.
    Positive = average shift above target; negative = average shift below target.
    """
    values = [float(r["value"]) for r in rows if isinstance(r.get("value"), (int, float))]
    if not values or not isinstance(target, (int, float)):
        return None
    return round(sum(v - target for v in values) / len(values), 2)


def latest_value(rows: List[Dict[str, Any]]) -> Optional[float]:
    for row in reversed(rows):
        if isinstance(row.get("value"), (int, float)):
            return round(float(row["value"]), 2)
    return None


def add_card(slide, x, y, w, h, title, value, body="", color=(48, 133, 226)):
    rgb = RGBColor(*color)
    panel = RGBColor(20, 38, 58)
    border = RGBColor(52, 74, 96)
    white = RGBColor(245, 248, 251)
    muted = RGBColor(165, 182, 198)

    box = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    box.fill.solid()
    box.fill.fore_color.rgb = panel
    box.line.color.rgb = border

    bar = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(0.06), Inches(h))
    bar.fill.solid()
    bar.fill.fore_color.rgb = rgb
    bar.line.fill.background()

    tb = slide.shapes.add_textbox(Inches(x + 0.18), Inches(y + 0.11), Inches(w - 0.32), Inches(0.28))
    p = tb.text_frame.paragraphs[0]
    p.text = title
    p.font.size = Pt(8.5)
    p.font.bold = True
    p.font.color.rgb = muted

    tb = slide.shapes.add_textbox(Inches(x + 0.18), Inches(y + 0.43), Inches(w - 0.32), Inches(0.4))
    p = tb.text_frame.paragraphs[0]
    p.text = value
    p.font.size = Pt(18)
    p.font.bold = True
    p.font.color.rgb = white

    if body:
        tb = slide.shapes.add_textbox(Inches(x + 0.18), Inches(y + 0.86), Inches(w - 0.32), Inches(h - 0.9))
        p = tb.text_frame.paragraphs[0]
        p.text = body
        p.font.size = Pt(8.5)
        p.font.color.rgb = white


def make_chart_png(
    line: str,
    z1_rows: List[Dict[str, Any]],
    z6_rows: List[Dict[str, Any]],
    goal: float,
    out_path: Path,
):
    x = list(range(len(z6_rows)))
    labels = [r["label"] for r in z6_rows]
    z1 = [r["value"] for r in z1_rows]
    z6 = [r["value"] for r in z6_rows]

    fig, ax = plt.subplots(figsize=(12.2, 4.15), dpi=150)
    fig.patch.set_facecolor("#081321")
    ax.set_facecolor("#0d1a28")

    ax.plot(x, z1, marker="o", linewidth=2.1, label="Zone 1 In")
    ax.plot(x, z6, marker="o", linewidth=2.1, label="Zone 6 Out / Loader Out")

    if goal:
        ax.axhline(goal, linestyle="--", linewidth=1.6, label=f"Shift Goal {goal:,.0f}")

    # Show every 4th label to avoid crowding, plus latest.
    ticks = [i for i in x if i % 4 == 0]
    if x and x[-1] not in ticks:
        ticks.append(x[-1])
    ax.set_xticks(ticks)
    ax.set_xticklabels([labels[i] for i in ticks], rotation=35, ha="right", fontsize=7)

    ax.tick_params(colors="#cfe8ff", labelsize=8)
    ax.grid(True, alpha=0.22)
    for spine in ax.spines.values():
        spine.set_color("#344a60")

    ax.set_title(f"{line}: 30-Day Shift Trend — Zone 1 In vs Zone 6 Out", color="white", fontsize=13, weight="bold")
    ax.set_ylabel("Shift total", color="#cfe8ff", fontsize=9)
    legend = ax.legend(loc="upper left", fontsize=8, frameon=True)
    legend.get_frame().set_facecolor("#13263b")
    legend.get_frame().set_edgecolor("#344a60")
    for text in legend.get_texts():
        text.set_color("white")

    fig.tight_layout()
    fig.savefig(out_path, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)


def format_num(value: Optional[float]) -> str:
    return "—" if value is None else f"{value:,.0f}"


def create_deck(all_data: Dict[str, Dict[str, Any]], out_pptx: Path, days: int, provider: str):
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    navy = RGBColor(8, 19, 33)
    white = RGBColor(245, 248, 251)
    muted = RGBColor(165, 182, 198)
    green = (58, 178, 109)
    blue = (48, 133, 226)
    yellow = (235, 184, 58)
    red = (219, 72, 68)

    # Title slide
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = navy

    tb = slide.shapes.add_textbox(Inches(0.75), Inches(1.0), Inches(12), Inches(0.8))
    p = tb.text_frame.paragraphs[0]
    p.text = "30-Day Manufacturing Line Trends"
    p.font.name = "Aptos Display"
    p.font.size = Pt(34)
    p.font.bold = True
    p.font.color.rgb = white

    tb = slide.shapes.add_textbox(Inches(0.78), Inches(1.85), Inches(11.6), Inches(0.4))
    p = tb.text_frame.paragraphs[0]
    p.text = "Zone 1 In vs Zone 6 Out / Loader Out"
    p.font.size = Pt(15)
    p.font.color.rgb = muted

    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    add_card(slide, 0.8, 3.0, 3.4, 1.2, "DATA WINDOW", f"{days} days", "Completed 12-hour shifts", blue)
    add_card(slide, 4.95, 3.0, 3.4, 1.2, "LINES INCLUDED", str(len(all_data)), "Active production lines by default", green)
    add_card(slide, 9.1, 3.0, 3.4, 1.2, "SOURCE", provider, f"Generated {generated}", yellow)

    tb = slide.shapes.add_textbox(Inches(0.85), Inches(5.2), Inches(11.8), Inches(0.6))
    p = tb.text_frame.paragraphs[0]
    p.text = "Read-only report generation: no machine control, no source-system modification, no product disposition."
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = white

    # Summary slide
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = navy

    tb = slide.shapes.add_textbox(Inches(0.65), Inches(0.35), Inches(12), Inches(0.55))
    p = tb.text_frame.paragraphs[0]
    p.text = "Executive Summary"
    p.font.size = Pt(27)
    p.font.bold = True
    p.font.color.rgb = white

    headers = ["Line", "5 Shift", "14 Shift", "20 Shift", "30 Day", "Target", "Avg Dev", "Mean"]
    x0, y0 = 0.65, 1.25
    widths = [1.15, 1.35, 1.35, 1.35, 1.35, 1.35, 1.45, 1.35]
    row_h = 0.28

    for i, h in enumerate(headers):
        tb = slide.shapes.add_textbox(Inches(x0 + sum(widths[:i])), Inches(y0), Inches(widths[i]), Inches(row_h))
        p = tb.text_frame.paragraphs[0]
        p.text = h
        p.font.size = Pt(8.8)
        p.font.bold = True
        p.font.color.rgb = muted

    sorted_lines = sorted(all_data)
    max_rows = min(20, len(sorted_lines))
    for r_idx, line in enumerate(sorted_lines[:max_rows]):
        d = all_data[line]
        vals = [
            line,
            format_num(d["avg_5"]),
            format_num(d["avg_14"]),
            format_num(d["avg_20"]),
            format_num(d["avg_30_day"]),
            format_num(d["goal"]),
            format_num(d["average_deviation"]),
            format_num(d["mean"]),
        ]
        y = y0 + 0.34 + r_idx * 0.25
        for i, val in enumerate(vals):
            tb = slide.shapes.add_textbox(Inches(x0 + sum(widths[:i])), Inches(y), Inches(widths[i]), Inches(0.22))
            p = tb.text_frame.paragraphs[0]
            p.text = val
            p.font.size = Pt(8.3)
            p.font.color.rgb = white

    if len(sorted_lines) > max_rows:
        tb = slide.shapes.add_textbox(Inches(8.8), Inches(6.55), Inches(3.8), Inches(0.3))
        p = tb.text_frame.paragraphs[0]
        p.text = f"+ {len(sorted_lines) - max_rows} additional lines shown on individual slides"
        p.font.size = Pt(9)
        p.font.color.rgb = muted

    with tempfile.TemporaryDirectory() as td:
        temp = Path(td)

        for line in sorted_lines:
            d = all_data[line]
            chart_path = temp / f"{line}_trend.png"
            make_chart_png(line, d["z1_rows"], d["z6_rows"], d["goal"], chart_path)

            slide = prs.slides.add_slide(prs.slide_layouts[6])
            slide.background.fill.solid()
            slide.background.fill.fore_color.rgb = navy

            tb = slide.shapes.add_textbox(Inches(0.55), Inches(0.28), Inches(12), Inches(0.5))
            p = tb.text_frame.paragraphs[0]
            p.text = f"{line} — Zone 1 In vs Zone 6 Out"
            p.font.name = "Aptos Display"
            p.font.size = Pt(24)
            p.font.bold = True
            p.font.color.rgb = white

            tb = slide.shapes.add_textbox(Inches(0.58), Inches(0.82), Inches(12), Inches(0.25))
            p = tb.text_frame.paragraphs[0]
            p.text = f"Last {days} days • Completed 12-hour shifts • Source: {provider}"
            p.font.size = Pt(9)
            p.font.color.rgb = muted

            slide.shapes.add_picture(str(chart_path), Inches(0.5), Inches(1.15), width=Inches(12.25), height=Inches(4.25))

            # Management / performance statistics requested for each line.
            stats = [
                ("5 Shift Avg", d["avg_5"], blue),
                ("14 Shift Avg", d["avg_14"], blue),
                ("20 Shift Avg", d["avg_20"], green if d["avg_20"] is not None and d["avg_20"] >= d["goal"] else red),
                ("30 Day Avg", d["avg_30_day"], blue),
                ("Shift Target", d["goal"], yellow),
                ("Avg Deviation", d["average_deviation"], green if d["average_deviation"] is not None and d["average_deviation"] >= 0 else red),
                ("Mean", d["mean"], blue),
            ]

            x_positions = [0.55, 2.35, 4.15, 5.95, 7.75, 9.55, 11.35]
            widths = [1.6, 1.6, 1.6, 1.6, 1.6, 1.6, 1.45]

            for (label, value, color), x, width in zip(stats, x_positions, widths):
                body = ""
                if label == "Avg Deviation":
                    body = "vs target"
                elif label == "20 Shift Avg":
                    body = "review recovery"
                add_card(slide, x, 5.68, width, 0.95, label, format_num(value), body, color)

    out_pptx.parent.mkdir(parents=True, exist_ok=True)
    prs.save(out_pptx)


def collect_data(args) -> Dict[str, Dict[str, Any]]:
    days = int(args.days)
    shift_count = days * 2
    lines = [x.strip().upper() for x in args.lines.split(",")] if args.lines else active_lines(args.include_out_of_production)
    lines = [line for line in lines if line in APP.ALL_LINE_MAP]

    if not lines:
        raise SystemExit("No valid manufacturing lines selected.")

    now = datetime.now(timezone.utc)
    shift_start = current_shift_start(now)
    targets = APP.load_line_targets() if hasattr(APP, "load_line_targets") else {}

    use_synthetic = args.synthetic or APP.CONFIG.get("provider") != "aveva-sql"

    data: Dict[str, Dict[str, Any]] = {}

    if use_synthetic:
        for line in lines:
            goal = float(targets.get(line, {}).get("SHIFT_GOAL", 42000) or 42000)
            z1_rows = synthetic_series(line, "z1", shift_start, shift_count, goal)
            z6_rows = synthetic_series(line, "z6", shift_start, shift_count, goal)
            data[line] = summarize_line(line, "synthetic", "synthetic", z1_rows, z6_rows, goal)
        return data

    try:
        import pyodbc
    except Exception as exc:
        raise SystemExit(f"Missing pyodbc. Install/repair pyodbc for live mode. Original error: {exc}")

    conn_str = APP.build_connection_string()
    with pyodbc.connect(conn_str, timeout=30, autocommit=True) as connection:
        cursor = connection.cursor()

        for idx, line in enumerate(lines, start=1):
            print(f"[{idx}/{len(lines)}] Querying {line}...")
            z1_key, z1_tag = resolve_tag(line, Z1_IN_KEYS)
            z6_key, z6_tag = resolve_tag(line, Z6_OUT_KEYS)
            goal = float(targets.get(line, {}).get("SHIFT_GOAL", 42000) or 42000)

            if not z1_tag:
                z1_rows = [{"start": shift_start - timedelta(hours=12 * i), "end": shift_start, "label": "", "value": None, "error": "Z1 tag unmapped"} for i in range(shift_count)]
            else:
                z1_rows = live_series_for_tag(cursor, z1_tag, shift_start, shift_count)

            if not z6_tag:
                z6_rows = [{"start": shift_start - timedelta(hours=12 * i), "end": shift_start, "label": "", "value": None, "error": "Z6 tag unmapped"} for i in range(shift_count)]
            else:
                z6_rows = live_series_for_tag(cursor, z6_tag, shift_start, shift_count)

            data[line] = summarize_line(line, z1_key, z6_key, z1_rows, z6_rows, goal)

    return data


def summarize_line(line: str, z1_key: Optional[str], z6_key: Optional[str], z1_rows, z6_rows, goal: float) -> Dict[str, Any]:
    latest_z1 = latest_value(z1_rows)
    latest_z6 = latest_value(z6_rows)
    avg_z6 = safe_avg(row.get("value") for row in z6_rows)

    losses = []
    for a, b in zip(z1_rows, z6_rows):
        if isinstance(a.get("value"), (int, float)) and isinstance(b.get("value"), (int, float)):
            losses.append(a["value"] - b["value"])

    missing_count = sum(1 for row in z1_rows + z6_rows if not isinstance(row.get("value"), (int, float)))

    return {
        "line": line,
        "z1_key": z1_key,
        "z6_key": z6_key,
        "z1_rows": z1_rows,
        "z6_rows": z6_rows,
        "goal": goal,
        "latest_z1": latest_z1,
        "latest_z6": latest_z6,
        "avg_z6": avg_z6,
        "avg_loss": safe_avg(losses),
        "missing_count": missing_count,

        # Requested Loader Out / Zone 6 performance statistics.
        "avg_5": rolling_avg(z6_rows, 5),
        "avg_14": rolling_avg(z6_rows, 14),
        "avg_20": rolling_avg(z6_rows, 20),
        "avg_30_day": safe_avg(r.get("value") for r in z6_rows),
        "mean": mean_value(z6_rows),
        "average_deviation": average_deviation(z6_rows, goal),
    }


def main():
    parser = argparse.ArgumentParser(description="Generate 30-day Zone 1 In vs Zone 6 Out trend PowerPoint.")
    parser.add_argument("--days", type=int, default=30, help="Number of calendar days to include. Default: 30.")
    parser.add_argument("--out", default=None, help="Output .pptx path.")
    parser.add_argument("--lines", default=None, help="Comma-separated line list, e.g. TAM01,TAM02,TAM18.")
    parser.add_argument("--include-out-of-production", action="store_true", help="Include lines marked out of production in line_status.json.")
    parser.add_argument("--synthetic", action="store_true", help="Force synthetic demo data instead of querying live historian.")
    args = parser.parse_args()

    if args.days < 1 or args.days > 365:
        raise SystemExit("--days must be between 1 and 365.")

    provider = "synthetic" if args.synthetic or APP.CONFIG.get("provider") != "aveva-sql" else "aveva-sql"
    out = Path(args.out) if args.out else Path("reports") / f"zone_1_in_vs_zone_6_out_{datetime.now():%Y%m%d_%H%M}.pptx"

    print(f"Generating {args.days}-day trend deck using provider: {provider}")
    data = collect_data(args)
    create_deck(data, out, args.days, provider)

    print(f"\nCreated: {out.resolve()}")


if __name__ == "__main__":
    main()
