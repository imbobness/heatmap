V11 LIVE DATA BUILD

Data sources queried independently:
1) Production historian (config/config.json -> sql; WW_SQL_* environment variables)
2) Legacy 3GT alarm DB (alarm_reference.py; LEGACY_ALARM_* / ALARM_SQL_* env vars)
3) FLEX alarm DB (alarm_reference.py; FLEX_ALARM_* / ALARM_SQL_* env vars)

Production and alarm retrieval for Line Story/Story endpoints runs concurrently.
Legacy and FLEX alarm databases are also queried concurrently.

START:
  Right-click/run start_live.ps1
  Enter production historian credentials and alarm DB credentials when prompted.

SAFETY:
  Automatic emails are forced OFF on every application startup, regardless of the previous saved setting.
  Enable them manually from Shift Control only after validating live data.

HEALTH:
  Startup prints connection status for production, Legacy alarms, and FLEX alarms.
  GET http://localhost:8080/api/health returns the same source health as JSON.

No synthetic fallback occurs in this package's live configuration. A failed live source reports an error rather than silently substituting demo values.
