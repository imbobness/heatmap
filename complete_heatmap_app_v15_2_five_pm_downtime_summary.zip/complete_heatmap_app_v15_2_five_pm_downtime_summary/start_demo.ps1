$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Starting 3GT TAM dashboard in OFFLINE DEMO mode..." -ForegroundColor Cyan
$env:DASHBOARD_MODE = "demo"
$env:DASHBOARD_VISUALIZATION_ONLY = "1"
Write-Host "READ-ONLY VISUALIZATION: no writes, no machine control, no product disposition, no operational record creation." -ForegroundColor Green
py -m py_compile .\app.py
Start-Process "http://localhost:8080"
py .\app.py
