@echo off
cd /d "%~dp0"
python generate_30_day_zone_trend_deck.py --days 30
pause
