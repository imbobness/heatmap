$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Starting 3GT TAM dashboard in LIVE mode" -ForegroundColor Green
Write-Host "Automatic emails will start OFF." -ForegroundColor Yellow
$env:DASHBOARD_MODE = "live"
$env:DASHBOARD_VISUALIZATION_ONLY = "1"
Write-Host "READ-ONLY VISUALIZATION: no writes, no machine control, no product disposition, no operational record creation." -ForegroundColor Green

if (-not $env:WW_SQL_USER) { $env:WW_SQL_USER = Read-Host "Production historian SQL username" }
if (-not $env:WW_SQL_PASSWORD) {
  $secure = Read-Host "Production historian SQL password" -AsSecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { $env:WW_SQL_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

if (-not $env:ALARM_SQL_USER) { $env:ALARM_SQL_USER = Read-Host "Alarm database SQL username [wwUser]"; if (-not $env:ALARM_SQL_USER) { $env:ALARM_SQL_USER = "wwUser" } }
if (-not $env:ALARM_SQL_PASSWORD) {
  $secure = Read-Host "Alarm database SQL password" -AsSecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { $env:ALARM_SQL_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

py -m py_compile .\app.py .\alarm_reference.py
Start-Process "http://localhost:8080"
py .\app.py
