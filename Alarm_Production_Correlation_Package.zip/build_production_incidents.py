import csv
import json
import sqlite3
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB = ROOT / "stop_start_analysis.sqlite"
OUTDIR = ROOT / "stop_alarm_correlation_outputs"
ONSET_WINDOW_SECONDS = 5 * 60


def iso_local(epoch):
    return datetime.fromtimestamp(epoch).isoformat(sep=" ") if epoch is not None else None


def main():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    incidents = []
    current = None
    for row in conn.execute("SELECT * FROM stops ORDER BY line, stop, zone"):
        if current is None or row["line"] != current["line"] or row["stop"] > current["start"] + ONSET_WINDOW_SECONDS:
            if current:
                incidents.append(current)
            current = {"line": row["line"], "start": row["stop"], "end": row["restart"],
                       "zones": {row["zone"]}, "tags": {row["tag"]}, "zone_stop_records": 1,
                       "open_records": int(row["restart"] is None), "counter_resets": row["counter_reset"] or 0}
        else:
            current["zones"].add(row["zone"])
            current["tags"].add(row["tag"])
            current["zone_stop_records"] += 1
            current["open_records"] += int(row["restart"] is None)
            current["counter_resets"] += row["counter_reset"] or 0
            if row["restart"] is None:
                current["end"] = None
            elif current["end"] is not None:
                current["end"] = max(current["end"], row["restart"])
    if current:
        incidents.append(current)

    rows = []
    for i, incident in enumerate(incidents, 1):
        end = incident["end"]
        rows.append({
            "incident_id": f"PI-{i:06d}", "line": incident["line"],
            "incident_start_local": iso_local(incident["start"]),
            "incident_end_local": iso_local(end),
            "incident_span_minutes": round((end-incident["start"])/60, 2) if end is not None else None,
            "zones_affected": len(incident["zones"]), "zones": "|".join(sorted(incident["zones"])),
            "zone_stop_records": incident["zone_stop_records"], "open_records": incident["open_records"],
            "counter_resets": incident["counter_resets"],
        })
    OUTDIR.mkdir(exist_ok=True)
    with (OUTDIR / "production_incidents.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    summary = {"onset_grouping_window_minutes": 5, "production_incidents": len(rows),
               "multi_zone_incidents": sum(r["zones_affected"] > 1 for r in rows),
               "by_line": dict(sorted(Counter(r["line"] for r in rows).items()))}
    (OUTDIR / "production_incident_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
