# Alarm–Production Correlation Update

## Dataset and method

- Production export: 39,525 zone-counter stop records covering August 2–September 1, 2026.
- Alarm export: the previously profiled 30-day alarm history.
- The production file uses one-minute samples and confirms a stop after five minutes without counter movement. It is suitable for sustained stops, but start/restart times are quantized to roughly one minute.
- Timestamp alignment is strongly supported by the data: alarm timestamps behave as UTC and production timestamps as `America/New_York` local time (EDT during this period), a four-hour offset.
- Alarm candidates were searched from five minutes before through one minute after each production stop and scored by timing, zone, alarm type, and prior nuisance/cascade/root-cause labels.

## Data-quality findings

- All 39,525 stop records have good stop quality; 16 were still open at the end of the pull.
- TAM27 is missing the ALI inlet and outlet counter tags because both returned `TagNotFound`. These are unavailable observations, not zero production.
- TAM32 and TAM33 have production-stop data but no corresponding alarm export, leaving all 3,247 of their zone-stop records unmatched.
- Planned downtime still cannot be excluded reliably without a separate planned-event source. It must remain an explicit exclusion flag, not an inferred label.

## Correlation results

- 33,264 of 39,525 zone-stop records (84.2%) had at least one alarm candidate in the search window.
- 9,984 were high-confidence, 14,887 medium-confidence, and 8,393 low-confidence matches.
- Grouping zone-stop onsets within five minutes produced 15,311 production-interruption incidents; 10,795 affected multiple zones.
- Summed zone-stop minutes are **not line downtime** because zones overlap. The provided incident table preserves zone breadth and incident span without claiming that overlapping minutes are additive.

## Examples worth validating first

| Line | Alarm | Unique alarm occurrences linked to a stop | Share of alarm occurrences | Interpretation |
|---|---|---:|---:|---|
| TAM18 | ALI System not ready | 304 / 593 | 51.3% | Strong stop-associated candidate |
| TAM18 | 216SRV Guard Open | 166 / 692 | 24.0% | Likely operator/guard access; validate legacy behavior |
| TAM07 | Mitsubishi robot error | 62 / 251 | 24.7% | Strong maintenance investigation candidate |
| TAM06 | Precure Enclosure door opened | 108 / 503 | 21.5% | Operator-access candidate |
| TAM25 | FC/BC IMM Door Open | 129 / 660 | 19.5% | FLEX operator-access event; check preceding zone stop |
| TAM02 | 30PS Air pressure low | 226 / 2,156 | 10.5% | Utility/process condition with meaningful stop association |
| TAM09 | Hydration enclosure delta | 636 / 22,249 | 2.9% | High event volume but weak per-occurrence stop association; likely background/chatter mixed with real events |
| TAM05 | Hydration enclosure delta | 234 / 30,492 | 0.8% | Very weak per-occurrence stop association; nuisance review priority |

These are statistical candidates, not validated root causes. A warning can be a consequence of a stop, and an alarm near a stop can be coincidental. The next validation layer should compare the candidate with the sequence of alarms, affected zones, counter restart, and operator-access pattern.

## Dashboard integration

For each interruption incident, the dashboard should expose:

- incident start, restart, and span;
- first affected zone and total zones affected;
- best candidate initiating alarm plus confidence;
- preceding zone-stop/guard-door sequence;
- likely category: equipment/process, operator access, run alarm, warning/consequence, cascade, or nuisance;
- repeated occurrences in the prior 7 and 30 days;
- median recovery time and recovery trend;
- planned-downtime exclusion status;
- links to the alarm sequence and zone production trace.

Do not use CMMS, out-of-production status, or alarm priority as ground truth. CMMS can enrich validated events; out-of-production is reporting-only; and alarm severity semantics remain unknown.

## Recommended next validation

Review 20–30 examples from each high-value category with operations and maintenance: high-confidence equipment faults, guard/door events, weakly associated high-volume alarms, and long-recovery incidents. Those labels can then seed a transparent rules model before any predictive model is attempted.
