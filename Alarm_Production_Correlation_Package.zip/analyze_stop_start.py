import bisect
import csv
import json
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "stop_start_extract" / "TAM_All_Tag_Stop_Start_20260901_150947"
ALARM_DB = ROOT / "alarm_analysis.sqlite"
STOP_DB = ROOT / "stop_start_analysis.sqlite"
OUT = ROOT / "stop_start_profile.json"


def ts(value):
    return datetime.fromisoformat(value).timestamp() if value else None


def main():
    if STOP_DB.exists():
        STOP_DB.unlink()
    conn = sqlite3.connect(STOP_DB)
    conn.execute("""CREATE TABLE stops(
      line TEXT,zone TEXT,tag TEXT,status TEXT,last_movement REAL,stop REAL,confirmed REAL,
      restart REAL,stopped_minutes REAL,production_gap_minutes REAL,counter_reset INTEGER,
      stop_quality INTEGER,restart_quality INTEGER,detection_threshold_minutes REAL,source_file TEXT)""")
    insert = "INSERT INTO stops VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    rows = []
    for path in sorted(SOURCE.glob("TAM*_Stop_Start.csv")):
        with path.open(encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                rows.append((r["Line"],r["Zone"],r["TagName"],r["EventStatus"],ts(r["LastMovementTimestamp"]),
                  ts(r["StopTimestamp"]),ts(r["StopConfirmedTimestamp"]),ts(r["RestartTimestamp"]),
                  float(r["StoppedMinutes"]) if r["StoppedMinutes"] else None,
                  float(r["ProductionGapMinutes"]) if r["ProductionGapMinutes"] else None,
                  int(r["CounterResetDuringStop"].lower()=="true"),int(r["StopQuality"]) if r["StopQuality"] else None,
                  int(r["RestartQuality"]) if r["RestartQuality"] else None,
                  float(r["DetectionThresholdMinutes"]),path.name))
                if len(rows) >= 10000:
                    conn.executemany(insert, rows); rows.clear()
    if rows:
        conn.executemany(insert, rows)
    conn.executescript("CREATE INDEX idx_stops_line_stop ON stops(line,stop); ANALYZE;")
    conn.commit()
    conn.row_factory = sqlite3.Row

    profile = {}
    profile["total_stop_events"] = conn.execute("SELECT count(*) FROM stops").fetchone()[0]
    profile["coverage"] = [dict(r) for r in conn.execute("""
      SELECT datetime(min(last_movement),'unixepoch') first_event,
             datetime(max(coalesce(restart,confirmed)),'unixepoch') last_event,
             count(*) events,sum(status='OPEN_AT_END_OF_PULL') open_events,
             round(sum(stopped_minutes),1) summed_stop_minutes
      FROM stops""")]
    profile["by_line"] = [dict(r) for r in conn.execute("""
      SELECT line,count(*) stop_events,count(distinct zone) zones,count(distinct tag) tags,
             sum(status='OPEN_AT_END_OF_PULL') open_events,round(avg(stopped_minutes),2) avg_stop_minutes,
             round(sum(stopped_minutes),1) summed_stop_minutes,sum(counter_reset) counter_resets
      FROM stops GROUP BY line ORDER BY line""")]
    profile["by_zone"] = [dict(r) for r in conn.execute("""
      SELECT zone,count(*) stop_events,round(avg(stopped_minutes),2) avg_stop_minutes,
             round(sum(stopped_minutes),1) summed_stop_minutes
      FROM stops GROUP BY zone ORDER BY stop_events DESC""")]
    profile["quality"] = [dict(r) for r in conn.execute("""
      SELECT stop_quality,restart_quality,count(*) events FROM stops
      GROUP BY stop_quality,restart_quality ORDER BY events DESC""")]

    alarm = sqlite3.connect(ALARM_DB)
    alarm.row_factory = sqlite3.Row
    alarm_lines = {r[0] for r in alarm.execute("SELECT DISTINCT line FROM events")}
    stop_lines = {r[0] for r in conn.execute("SELECT DISTINCT line FROM stops")}
    profile["stop_lines_without_alarm_export"] = sorted(stop_lines - alarm_lines)

    # Empirically align FLEX zone-stop pushbutton events with production-stop timestamps.
    zone_stops = defaultdict(list)
    for r in alarm.execute("""
      SELECT line,start FROM events WHERE source='FLEX' AND
       (lower(alarm_key) LIKE '%pbl_actuated%' OR lower(message) LIKE '%zone stop%')
      ORDER BY line,start"""):
        zone_stops[r[0]].append(r[1])
    production_stops = defaultdict(list)
    for r in conn.execute("SELECT line,stop FROM stops WHERE line>='TAM24' AND line<='TAM33' ORDER BY line,stop"):
        production_stops[r[0]].append(r[1])

    offset_scores = []
    for hours in range(-12,13):
        offset = hours*3600
        matched = 0
        total = 0
        for line, stops in production_stops.items():
            alarms = zone_stops.get(line, [])
            for stop in stops:
                total += 1
                # alarm + offset should occur from five minutes before through one minute after the stop.
                low = stop - 300 - offset
                high = stop + 60 - offset
                pos = bisect.bisect_left(alarms, low)
                if pos < len(alarms) and alarms[pos] <= high:
                    matched += 1
        offset_scores.append({"alarm_timestamp_offset_hours":hours,"matched_stops":matched,
                              "total_stops":total,"match_pct":round(matched/max(1,total)*100,2)})
    profile["flex_zone_stop_offset_test"] = sorted(offset_scores,key=lambda r:(-r["matched_stops"],abs(r["alarm_timestamp_offset_hours"])))
    OUT.write_text(json.dumps(profile,indent=2),encoding="utf-8")
    print(json.dumps(profile,indent=2))


if __name__ == "__main__":
    main()
