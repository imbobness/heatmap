import csv
import json
import re
import sqlite3
from collections import defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ALARM_DB = ROOT / "alarm_analysis.sqlite"
STOP_DB = ROOT / "stop_start_analysis.sqlite"
CATALOG = ROOT / "alarm_analysis_outputs" / "alarm_catalog.csv"
OUTDIR = ROOT / "stop_alarm_correlation_outputs"
ALARM_TO_PRODUCTION_OFFSET_SECONDS = -4 * 3600  # UTC alarms -> EDT production export for this period


def zone_number(value):
    match = re.search(r"(?:Z|ZONE)?0?(\d{1,2})", value or "", re.I)
    return int(match.group(1)) if match else None


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def iso_local(epoch):
    return datetime.fromtimestamp(epoch).isoformat(sep=" ") if epoch is not None else None


def main():
    OUTDIR.mkdir(exist_ok=True)
    classifications = {}
    with CATALOG.open(encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            classifications[(row["source"], row["line"], row["alarm_key"])] = row["classification"]

    alarms = sqlite3.connect(ALARM_DB)
    alarms.row_factory = sqlite3.Row
    stops = sqlite3.connect(STOP_DB)
    stops.row_factory = sqlite3.Row
    output = []
    aggregate = defaultdict(lambda: {"stop_events":0,"zone_stop_minutes":0.0,"confidence_sum":0,
                                      "same_zone":0,"first_delay_sum":0.0,"alarm_sequences":set()})
    confidence_rank = {"LOW":1,"MEDIUM":2,"HIGH":3}

    for index, stop in enumerate(stops.execute("SELECT * FROM stops ORDER BY line,stop"), 1):
        # Alarm timestamps are stored four hours ahead of the local production timestamps.
        alarm_center = stop["stop"] - ALARM_TO_PRODUCTION_OFFSET_SECONDS
        candidates = alarms.execute("""
          SELECT seq,source,line,zone,alarm_key,message,start,end,door_open_flag,warning_flag,
                 run_flag,stop_flag FROM events
          WHERE line=? AND start>=? AND start<=? ORDER BY start
        """, (stop["line"], alarm_center-300, alarm_center+60)).fetchall()
        ranked = []
        stop_zone = zone_number(stop["zone"])
        for alarm in candidates:
            key = (alarm["source"], alarm["line"], alarm["alarm_key"])
            labels = classifications.get(key, "UNCLASSIFIED")
            local_alarm_start = alarm["start"] + ALARM_TO_PRODUCTION_OFFSET_SECONDS
            delay = stop["stop"] - local_alarm_start
            alarm_zone = zone_number(alarm["zone"])
            same_zone = stop_zone is not None and alarm_zone == stop_zone
            score = 0
            if -30 <= delay <= 120:
                score += 4
            elif -60 <= delay <= 300:
                score += 2
            if same_zone:
                score += 4
            if alarm["stop_flag"]:
                score += 4
            if alarm["door_open_flag"]:
                score += 2
            if "ROOT_CAUSE_CANDIDATE" in labels:
                score += 2
            if "CASCADE_SYMPTOM_CANDIDATE" in labels:
                score -= 3
            if "NUISANCE_CHATTER_CANDIDATE" in labels:
                score -= 5
            if alarm["run_flag"]:
                score -= 4
            ranked.append((score, same_zone, -abs(delay), alarm, labels, delay, local_alarm_start))
        ranked.sort(key=lambda item: (item[0], item[1], item[2]), reverse=True)
        best = ranked[0] if ranked else None
        if best:
            score, same_zone, _, alarm, labels, delay, local_start = best
            confidence = "HIGH" if score >= 9 else "MEDIUM" if score >= 5 else "LOW"
            key = (alarm["source"],alarm["line"],alarm["alarm_key"],alarm["message"],labels)
            aggregate[key]["stop_events"] += 1
            aggregate[key]["zone_stop_minutes"] += stop["stopped_minutes"] or 0
            aggregate[key]["confidence_sum"] += confidence_rank[confidence]
            aggregate[key]["same_zone"] += int(same_zone)
            aggregate[key]["first_delay_sum"] += delay
            aggregate[key]["alarm_sequences"].add(alarm["seq"])
            alarm_key = alarm["alarm_key"]
            alarm_message = alarm["message"]
            alarm_source = alarm["source"]
            alarm_zone = alarm["zone"]
            alarm_start_local = local_start
        else:
            score = None; confidence = "UNMATCHED"; labels = "UNMATCHED"
            alarm_key = alarm_message = alarm_source = alarm_zone = None
            alarm_start_local = delay = None
        output.append({
          "line":stop["line"],"production_zone":stop["zone"],"production_tag":stop["tag"],
          "stop_timestamp_local":iso_local(stop["stop"]),"restart_timestamp_local":iso_local(stop["restart"]),
          "stopped_minutes":stop["stopped_minutes"],"event_status":stop["status"],
          "candidate_alarm_source":alarm_source,"candidate_alarm_zone":alarm_zone,
          "candidate_alarm_key":alarm_key,"candidate_alarm_message":alarm_message,
          "candidate_alarm_start_local":iso_local(alarm_start_local),"alarm_to_stop_seconds":delay,
          "candidate_score":score,"confidence":confidence,"classification":labels,
          "candidate_count_in_window":len(candidates)
        })
        if index % 5000 == 0:
            print(f"correlated {index:,} stops")

    scores = []
    occurrence_counts = {(r[0],r[1],r[2]):r[3] for r in alarms.execute(
        "SELECT source,line,alarm_key,count(*) FROM events GROUP BY source,line,alarm_key")}
    for key, values in aggregate.items():
        source,line,alarm_key,message,labels = key
        occurrences = occurrence_counts.get((source,line,alarm_key),0)
        n = values["stop_events"]
        unique_occurrences = len(values["alarm_sequences"])
        scores.append({
          "source":source,"line":line,"alarm_key":alarm_key,"message":message,
          "classification":labels,"alarm_occurrences":occurrences,
          "alarm_occurrences_linked_to_stop":unique_occurrences,
          "alarm_occurrence_stop_association_pct":round(unique_occurrences/max(1,occurrences)*100,3),
          "attributed_zone_stops":n,
          "attributed_zone_stop_minutes":round(values["zone_stop_minutes"],1),
          "average_zone_stop_minutes":round(values["zone_stop_minutes"]/n,2),
          "same_zone_pct":round(values["same_zone"]/n*100,2),
          "average_alarm_to_stop_seconds":round(values["first_delay_sum"]/n,2),
          "average_confidence_score":round(values["confidence_sum"]/n,2)
        })
    scores.sort(key=lambda r:(-r["attributed_zone_stop_minutes"],-r["attributed_zone_stops"]))
    write_csv(OUTDIR / "stop_alarm_attribution.csv", output)
    write_csv(OUTDIR / "alarm_downtime_scores.csv", scores)
    summary = {
      "alarm_to_production_offset_hours": -4,
      "timezone_interpretation":"Alarm timestamps UTC; stop/start timestamps America/New_York (EDT for this period)",
      "stop_events":len(output),
      "matched":sum(r["confidence"]!="UNMATCHED" for r in output),
      "high_confidence":sum(r["confidence"]=="HIGH" for r in output),
      "medium_confidence":sum(r["confidence"]=="MEDIUM" for r in output),
      "low_confidence":sum(r["confidence"]=="LOW" for r in output),
      "unmatched":sum(r["confidence"]=="UNMATCHED" for r in output),
      "top_attributed_alarms":scores[:50]
    }
    (OUTDIR / "summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps({k:v for k,v in summary.items() if k!="top_attributed_alarms"},indent=2))


if __name__ == "__main__":
    main()
