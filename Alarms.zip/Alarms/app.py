"""Unified TAM Alarm Viewer - Streamlit edition.

Required packages:
    py -m pip install streamlit pandas pyodbc

Run:
    $env:ALARM_SQL_USER = "wwUser"
    $env:ALARM_SQL_PASSWORD = "your_password"
    py -m streamlit run .\app.py
"""

from __future__ import annotations

import os
import re
from datetime import datetime, timedelta
from typing import Any

import pandas as pd
import pyodbc
import streamlit as st

st.set_page_config(page_title="Unified TAM Alarm Viewer", page_icon="⚠️", layout="wide")

# -----------------------------------------------------------------------------
# Configuration
# -----------------------------------------------------------------------------
SQL_DRIVER = os.getenv("ALARM_SQL_DRIVER", "SQL Server")
SQL_USER = os.getenv("ALARM_SQL_USER", "wwUser")
SQL_PASSWORD = os.getenv("ALARM_SQL_PASSWORD", "")

LEGACY_SERVER = os.getenv("LEGACY_ALARM_SERVER", "visusjp3gtalarm.jaxprod.local")
LEGACY_DATABASE = os.getenv("LEGACY_ALARM_DATABASE", "WWALMDB")
FLEX_SERVER = os.getenv("FLEX_ALARM_SERVER", "visusjpflxalarm.jaxprod.local")
FLEX_DATABASE = os.getenv("FLEX_ALARM_DATABASE", "RWAEDB")

ACTIVE_LINES = [
    "TAM01", "TAM02", "TAM05", "TAM06", "TAM07", "TAM09", "TAM10",
    "TAM17", "TAM18", "TAM20", "TAM21", "TAM22", "TAM23",
    "TAM24", "TAM25", "TAM26", "TAM27", "TAM28", "TAM29", "TAM30",
    "TAM31", "TAM32", "TAM33",
]

# Permanent legacy exclusions. These records never enter counts, summaries,
# classification, CSV exports, or charts.
LEGACY_EXCLUDED_PRIORITIES = {500, 250, 300}
LEGACY_EXCLUDED_TAG_REGEX = re.compile(r"RunAlm", re.IGNORECASE)
LEGACY_EXCLUDED_ZONE_REGEX = re.compile(r"^Ru_", re.IGNORECASE)
LEGACY_EXCLUDED_MESSAGE_REGEX = re.compile(
    r"Web\s*Guide\s*-\s*Disturbance\s*detected|"
    r"Web\s*Guide\s*Sensor.*Low\s*contrast\s*Edge\s*detected",
    re.IGNORECASE,
)

ACCESS_RULES = [
    (re.compile(r"zone\s*stop|z\s*stop|zstop|_zstop_|pbl.*actuat", re.I), "Zone stop / stop pushbutton"),
    (re.compile(r"guard\s*(door|open)|safety\s*guard\s*open|guard_open|gls(?:_lck)?", re.I), "Guard door / guard circuit"),
    (re.compile(r"safety\s*mat|walk.?in\s*mat", re.I), "Safety mat"),
    (re.compile(r"light\s*curtain|lightcurtain", re.I), "Light curtain"),
    (re.compile(r"door\s*open|door_open|door opened", re.I), "Door opened"),
]

CONSEQUENCE_RULES = [
    (re.compile(r"e[- ]?stop|emergency\s*stop|emergency stopped|estopcondition", re.I), "E-stop consequence"),
    (re.compile(r"controller\s*fault|controllerfault|controller fauled", re.I), "Controller consequence"),
    (re.compile(r"not\s*enabled|not\s*ready|emergency", re.I), "Disabled / not-ready consequence"),
    (re.compile(r"zero\s*position|zeroposition", re.I), "Recovery / zero-position consequence"),
]

APP_COLUMNS = [
    "Source", "Line", "Classification", "Start", "Clear", "DurationSeconds",
    "Severity", "Priority", "ZoneSource", "Alarm", "Tag", "LoggingNode",
    "Acked", "NoiseReason", "SuppressionReason", "AccessEpisode",
]

# -----------------------------------------------------------------------------
# Database helpers
# -----------------------------------------------------------------------------
def connection_string(server: str, database: str) -> str:
    if not SQL_PASSWORD:
        raise RuntimeError(
            "ALARM_SQL_PASSWORD is not set. Set it in PowerShell before starting Streamlit."
        )
    return (
        f"DRIVER={{{SQL_DRIVER}}};"
        f"SERVER={server};DATABASE={database};"
        f"UID={SQL_USER};PWD={SQL_PASSWORD};"
        "Connection Timeout=15;"
    )


def normalize_line(logging_node: Any) -> str:
    match = re.search(r"(\d{1,2})$", str(logging_node or ""))
    return f"TAM{int(match.group(1)):02d}" if match else str(logging_node or "Unknown")


def elapsed_seconds(start: Any, clear: Any) -> float | None:
    """Calculate duration only from alarm appearance until clear timestamp."""
    if pd.isna(start) or pd.isna(clear):
        return None
    start_ts = pd.Timestamp(start)
    clear_ts = pd.Timestamp(clear)
    return round(max((clear_ts - start_ts).total_seconds(), 0.0), 3)


@st.cache_data(ttl=30, show_spinner=False)
def query_legacy(hours: int, minimum_priority: int, row_limit: int) -> pd.DataFrame:
    # Priority 500, RunAlm, Ru_ groups, and known web-guide run warnings are
    # excluded in SQL so they never affect downstream metrics.
    sql = """
    SELECT TOP (?)
        LoggingNode,
        GroupName,
        Comment,
        Priority,
        OriginationTime,
        ReturnTime,
        TagName,
        AlarmType
    FROM WWALMDB.dbo.[3GTAlarms]
    WHERE OriginationTime >= DATEADD(HOUR, -?, GETDATE())
      AND Priority >= ?
      AND Priority <> 500
      AND ISNULL(TagName, '') NOT LIKE '%RunAlm%'
      AND ISNULL(GroupName, '') NOT LIKE 'Ru[_]%'
      AND ISNULL(Comment, '') NOT LIKE '%Web Guide - Disturbance detected%'
      AND ISNULL(Comment, '') NOT LIKE '%Low contrast Edge detected%'
    ORDER BY OriginationTime DESC
    """
    with pyodbc.connect(
        connection_string(LEGACY_SERVER, LEGACY_DATABASE), autocommit=True
    ) as connection:
        rows = pd.read_sql_query(
            sql, connection, params=[row_limit, hours, minimum_priority]
        )

    if rows.empty:
        return empty_alarm_frame()

    # Defense in depth in case source formatting varies.
    noise_mask = (
        rows["Priority"].isin(LEGACY_EXCLUDED_PRIORITIES)
        | rows["TagName"].fillna("").str.contains(LEGACY_EXCLUDED_TAG_REGEX)
        | rows["GroupName"].fillna("").str.contains(LEGACY_EXCLUDED_ZONE_REGEX)
        | rows["Comment"].fillna("").str.contains(LEGACY_EXCLUDED_MESSAGE_REGEX)
    )
    rows = rows.loc[~noise_mask].copy()

    result = pd.DataFrame()
    result["Source"] = "Legacy 3GT"
    result["Line"] = rows["LoggingNode"].map(normalize_line)
    result["Start"] = pd.to_datetime(rows["OriginationTime"], errors="coerce")
    result["Clear"] = pd.to_datetime(rows["ReturnTime"], errors="coerce")
    result["DurationSeconds"] = [
        elapsed_seconds(start, clear)
        for start, clear in zip(result["Start"], result["Clear"])
    ]
    result["Severity"] = pd.NA
    result["Priority"] = rows["Priority"]
    result["ZoneSource"] = rows["GroupName"].fillna("")
    result["Alarm"] = rows["Comment"].fillna("")
    result["Tag"] = rows["TagName"].fillna("")
    result["LoggingNode"] = rows["LoggingNode"].fillna("")
    result["Acked"] = pd.NA
    result["NoiseReason"] = ""
    result["AlarmType"] = rows["AlarmType"].fillna("").astype(str).str.strip()
    return ensure_columns(result)


@st.cache_data(ttl=30, show_spinner=False)
def query_flex(hours: int, minimum_severity: int, row_limit: int) -> pd.DataFrame:
    sql = """
    SELECT TOP (?)
        LoggingNode,
        SourceName,
        Message,
        Severity,
        Priority,
        AlarmStartTimeStamp,
        AlarmEndTimeStamp,
        Acked
    FROM RWAEDB.dbo.FLEXALARMS
    WHERE AlarmStartTimeStamp >= DATEADD(HOUR, -?, GETDATE())
      AND Severity >= ?
    ORDER BY AlarmStartTimeStamp DESC
    """
    with pyodbc.connect(
        connection_string(FLEX_SERVER, FLEX_DATABASE), autocommit=True
    ) as connection:
        rows = pd.read_sql_query(
            sql, connection, params=[row_limit, hours, minimum_severity]
        )

    if rows.empty:
        return empty_alarm_frame()

    result = pd.DataFrame()
    result["Source"] = "Flex"
    result["Line"] = rows["LoggingNode"].map(normalize_line)
    result["Start"] = pd.to_datetime(rows["AlarmStartTimeStamp"], errors="coerce")
    result["Clear"] = pd.to_datetime(rows["AlarmEndTimeStamp"], errors="coerce")
    result["DurationSeconds"] = [
        elapsed_seconds(start, clear)
        for start, clear in zip(result["Start"], result["Clear"])
    ]
    result["Severity"] = rows["Severity"]
    result["Priority"] = rows["Priority"]
    result["ZoneSource"] = rows["SourceName"].fillna("")
    result["Alarm"] = rows["Message"].fillna("")
    result["Tag"] = rows["SourceName"].fillna("")
    result["LoggingNode"] = rows["LoggingNode"].fillna("")
    result["Acked"] = rows["Acked"]
    result["NoiseReason"] = ""
    result["AlarmType"] = ""
    return ensure_columns(result)


def empty_alarm_frame() -> pd.DataFrame:
    return pd.DataFrame(columns=APP_COLUMNS + ["AlarmType"])


def ensure_columns(frame: pd.DataFrame) -> pd.DataFrame:
    for column in APP_COLUMNS + ["AlarmType"]:
        if column not in frame.columns:
            frame[column] = pd.NA
    return frame

# -----------------------------------------------------------------------------
# Classification and correlation
# -----------------------------------------------------------------------------
def text_for(row: pd.Series) -> str:
    return " ".join(
        str(row.get(column, "") or "")
        for column in ["Alarm", "Tag", "ZoneSource"]
    )


def first_matching_reason(row: pd.Series, rules: list[tuple[re.Pattern, str]]) -> str | None:
    text = text_for(row)
    for pattern, reason in rules:
        if pattern.search(text):
            return reason
    return None


def classify_and_correlate(frame: pd.DataFrame, cascade_seconds: int) -> pd.DataFrame:
    if frame.empty:
        return ensure_columns(frame.copy())

    result = frame.copy().sort_values(["Line", "Start"], na_position="last")
    result["Classification"] = "Root-cause Candidate"
    result["SuppressionReason"] = ""
    result["AccessEpisode"] = pd.NA
    result["Nuisance"] = False

    episode_sequence = 0
    output_parts = []

    for line, group in result.groupby("Line", dropna=False, sort=False):
        group = group.copy().sort_values("Start", na_position="last")
        access_events = []

        for index, row in group.iterrows():
            access_reason = first_matching_reason(row, ACCESS_RULES)
            consequence_reason = first_matching_reason(row, CONSEQUENCE_RULES)
            if access_reason:
                group.at[index, "Classification"] = "Operator Access"
                start = row["Start"]
                if pd.notna(start):
                    clear = row["Clear"] if pd.notna(row["Clear"]) else start
                    if clear < start:
                        clear = start
                    access_events.append(
                        {
                            "start": pd.Timestamp(start),
                            "end": pd.Timestamp(clear) + timedelta(seconds=cascade_seconds),
                            "reason": access_reason,
                        }
                    )
            elif consequence_reason:
                group.at[index, "Classification"] = "Consequence"

        episodes = []
        for event in sorted(access_events, key=lambda item: item["start"]):
            if episodes and event["start"] <= episodes[-1]["end"]:
                episodes[-1]["end"] = max(episodes[-1]["end"], event["end"])
                if event["reason"] not in episodes[-1]["reasons"]:
                    episodes[-1]["reasons"].append(event["reason"])
            else:
                episode_sequence += 1
                episodes.append(
                    {
                        "id": episode_sequence,
                        "start": event["start"],
                        "end": event["end"],
                        "reasons": [event["reason"]],
                    }
                )

        for index, row in group.iterrows():
            if pd.isna(row["Start"]):
                continue
            start = pd.Timestamp(row["Start"])
            episode = next(
                (
                    item for item in episodes
                    if item["start"] <= start <= item["end"]
                ),
                None,
            )
            if episode is None:
                continue

            group.at[index, "Nuisance"] = True
            group.at[index, "AccessEpisode"] = episode["id"]
            if group.at[index, "Classification"] == "Operator Access":
                group.at[index, "SuppressionReason"] = "; ".join(episode["reasons"])
            else:
                group.at[index, "Classification"] = "Suppressed Access Consequence"
                group.at[index, "SuppressionReason"] = (
                    f"Started during operator-access episode on {line}: "
                    f"{episode['start']} through {episode['end']}"
                )

        output_parts.append(group)

    return (
        pd.concat(output_parts, ignore_index=True)
        .sort_values("Start", ascending=False, na_position="last")
        .reset_index(drop=True)
    )


def apply_text_filters(
    frame: pd.DataFrame,
    selected_lines: list[str],
    keyword: str,
    zone_keyword: str,
) -> pd.DataFrame:
    result = frame.copy()
    if selected_lines:
        result = result[result["Line"].isin(selected_lines)]
    if keyword:
        mask = (
            result["Alarm"].fillna("").str.contains(keyword, case=False, regex=False)
            | result["Tag"].fillna("").str.contains(keyword, case=False, regex=False)
        )
        result = result[mask]
    if zone_keyword:
        result = result[
            result["ZoneSource"].fillna("").str.contains(
                zone_keyword, case=False, regex=False
            )
        ]
    return result


def apply_view(frame: pd.DataFrame, view: str) -> pd.DataFrame:
    if view == "All alarms":
        return frame
    if view == "Actionable only":
        return frame[~frame["Nuisance"]]
    if view == "Root-cause candidates":
        return frame[frame["Classification"] == "Root-cause Candidate"]
    if view == "Operator access":
        return frame[frame["Classification"] == "Operator Access"]
    if view == "Suppressed access consequences":
        return frame[frame["Classification"] == "Suppressed Access Consequence"]
    return frame


def summarize_by_line(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame(
            columns=[
                "Line", "AlarmCount", "AlarmMinutes", "RootCauseCandidates",
                "OperatorAccess", "SuppressedConsequences", "TopAlarm",
                "TopAlarmOccurrences",
            ]
        )

    summaries = []
    for line, group in frame.groupby("Line", dropna=False):
        counts = group["Alarm"].fillna("").value_counts()
        top_alarm = counts.index[0] if len(counts) else ""
        top_occurrences = int(counts.iloc[0]) if len(counts) else 0
        summaries.append(
            {
                "Line": line,
                "AlarmCount": int(len(group)),
                "AlarmMinutes": round(
                    pd.to_numeric(group["DurationSeconds"], errors="coerce")
                    .fillna(0)
                    .sum()
                    / 60,
                    2,
                ),
                "RootCauseCandidates": int((group["Classification"] == "Root-cause Candidate").sum()),
                "OperatorAccess": int((group["Classification"] == "Operator Access").sum()),
                "SuppressedConsequences": int((group["Classification"] == "Suppressed Access Consequence").sum()),
                "TopAlarm": top_alarm,
                "TopAlarmOccurrences": top_occurrences,
            }
        )
    return pd.DataFrame(summaries).sort_values(
        ["AlarmCount", "Line"], ascending=[False, True]
    )

# -----------------------------------------------------------------------------
# Streamlit UI
# -----------------------------------------------------------------------------
st.title("Unified TAM Alarm Viewer")
st.caption(
    "Queries the Legacy 3GT and Flex alarm databases, removes known run-warning "
    "noise, calculates duration from appearance to clear timestamps, and suppresses "
    "operator-access alarm cascades."
)

with st.sidebar:
    st.header("Query")
    source_choice = st.selectbox("Source", ["Both", "Legacy 3GT", "Flex"])
    hours = st.number_input("Lookback hours", min_value=1, max_value=8760, value=24, step=1)
    selected_lines = st.multiselect("TAM lines", ACTIVE_LINES)
    view_choice = st.selectbox(
        "View",
        [
            "Actionable only",
            "All alarms",
            "Root-cause candidates",
            "Operator access",
            "Suppressed access consequences",
        ],
    )
    cascade_seconds = st.number_input(
        "Access cascade window (seconds)", min_value=0, max_value=3600, value=120, step=15
    )
    legacy_min_priority = st.number_input(
        "Legacy minimum priority", min_value=-32768, max_value=32767, value=1, step=1
    )
    flex_min_severity = st.number_input(
        "Flex minimum severity", min_value=0, max_value=10000, value=740, step=10
    )
    keyword = st.text_input("Alarm or tag contains")
    zone_keyword = st.text_input("Zone or source contains")
    row_limit = st.number_input(
        "Maximum rows per source", min_value=100, max_value=50000, value=10000, step=500
    )
    run_query = st.button("Run query", type="primary", use_container_width=True)
    if st.button("Clear cached query results", use_container_width=True):
        st.cache_data.clear()
        st.rerun()

st.warning(
    "Permanent Legacy exclusions: Priority 500, TagName containing RunAlm, "
    "GroupName beginning Ru_, Web Guide disturbance alerts, and Web Guide low-contrast alerts."
)

if "query_requested" not in st.session_state:
    st.session_state.query_requested = True
if run_query:
    st.session_state.query_requested = True

if not SQL_PASSWORD:
    st.error(
        "ALARM_SQL_PASSWORD is not set. In PowerShell, set the environment variables "
        "and restart Streamlit:\n\n"
        '$env:ALARM_SQL_USER = "wwUser"\n'
        '$env:ALARM_SQL_PASSWORD = "your_password"'
    )
    st.stop()

frames = []
errors = []
with st.spinner("Querying alarm databases..."):
    if source_choice in {"Both", "Legacy 3GT"}:
        try:
            frames.append(
                query_legacy(int(hours), int(legacy_min_priority), int(row_limit))
            )
        except Exception as error:
            errors.append(f"Legacy 3GT: {error}")
    if source_choice in {"Both", "Flex"}:
        try:
            frames.append(
                query_flex(int(hours), int(flex_min_severity), int(row_limit))
            )
        except Exception as error:
            errors.append(f"Flex: {error}")

for error in errors:
    st.error(error)

raw = pd.concat(frames, ignore_index=True) if frames else empty_alarm_frame()
raw = apply_text_filters(raw, selected_lines, keyword, zone_keyword)
classified = classify_and_correlate(raw, int(cascade_seconds))
visible = apply_view(classified, view_choice).reset_index(drop=True)

metric1, metric2, metric3, metric4 = st.columns(4)
metric1.metric("Visible alarms", f"{len(visible):,}")
metric2.metric("Total after hard exclusions", f"{len(classified):,}")
metric3.metric(
    "Operator access",
    f"{int((classified['Classification'] == 'Operator Access').sum()) if not classified.empty else 0:,}",
)
metric4.metric(
    "Suppressed consequences",
    f"{int((classified['Classification'] == 'Suppressed Access Consequence').sum()) if not classified.empty else 0:,}",
)

explorer_tab, summary_tab, rules_tab = st.tabs(
    ["Alarm Explorer", "Summary by Line", "Noise Rules"]
)

with explorer_tab:
    display_columns = [
        "Source", "Line", "Classification", "Start", "Clear",
        "DurationSeconds", "Severity", "Priority", "ZoneSource", "Alarm",
        "Tag", "SuppressionReason", "AccessEpisode", "Acked",
    ]
    st.dataframe(
        visible[display_columns] if not visible.empty else pd.DataFrame(columns=display_columns),
        use_container_width=True,
        height=620,
        hide_index=True,
    )
    csv_data = visible[display_columns].to_csv(index=False).encode("utf-8-sig")
    st.download_button(
        "Download current filtered results",
        data=csv_data,
        file_name="Unified_TAM_Alarms.csv",
        mime="text/csv",
    )

with summary_tab:
    summary = summarize_by_line(visible)
    st.dataframe(summary, use_container_width=True, height=520, hide_index=True)
    if not summary.empty:
        chart_data = summary.set_index("Line")[["AlarmCount"]]
        st.bar_chart(chart_data)

with rules_tab:
    st.subheader("Permanent hard exclusions")
    st.code(
        "Legacy Priority = 500\n"
        "Legacy TagName contains RunAlm\n"
        "Legacy GroupName begins Ru_\n"
        "Legacy Comment contains Web Guide - Disturbance detected\n"
        "Legacy Comment contains Low contrast Edge detected"
    )
    st.subheader("Operator-access triggers")
    st.write(
        "Zone stops, stop pushbuttons, guard-door or guard-circuit events, "
        "safety mats, light curtains, and door-open events."
    )
    st.subheader("Consequence patterns")
    st.write(
        "E-stop, emergency-stop, controller-fault, not-ready/not-enabled, "
        "and zero-position recovery alarms."
    )
    st.info(
        "An alarm that starts before the operator-access episode remains visible. "
        "An alarm that starts during the access episode is classified as a suppressed "
        "access consequence. Root-cause candidate is a screening label, not proof of causality."
    )
