# Implementation notes

## Request and line-switch behavior

The browser increments a request version whenever a line is selected. A response is rendered only when its version and line still match the current selection. This prevents a slow response for a previous line from forcing the dashboard back to that line.

The SQL provider also uses:

- a per-line semaphore so identical line queries do not run concurrently;
- a 15-second in-memory snapshot cache;
- a maximum of four concurrent lines during fleet overview queries.

## Management Review action plans

Action plans are local coordination data only. They do not modify the historian, PLCs, alarm database, production status, product disposition, or CMMS. For a durable multi-user deployment, move `ActionPlanStore` to an approved SQL table with audit and access controls.

## Provider selection

`Dashboard:Provider` supports:

- `Synthetic`
- `SqlHistorian`

The Visual Studio launch profiles set this value without changing source files.
