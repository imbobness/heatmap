$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj"
if (-not $env:WW_SQL_USER -or -not $env:WW_SQL_PASSWORD) {
    throw "WW_SQL_USER and WW_SQL_PASSWORD must be set before starting live mode."
}
dotnet restore $project
dotnet run --project $project --launch-profile "HeatmapDashboard.Web (Live Historian)"
