# 3GT TAM Heatmap Dashboard — Visual Studio Solution

This is the ASP.NET Core implementation of the v14 presentation-focused dashboard. It is a separate solution from the Python package and is intended as the base for a future hosted website.

## Included

- Landing page for a broader audience
- Dedicated All Lines Loader Performance page
- Dedicated selected-line hourly heatmap and shift-summary page
- Dedicated Management Review page
- Fillable Management Review recovery action plan with owner, due date, priority, status, notes, editing, completion, and reopening
- Dedicated Active Zone Alerts page using the 15-minute no-increment rule
- Selected-line 60-shift history page
- Synthetic mode for off-network development
- AVEVA/Wonderware SQL Historian provider for live use
- Latest-request-wins browser logic so an older historian response cannot reset the selected line
- 15-second server-side per-line snapshot cache and single-flight line queries
- Read-only manufacturing boundary; the local action plan is not CMMS and does not write to the historian

## Open and run in Visual Studio

1. Install **Visual Studio 2026** (or a compatible release) with the **ASP.NET and web development** workload.
2. Install the **.NET 10 SDK**.
3. Open `HeatmapDashboard.sln`.
4. Allow NuGet to restore `Microsoft.Data.SqlClient`.
5. Select **HeatmapDashboard.Web (Demo)** in the run-profile menu.
6. Press **F5**. The site opens at `http://localhost:8787`.

Synthetic mode does not require access to the work network.

## Live historian configuration

The live launch profile uses `appsettings.Live.json` and the **SqlHistorian** provider. Credentials are deliberately excluded from source control and configuration files.

Set these Windows user environment variables:

```powershell
[Environment]::SetEnvironmentVariable("WW_SQL_USER", "ApplicationUser", "User")
[Environment]::SetEnvironmentVariable("WW_SQL_PASSWORD", "YOUR_PASSWORD", "User")
```

Close and reopen Visual Studio after setting them. Select **HeatmapDashboard.Web (Live Historian)** and press **F5**.

The default live configuration is:

```json
{
  "Historian": {
    "Server": "VISUSJANAW0002",
    "Database": "Runtime"
  }
}
```

Change `appsettings.Live.json` when the production source moves. Do not commit a username or password.

## Command-line run

From the solution folder:

```powershell
dotnet restore .\HeatmapDashboard.sln
dotnet build .\HeatmapDashboard.sln
dotnet run --project .\src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj --launch-profile "HeatmapDashboard.Web (Demo)"
```

For live mode:

```powershell
dotnet run --project .\src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj --launch-profile "HeatmapDashboard.Web (Live Historian)"
```

## Website deployment

Publish a self-contained folder from Visual Studio (**Build > Publish**) or run:

```powershell
dotnet publish .\src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj -c Release -o .\publish
```

The `publish` folder can be hosted with IIS. Install the .NET 10 Hosting Bundle on the IIS server and configure an application pool with **No Managed Code**. Set `WW_SQL_USER` and `WW_SQL_PASSWORD` for the service identity or use an approved secret store.

For access beyond a local workstation, add the organization’s approved authentication method before deployment. The current solution does not invent or bypass corporate identity controls.

## Data and action plans

- Performance targets: `src/HeatmapDashboard.Web/data/targets.json`
- Local recovery plans: `src/HeatmapDashboard.Web/data/management_action_plans.json`
- Main configuration: `src/HeatmapDashboard.Web/appsettings.json`
- Live configuration: `src/HeatmapDashboard.Web/appsettings.Live.json`

The action-plan JSON file must be writable by the website process. For a multi-server deployment, replace the JSON store with SQL Server or another approved shared data store.

## Important live-query note

The SQL service intentionally uses the same AVEVA tables and retrieval modes as the Python application:

- `Runtime.dbo.AnalogLive`
- `Runtime.dbo.AnalogHistory`
- `wwRetrievalMode = 'Cyclic'` with one-hour boundaries
- `wwRetrievalMode = 'Delta'` for completed-shift history

The solution keeps the current query window and reduces unnecessary repeats using short-lived caching. It does not reduce the requested historian window.

## Validation performed in this workspace

- JavaScript syntax check passed with Node.
- All JSON configuration files parsed successfully.
- Solution/project paths and GUID references were checked.
- A full `dotnet build` could not be executed here because this workspace does not have the .NET SDK installed. Run `dotnet restore` and `dotnet build` on the Visual Studio workstation before live deployment.
