using HeatmapDashboard.Web.Models;
using HeatmapDashboard.Web.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<DashboardOptions>(builder.Configuration.GetSection("Dashboard"));
builder.Services.Configure<HistorianOptions>(builder.Configuration.GetSection("Historian"));
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<TargetStore>();
builder.Services.AddSingleton<ActionPlanStore>();
var provider = builder.Configuration["Dashboard:Provider"] ?? "Synthetic";
if (provider.Equals("SqlHistorian", StringComparison.OrdinalIgnoreCase))
    builder.Services.AddSingleton<IDashboardDataService, SqlHistorianDashboardDataService>();
else
    builder.Services.AddSingleton<IDashboardDataService, SyntheticDashboardDataService>();

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/mappings", () => Results.Ok(LineCatalog.Lines));
app.MapGet("/api/data", async (string? line, IDashboardDataService data, CancellationToken token) =>
    Results.Ok(await data.GetLineAsync(line ?? LineCatalog.Lines.Keys.First(), token)));
app.MapGet("/api/overview", async (IDashboardDataService data, CancellationToken token) =>
    Results.Ok(new { generatedAt = DateTimeOffset.UtcNow, rows = await data.GetOverviewAsync(token) }));
app.MapGet("/api/review-triggers", async (IDashboardDataService data, CancellationToken token) =>
    Results.Ok(new { generatedAt = DateTimeOffset.UtcNow, rows = await data.GetManagementReviewAsync(token) }));
app.MapGet("/api/history", async (string? line, int? count, IDashboardDataService data, CancellationToken token) =>
    Results.Ok(await data.GetHistoryAsync(line ?? LineCatalog.Lines.Keys.First(), Math.Clamp(count ?? 60, 1, 120), token)));
app.MapGet("/api/management-action-plans", async (string? line, ActionPlanStore store, CancellationToken token) =>
    Results.Ok(new { line, plans = await store.GetAsync(line, token), localCoordinationOnly = true }));
app.MapPost("/api/management-action-plans", async (ManagementActionPlan plan, ActionPlanStore store, CancellationToken token) =>
    Results.Ok(new { ok = true, plan = await store.UpsertAsync(plan, token), localCoordinationOnly = true }));
app.MapGet("/api/zone-alerts", async (IDashboardDataService data, IConfiguration configuration, CancellationToken token) =>
{
    var threshold = configuration.GetValue("Dashboard:ZoneIdleAlertMinutes", 15); var alerts = new List<object>();
    foreach (var line in LineCatalog.Lines.Keys)
    {
        try
        {
            var snapshot = await data.GetLineAsync(line, token); var current = snapshot.Periods.FirstOrDefault();
            if (current is null || (current.End-current.Start).TotalMinutes < threshold) continue;
            foreach (var zone in new[] { "Z1", "Z2A", "Z3_OUT", "Z4_OUT", "Z5_IN", "ALI_OUT", "Z6_IN" })
                if ((current.Columns.GetValueOrDefault(zone) ?? 0) <= 0)
                    alerts.Add(new { line, zone, tag = snapshot.Tags.GetValueOrDefault(zone), idleSince = current.Start, lastChecked = snapshot.GeneratedAt, lastDelta = current.Columns.GetValueOrDefault(zone) });
        }
        catch { /* Per-line errors are visible on the other pages; do not hide healthy lines. */ }
    }
    return Results.Ok(new { generatedAt = DateTimeOffset.UtcNow, alerts });
});
app.MapGet("/api/alerts/status", async (IDashboardDataService data, CancellationToken token) =>
{
    var overview = await data.GetOverviewAsync(token); return Results.Ok(new { enabled = true, transport = "dashboard", lastRun = DateTimeOffset.UtcNow, lastError = (string?)null, activeZoneAlerts = Array.Empty<object>(), lineCount = overview.Count });
});
app.MapGet("/api/health", (IConfiguration configuration) => Results.Ok(new
{
    applicationVersion = "14.0-dotnet", provider = configuration["Dashboard:Provider"],
    production = new { ok = true, detail = configuration["Dashboard:Provider"] },
    readOnlyManufacturingData = true, machineControl = false, sourceModification = false
}));
app.MapFallbackToFile("index.html");

app.Run();
