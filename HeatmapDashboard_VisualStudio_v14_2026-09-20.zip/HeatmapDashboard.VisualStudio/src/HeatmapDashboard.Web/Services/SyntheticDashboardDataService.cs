using HeatmapDashboard.Web.Models;
using Microsoft.Extensions.Options;

namespace HeatmapDashboard.Web.Services;

public sealed class SyntheticDashboardDataService(TargetStore targets, IOptions<DashboardOptions> options) : IDashboardDataService
{
    private readonly DashboardOptions _options = options.Value;
    private static readonly Dictionary<string, double> YieldTargets = new()
    {
        ["Z2A_YIELD"]=98, ["Z3_YIELD"]=98, ["Z4_YIELD"]=98,
        ["Z5_YIELD"]=95, ["ALI_YIELD"]=90, ["Z6_YIELD"]=98, ["LINE_YIELD"]=90
    };

    public async Task<LineSnapshot> GetLineAsync(string line, CancellationToken cancellationToken = default)
    {
        if (!LineCatalog.Lines.ContainsKey(line)) line = LineCatalog.Lines.Keys.First();
        var target = await targets.GetAsync(line, cancellationToken);
        var now = DateTimeOffset.Now; var hour = new DateTimeOffset(now.Year, now.Month, now.Day, now.Hour, 0, 0, now.Offset);
        var seed = StringComparer.OrdinalIgnoreCase.GetHashCode(line) ^ DateOnly.FromDateTime(now.Date).GetHashCode();
        var random = new Random(seed); var periods = new List<HourPeriod>();
        for (var offset = _options.HistoryHours - 1; offset >= 0; offset--)
        {
            var start = hour.AddHours(-offset - 1); var end = start.AddHours(1);
            periods.Add(new(FormatHour(start, end), start, end, false, MakeColumns(target, random, 1)));
        }
        var fraction = Math.Max((now - hour).TotalHours, .02);
        periods.Insert(0, new("Current Hour", hour, now, true, MakeColumns(target, random, fraction)));
        var completed = periods.Where(p => !p.IsLiveHour).ToArray();
        var actual = completed.Sum(p => p.Columns.GetValueOrDefault("Z6_IN") ?? 0);
        var live = periods[0].Columns.GetValueOrDefault("Z6_IN") ?? 0;
        var projection = actual + live / fraction * Math.Max(12 - completed.Length, 0);
        var goal = target.GetValueOrDefault("SHIFT_GOAL");
        var (trend, action) = DashboardCalculations.Trend(periods, target);
        var summary = new List<ShiftMetric>
        {
            new("Current Shift Projection", projection), new("Shift Goal", goal),
            new("Projected Attainment", goal > 0 ? projection / goal * 100 : null, "percent"),
            new("5 Shift Average", goal * (.88 + random.NextDouble() * .18)),
            new("14 Shift Average", goal * (.88 + random.NextDouble() * .16)),
            new("20 Shift Average", goal * (.89 + random.NextDouble() * .14)),
            new("30 Day Average", goal * (.90 + random.NextDouble() * .12))
        };
        return new("synthetic-dotnet", DateTimeOffset.UtcNow, line, LineCatalog.Lines.Keys.ToArray(),
            _options.HistoryHours, _options.RefreshSeconds, YieldTargets, target, goal,
            LineCatalog.Lines[line], [], periods, summary, trend, action, goal > 0 ? projection / goal * 100 : null);
    }

    public async Task<IReadOnlyList<OverviewRow>> GetOverviewAsync(CancellationToken cancellationToken = default)
    {
        var rows = new List<OverviewRow>();
        foreach (var line in LineCatalog.Lines.Keys)
        {
            var data = await GetLineAsync(line, cancellationToken); var goal = data.ShiftGoal ?? 0;
            var projection = data.ShiftSummary.First(x => x.Label == "Current Shift Projection").Value;
            var attainment = goal > 0 ? projection / goal * 100 : null;
            var current = data.Periods.First().Columns.GetValueOrDefault("Z6_IN");
            var elapsed = Math.Max((data.Periods.First().End - data.Periods.First().Start).TotalHours, .02);
            var rate = data.HourlyTargets.GetValueOrDefault("Z6_IN");
            rows.Add(new(line, goal * (.82 + Random.Shared.NextDouble() * .25), null, projection, goal, attainment,
                projection - goal, rate > 0 ? current / elapsed / rate * 100 : null,
                data.Trend.ChangePercent, data.ActionStatus));
        }
        return rows.OrderBy(r => r.Attainment ?? double.MaxValue).ToArray();
    }

    public async Task<IReadOnlyList<ManagementReviewRow>> GetManagementReviewAsync(CancellationToken cancellationToken = default)
    {
        var overview = await GetOverviewAsync(cancellationToken); var rows = new List<ManagementReviewRow>();
        foreach (var row in overview.Where(r => r.Attainment < 98).Take(8))
        {
            var reds = Math.Clamp((int)Math.Round((100 - (row.Attainment ?? 100)) / 2), 2, 12);
            var tier = reds >= 8 ? "Tier 3" : reds >= 5 ? "Tier 2" : "Tier 1";
            var avg = (row.Goal ?? 0) * ((row.Attainment ?? 0) / 100 + .04);
            rows.Add(new(tier, row.Line, reds, avg, avg - row.Goal, "REMAINS ON REVIEW", row.LastShift,
                row.Goal, row.Gap, (row.Goal ?? 0) * 1.03, DateTimeOffset.Now.AddDays(-reds / 2d)));
        }
        return rows.OrderByDescending(r => r.ConsecutiveRedShifts).ToArray();
    }

    public async Task<object> GetHistoryAsync(string line, int count, CancellationToken cancellationToken = default)
    {
        var target = await targets.GetAsync(line, cancellationToken); var goal = target.GetValueOrDefault("SHIFT_GOAL");
        var random = new Random(StringComparer.OrdinalIgnoreCase.GetHashCode(line)); var end = DateTimeOffset.Now.Date.AddHours(6);
        var rows = Enumerable.Range(0, Math.Clamp(count, 1, 120)).Select(i =>
        {
            var start = end.AddHours(-12 * (count - i)); var value = goal * (.78 + random.NextDouble() * .35);
            return new { start, end = start.AddHours(12), value, attainment = goal > 0 ? value / goal * 100 : (double?)null };
        }).ToArray();
        return new { line, goal, provider = "synthetic-dotnet", rows };
    }

    private static Dictionary<string, double?> MakeColumns(Dictionary<string, double> targets, Random random, double fraction)
    {
        double V(string key, double fallback, double factor) => Math.Max(0, targets.GetValueOrDefault(key, fallback) * fraction * factor * (.92 + random.NextDouble() * .16));
        var z1 = V("Z1", 4000, 1); var z2 = V("Z2A", z1, .99); var z3in = z2; var z3 = V("Z3_OUT", z3in, .985);
        var z4 = V("Z4_OUT", z3, .98); var z5 = V("Z5_IN", z4, .97); var aliIn = z5; var ali = V("ALI_OUT", aliIn, .96); var z6 = V("Z6_IN", ali, .98);
        return DashboardCalculations.Columns(new() { ["Z1"]=z1, ["Z2A"]=z2, ["Z3_IN"]=z3in, ["Z3_OUT"]=z3, ["Z4_OUT"]=z4, ["Z5_IN"]=z5, ["ALI_IN"]=aliIn, ["ALI_OUT"]=ali, ["Z6_IN"]=z6 });
    }

    private static string FormatHour(DateTimeOffset start, DateTimeOffset end) => $"{start:h tt} to {end:h tt}";
}
