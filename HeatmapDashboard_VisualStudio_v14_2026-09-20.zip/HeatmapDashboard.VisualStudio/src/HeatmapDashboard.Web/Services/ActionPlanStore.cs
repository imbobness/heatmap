using System.Text.Json;
using HeatmapDashboard.Web.Models;

namespace HeatmapDashboard.Web.Services;

public sealed class ActionPlanStore(IWebHostEnvironment environment)
{
    private readonly string _path = Path.Combine(environment.ContentRootPath, "data", "management_action_plans.json");
    private readonly SemaphoreSlim _gate = new(1, 1);
    private static readonly HashSet<string> Statuses = ["Open", "In Progress", "Blocked", "Complete"];
    private static readonly HashSet<string> Priorities = ["High", "Medium", "Low"];

    public async Task<IReadOnlyList<ManagementActionPlan>> GetAsync(string? line, CancellationToken token)
    {
        await _gate.WaitAsync(token);
        try
        {
            var document = await ReadAsync(token); return document.Plans
                .Where(p => string.IsNullOrWhiteSpace(line) || p.Line.Equals(line, StringComparison.OrdinalIgnoreCase))
                .OrderBy(p => p.Status == "Complete").ThenBy(p => string.IsNullOrWhiteSpace(p.DueDate) ? "9999-12-31" : p.DueDate).ToArray();
        }
        finally { _gate.Release(); }
    }

    public async Task<ManagementActionPlan> UpsertAsync(ManagementActionPlan input, CancellationToken token)
    {
        if (!LineCatalog.Lines.ContainsKey(input.Line)) throw new ArgumentException("Invalid line");
        if (string.IsNullOrWhiteSpace(input.Title)) throw new ArgumentException("Action item is required");
        if (!Statuses.Contains(input.Status)) throw new ArgumentException("Invalid status");
        if (!Priorities.Contains(input.Priority)) throw new ArgumentException("Invalid priority");
        await _gate.WaitAsync(token);
        try
        {
            var document = await ReadAsync(token); var existing = document.Plans.FirstOrDefault(p => p.Id == input.Id); var now = DateTimeOffset.UtcNow;
            input.Id = string.IsNullOrWhiteSpace(input.Id) ? Guid.NewGuid().ToString() : input.Id;
            input.Title = input.Title.Trim()[..Math.Min(input.Title.Trim().Length, 200)];
            input.Owner = (input.Owner ?? "").Trim()[..Math.Min((input.Owner ?? "").Trim().Length, 100)];
            input.Notes = (input.Notes ?? "").Trim()[..Math.Min((input.Notes ?? "").Trim().Length, 1500)];
            input.CreatedAt = existing?.CreatedAt ?? now; input.UpdatedAt = now; input.CompletedAt = input.Status == "Complete" ? now : null;
            if (existing is null) document.Plans.Add(input); else document.Plans[document.Plans.IndexOf(existing)] = input;
            Directory.CreateDirectory(Path.GetDirectoryName(_path)!); var temp = _path + ".tmp";
            await File.WriteAllTextAsync(temp, JsonSerializer.Serialize(document, JsonOptions), token); File.Move(temp, _path, true); return input;
        }
        finally { _gate.Release(); }
    }

    private async Task<ActionPlanDocument> ReadAsync(CancellationToken token)
    {
        if (!File.Exists(_path)) return new();
        try { return JsonSerializer.Deserialize<ActionPlanDocument>(await File.ReadAllTextAsync(_path, token), JsonOptions) ?? new(); }
        catch (JsonException) { return new(); }
    }

    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web) { WriteIndented = true };
}
