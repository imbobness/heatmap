using System.Text.Json;

namespace HeatmapDashboard.Web.Services;

public sealed class TargetStore(IWebHostEnvironment environment)
{
    private readonly string _path = Path.Combine(environment.ContentRootPath, "data", "targets.json");
    private readonly SemaphoreSlim _gate = new(1, 1);

    public async Task<Dictionary<string, double>> GetAsync(string line, CancellationToken cancellationToken = default)
    {
        if (!File.Exists(_path)) return Defaults(line);
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var stream = File.OpenRead(_path);
            var all = await JsonSerializer.DeserializeAsync<Dictionary<string, Dictionary<string, double?>>>(stream, cancellationToken: cancellationToken);
            var values = all?.GetValueOrDefault(line);
            return values is null ? Defaults(line) : values.Where(item => item.Value.HasValue).ToDictionary(item => item.Key, item => item.Value!.Value);
        }
        catch (JsonException) { return Defaults(line); }
        finally { _gate.Release(); }
    }

    private static Dictionary<string, double> Defaults(string line)
    {
        var number = int.TryParse(line.AsSpan(3), out var value) ? value : 1;
        var hourly = number >= 24 ? 7200d : 3600d;
        return new()
        {
            ["Z1"]=hourly, ["Z2A"]=hourly*.98, ["Z3_OUT"]=hourly*.96,
            ["Z4_OUT"]=hourly*.94, ["Z5_IN"]=hourly*.91, ["ALI_OUT"]=hourly*.88,
            ["Z6_IN"]=hourly*.85, ["SHIFT_GOAL"]=hourly*10.5,
            ["Z2A_YIELD"]=98, ["Z3_YIELD"]=98, ["Z4_YIELD"]=98,
            ["Z5_YIELD"]=95, ["ALI_YIELD"]=90, ["Z6_YIELD"]=98, ["LINE_YIELD"]=90
        };
    }
}
