using System.Collections.Concurrent;
using HeatmapDashboard.Web.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace HeatmapDashboard.Web.Services;

public sealed class SqlHistorianDashboardDataService(
    TargetStore targets,
    IOptions<DashboardOptions> dashboardOptions,
    IOptions<HistorianOptions> historianOptions,
    IMemoryCache cache,
    ILogger<SqlHistorianDashboardDataService> logger) : IDashboardDataService
{
    private readonly DashboardOptions _dashboard = dashboardOptions.Value;
    private readonly HistorianOptions _historian = historianOptions.Value;
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _lineGates = new(StringComparer.OrdinalIgnoreCase);
    private static readonly Dictionary<string, double> YieldTargets = new()
    {
        ["Z2A_YIELD"]=98, ["Z3_YIELD"]=98, ["Z4_YIELD"]=98,
        ["Z5_YIELD"]=95, ["ALI_YIELD"]=90, ["Z6_YIELD"]=98, ["LINE_YIELD"]=90
    };

    public async Task<LineSnapshot> GetLineAsync(string line, CancellationToken cancellationToken = default)
    {
        if (!LineCatalog.Lines.ContainsKey(line)) throw new ArgumentException($"Unknown line: {line}");
        var key = $"line:{line}";
        if (cache.TryGetValue(key, out LineSnapshot? existing) && existing is not null) return existing;
        var gate = _lineGates.GetOrAdd(line, _ => new SemaphoreSlim(1, 1));
        await gate.WaitAsync(cancellationToken);
        try
        {
            if (cache.TryGetValue(key, out existing) && existing is not null) return existing;
            var data = await QueryLineAsync(line, cancellationToken);
            cache.Set(key, data, TimeSpan.FromSeconds(Math.Max(_dashboard.LineCacheSeconds, 5)));
            return data;
        }
        finally { gate.Release(); }
    }

    private async Task<LineSnapshot> QueryLineAsync(string line, CancellationToken cancellationToken)
    {
        var lineTargets = await targets.GetAsync(line, cancellationToken); var tags = LineCatalog.Lines[line];
        var now = DateTime.Now; var currentHour = new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0); var first = currentHour.AddHours(-_dashboard.HistoryHours);
        var boundaries = new Dictionary<string, Dictionary<DateTime, double?>>(); var live = new Dictionary<string, (DateTime Stamp, double? Value)?>(); var missing = new List<string>();
        await using var connection = new SqlConnection(ConnectionString());
        await connection.OpenAsync(cancellationToken);
        foreach (var (key, tag) in tags)
        {
            boundaries[key] = await QueryBoundariesAsync(connection, tag, first, currentHour, cancellationToken);
            live[key] = await QueryLiveAsync(connection, tag, cancellationToken);
            if (boundaries[key].Count == 0 && live[key] is null) missing.Add(tag);
        }
        var periods = new List<HourPeriod>();
        for (var offset = _dashboard.HistoryHours - 1; offset >= 0; offset--)
        {
            var start = first.AddHours(offset); var end = start.AddHours(1); var values = new Dictionary<string, double?>();
            foreach (var key in tags.Keys) values[key] = CounterDelta(boundaries[key].GetValueOrDefault(start), boundaries[key].GetValueOrDefault(end));
            periods.Add(new($"{start:h tt} to {end:h tt}", new DateTimeOffset(start), new DateTimeOffset(end), false, DashboardCalculations.Columns(values)));
        }
        var liveValues = new Dictionary<string, double?>(); var liveEnd = now;
        foreach (var key in tags.Keys)
        {
            var record = live[key]; if (record?.Stamp > liveEnd) liveEnd = record.Value.Stamp;
            liveValues[key] = CounterDelta(boundaries[key].GetValueOrDefault(currentHour), record?.Value);
        }
        periods.Insert(0, new("Current Hour", new DateTimeOffset(currentHour), new DateTimeOffset(liveEnd), true, DashboardCalculations.Columns(liveValues)));
        var shiftStart = now.Hour >= 18 ? now.Date.AddHours(18) : now.Hour >= 6 ? now.Date.AddHours(6) : now.Date.AddDays(-1).AddHours(18);
        var completed = periods.Where(p => !p.IsLiveHour && p.Start >= new DateTimeOffset(shiftStart)).ToArray();
        var actual = completed.Sum(p => p.Columns.GetValueOrDefault("Z6_IN") ?? 0); var liveCount = liveValues.GetValueOrDefault("Z6_IN") ?? 0;
        var elapsedHour = Math.Max((liveEnd - currentHour).TotalHours, .02); var remainingHours = Math.Max(12 - (now - shiftStart).TotalHours, 0);
        var projection = actual + liveCount + liveCount / elapsedHour * remainingHours; var goal = lineTargets.GetValueOrDefault("SHIFT_GOAL");
        var (trend, action) = DashboardCalculations.Trend(periods, lineTargets);
        var summary = new List<ShiftMetric>
        {
            new("Current Shift Projection", projection), new("Shift Goal", goal),
            new("Projected Attainment", goal > 0 ? projection / goal * 100 : null, "percent")
        };
        return new("aveva-sql-dotnet", DateTimeOffset.UtcNow, line, LineCatalog.Lines.Keys.ToArray(), _dashboard.HistoryHours,
            _dashboard.RefreshSeconds, YieldTargets, lineTargets, goal, new(tags), missing, periods, summary, trend, action,
            goal > 0 ? projection / goal * 100 : null);
    }

    public async Task<IReadOnlyList<OverviewRow>> GetOverviewAsync(CancellationToken cancellationToken = default)
    {
        var results = new ConcurrentBag<OverviewRow>();
        await Parallel.ForEachAsync(LineCatalog.Lines.Keys, new ParallelOptions { MaxDegreeOfParallelism = 4, CancellationToken = cancellationToken }, async (line, token) =>
        {
            try
            {
                var data = await GetLineAsync(line, token); var goal = data.ShiftGoal ?? 0;
                var projection = data.ShiftSummary.First(x => x.Label == "Current Shift Projection").Value;
                var current = data.Periods[0]; var value = current.Columns.GetValueOrDefault("Z6_IN");
                var elapsed = Math.Max((current.End - current.Start).TotalHours, .02); var rateTarget = data.HourlyTargets.GetValueOrDefault("Z6_IN");
                results.Add(new(line, null, null, projection, goal, goal > 0 ? projection / goal * 100 : null,
                    projection - goal, rateTarget > 0 ? value / elapsed / rateTarget * 100 : null, data.Trend.ChangePercent, data.ActionStatus));
            }
            catch (Exception ex) { logger.LogError(ex, "Overview query failed for {Line}", line); results.Add(new(line, null, null, null, null, null, null, null, null, null, ex.Message)); }
        });
        return results.OrderBy(r => r.Attainment ?? double.MaxValue).ToArray();
    }

    public async Task<IReadOnlyList<ManagementReviewRow>> GetManagementReviewAsync(CancellationToken cancellationToken = default)
    {
        var overview = await GetOverviewAsync(cancellationToken); return overview.Where(r => r.Error is null && r.Attainment < 98).Select(r =>
        {
            var reds = Math.Clamp((int)Math.Round((100 - (r.Attainment ?? 100)) / 2), 2, 12); var tier = reds >= 8 ? "Tier 3" : reds >= 5 ? "Tier 2" : "Tier 1";
            return new ManagementReviewRow(tier, r.Line, reds, null, null, "REMAINS ON REVIEW", r.LastShift, r.Goal, r.Gap, null, null);
        }).OrderByDescending(r => r.ConsecutiveRedShifts).ToArray();
    }

    public async Task<object> GetHistoryAsync(string line, int count, CancellationToken cancellationToken = default)
    {
        if (!LineCatalog.Lines.TryGetValue(line, out var tags)) throw new ArgumentException("Unknown line");
        var lineTargets = await targets.GetAsync(line, cancellationToken); var goal = lineTargets.GetValueOrDefault("SHIFT_GOAL");
        var end = DateTime.Now.Hour >= 18 ? DateTime.Today.AddHours(18) : DateTime.Now.Hour >= 6 ? DateTime.Today.AddHours(6) : DateTime.Today.AddDays(-1).AddHours(18);
        var start = end.AddHours(-12 * Math.Clamp(count, 1, 120));
        await using var connection = new SqlConnection(ConnectionString()); await connection.OpenAsync(cancellationToken);
        var samples = await QueryDeltaAsync(connection, tags["Z6_IN"], start, end, cancellationToken); var rows = new List<object>();
        for (var cursor = start; cursor < end; cursor = cursor.AddHours(12))
        {
            var slice = samples.Where(x => x.Stamp >= cursor && x.Stamp <= cursor.AddHours(12)).ToArray(); var value = AccumulatedDelta(slice);
            rows.Add(new { start = cursor, end = cursor.AddHours(12), value, attainment = goal > 0 && value.HasValue ? value / goal * 100 : null });
        }
        return new { line, goal, provider = "aveva-sql-dotnet", rows };
    }

    private string ConnectionString()
    {
        var user = Environment.GetEnvironmentVariable(_historian.UserEnvironmentVariable); var password = Environment.GetEnvironmentVariable(_historian.PasswordEnvironmentVariable);
        if (string.IsNullOrWhiteSpace(user) || string.IsNullOrWhiteSpace(password)) throw new InvalidOperationException($"Set {_historian.UserEnvironmentVariable} and {_historian.PasswordEnvironmentVariable} before using live mode.");
        return new SqlConnectionStringBuilder { DataSource = _historian.Server, InitialCatalog = _historian.Database, UserID = user, Password = password,
            Encrypt = _historian.Encrypt, TrustServerCertificate = _historian.TrustServerCertificate, ConnectTimeout = 15 }.ConnectionString;
    }

    private async Task<Dictionary<DateTime, double?>> QueryBoundariesAsync(SqlConnection connection, string tag, DateTime start, DateTime end, CancellationToken token)
    {
        await using var command = connection.CreateCommand(); command.CommandTimeout = _historian.CommandTimeoutSeconds;
        command.CommandText = "SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory WHERE TagName=@tag AND DateTime>=@start AND DateTime<=@end AND wwRetrievalMode='Cyclic' AND wwResolution=3600000 ORDER BY DateTime";
        command.Parameters.AddWithValue("@tag", tag); command.Parameters.AddWithValue("@start", start); command.Parameters.AddWithValue("@end", end);
        var result = new Dictionary<DateTime, double?>(); await using var reader = await command.ExecuteReaderAsync(token);
        while (await reader.ReadAsync(token)) { var stamp = reader.GetDateTime(0); result[new(stamp.Year, stamp.Month, stamp.Day, stamp.Hour, 0, 0)] = reader.IsDBNull(1) ? null : Convert.ToDouble(reader.GetValue(1)); }
        return result;
    }

    private async Task<(DateTime Stamp, double? Value)?> QueryLiveAsync(SqlConnection connection, string tag, CancellationToken token)
    {
        await using var command = connection.CreateCommand(); command.CommandTimeout = _historian.CommandTimeoutSeconds;
        command.CommandText = "SELECT TOP 1 DateTime, Value FROM Runtime.dbo.AnalogLive WHERE TagName=@tag"; command.Parameters.AddWithValue("@tag", tag);
        await using var reader = await command.ExecuteReaderAsync(token); if (!await reader.ReadAsync(token)) return null;
        return (reader.GetDateTime(0), reader.IsDBNull(1) ? null : Convert.ToDouble(reader.GetValue(1)));
    }

    private async Task<List<(DateTime Stamp, double? Value)>> QueryDeltaAsync(SqlConnection connection, string tag, DateTime start, DateTime end, CancellationToken token)
    {
        await using var command = connection.CreateCommand(); command.CommandTimeout = _historian.CommandTimeoutSeconds;
        command.CommandText = "SELECT DateTime, Value FROM Runtime.dbo.AnalogHistory WHERE TagName=@tag AND DateTime>=@start AND DateTime<=@end AND wwRetrievalMode='Delta' ORDER BY DateTime";
        command.Parameters.AddWithValue("@tag", tag); command.Parameters.AddWithValue("@start", start); command.Parameters.AddWithValue("@end", end);
        var result = new List<(DateTime, double?)>(); await using var reader = await command.ExecuteReaderAsync(token);
        while (await reader.ReadAsync(token)) result.Add((reader.GetDateTime(0), reader.IsDBNull(1) ? null : Convert.ToDouble(reader.GetValue(1))));
        return result;
    }

    private static double? CounterDelta(double? start, double? end) => start.HasValue && end.HasValue ? (end >= start ? end - start : end) : null;
    private static double? AccumulatedDelta(IReadOnlyList<(DateTime Stamp, double? Value)> samples)
    {
        var values = samples.Where(x => x.Value.HasValue).Select(x => x.Value!.Value).ToArray(); if (values.Length < 2) return null;
        var total = 0d; for (var i=1;i<values.Length;i++) total += values[i] >= values[i-1] ? values[i]-values[i-1] : values[i]; return total;
    }
}
