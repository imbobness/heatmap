namespace HeatmapDashboard.Web.Services;

public static class LineCatalog
{
    private static readonly int[] Legacy = [1, 2, 5, 6, 7, 9, 10, 17, 18, 20];
    private static readonly int[] Transition = [21, 22, 23];
    private static readonly int[] Flex = [24, 25, 26, 27, 28, 29, 30, 31, 32, 33];
    private static readonly Dictionary<int, string> Prefix = new()
    {
        [1]="A", [2]="B", [5]="E", [6]="F", [7]="G", [9]="I", [10]="J",
        [17]="M", [18]="N", [20]="S"
    };

    public static IReadOnlyDictionary<string, Dictionary<string, string>> Lines { get; } = Build();

    private static IReadOnlyDictionary<string, Dictionary<string, string>> Build()
    {
        var result = new SortedDictionary<string, Dictionary<string, string>>(StringComparer.OrdinalIgnoreCase);
        foreach (var n in Legacy) result[$"TAM{n:00}"] = LegacyTags(n);
        foreach (var n in Transition.Where(n => n != 23)) result[$"TAM{n:00}"] = TransitionTags(n);
        result["TAM23"] = Tam23Tags();
        foreach (var n in Flex) result[$"TAM{n:00}"] = FlexTags(n);

        result["TAM02"]["Z5_IN"] = "BP2_InCount2";
        result["TAM02"]["ALI_IN"] = "BP2_InCount3";
        result["TAM02"]["ALI_OUT"] = "BP2_OutCount3";
        result["TAM06"]["ALI_OUT"] = "FP2_OutCount3";
        foreach (var line in new[] { "TAM17", "TAM18", "TAM20" })
        {
            result[line]["Z5_IN"] = $"{Prefix[int.Parse(line[3..])]}P2_InCount2";
            result[line]["ALI_IN"] = $"{Prefix[int.Parse(line[3..])]}P2_InCount3";
            result[line]["ALI_OUT"] = $"{Prefix[int.Parse(line[3..])]}P2_OutCount3";
        }
        result["TAM26"]["ALI_IN"] = "L26_PLC3.EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.Out";
        result["TAM26"]["ALI_OUT"] = "L26_PLC3.EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out";
        result["TAM27"]["ALI_IN"] = "L27_PLC3.EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In";
        result["TAM27"]["ALI_OUT"] = "L27_PLC3.EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out";
        return result;
    }

    private static Dictionary<string, string> LegacyTags(int n)
    {
        var p = Prefix[n];
        return new()
        {
            ["Z1"]=$"{p}P0_GOODCOUNT1", ["Z2A"]=$"{p}P0_GOODCOUNT2",
            ["Z3_IN"]=$"{p}P0_GOODCOUNT6", ["Z3_OUT"]=$"{p}P1_GOODCOUNT1",
            ["Z4_OUT"]=$"{p}P1_GOODCOUNT3", ["Z5_IN"]=$"{p}P2_INCOUNT2",
            ["ALI_IN"]=$"{p}P2_INCOUNT3", ["ALI_OUT"]=$"{p}P2_OUTCOUNT3",
        ["Z6_IN"]=$"{p}P3_LOAD_IN_CNT"
        };
    }

    private static Dictionary<string, string> TransitionTags(int n) => new()
    {
        ["Z1"]=$"L{n}_P1_Data.Crv_CountIMMStarts", ["Z2A"]=$"L{n}_P1_Data.GoodCountInlay",
        ["Z3_IN"]=$"L{n}_P1_Data.GoodCountCure", ["Z3_OUT"]=$"L{n}_P1_Data.GoodCountDemold",
        ["Z4_OUT"]=$"L{n}_P1_Data.GoodCountFCXfer", ["Z5_IN"]=$"L{n}_P3_Data.InCountLensXfer",
        ["ALI_IN"]=$"L{n}_P3_Data.OutCountLensXfer", ["ALI_OUT"]=$"L{n}_P3_Data.OutCountDIRemoval",
        ["Z6_IN"]=$"L{n}_P4_Data.OutCountLoader"
    };

    private static Dictionary<string, string> Tam23Tags() => new()
    {
        ["Z1"]="SP0_GOODCOUNT1", ["Z2A"]="SP0_GOODCOUNT2", ["Z3_IN"]="SP0_GOODCOUNT6",
        ["Z3_OUT"]="SP1_GOODCOUNT1", ["Z4_OUT"]="SP1_GOODCOUNT3", ["Z5_IN"]="SP2_INCOUNT2",
        ["ALI_IN"]="SP2_INCOUNT3", ["ALI_OUT"]="SP2_OUTCOUNT3", ["Z6_IN"]="SP3_LOAD_IN_CNT"
    };

    private static Dictionary<string, string> FlexTags(int n)
    {
        var p1=$"L{n}_PLC1_"; var p2=$"L{n}_PLC2_"; var p3=$"L{n}_PLC3_"; var p4=$"L{n}_PLC4_";
        return new()
        {
        ["Z1"]=$"{p1}Global.StatsCnt_Z01.CurrS.Total.In",
        ["Z2A"]=$"{p1}Global.StatsCnt_Z02.CurrS.Total.In",
        ["Z3_IN"]=n>=29?$"{p2}EM0312_Demold.StatsCnt.CurrS.Total.In":$"{p1}EM0304_WB_Demold.StatsCnt.CurrS.Total.In",
        ["Z3_OUT"]=n>=29?$"{p2}EM0312_Demold.StatsCnt.CurrS.Total.Out":$"{p1}EM0304_WB_Demold.StatsCnt.CurrS.Total.Out",
        ["Z4_IN"]=$"{p2}EM0332_FC_Transfer.StatsCnt.CurrS.Total.In",
        ["Z4_OUT"]=n>=29?$"{p2}EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out":$"{p1}EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out",
        ["Z5_IN"]=$"{p3}EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In",
        ["ALI_IN"]=n>=29?$"{p3}EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In":$"{p3}EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.In",
        ["ALI_OUT"]=$"{p3}EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out",
        ["Z6_IN"]=$"{p4}EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In"
        };
    }
}
