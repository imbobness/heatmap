namespace HeatmapDashboard.Web.Services;

public sealed class DashboardOptions
{
    public string Provider { get; set; } = "Synthetic";
    public int RefreshSeconds { get; set; } = 60;
    public int HistoryHours { get; set; } = 12;
    public int LineCacheSeconds { get; set; } = 15;
    public int ZoneIdleAlertMinutes { get; set; } = 15;
}

public sealed class HistorianOptions
{
    public string Server { get; set; } = "VISUSJANAW0002";
    public string Database { get; set; } = "Runtime";
    public string UserEnvironmentVariable { get; set; } = "WW_SQL_USER";
    public string PasswordEnvironmentVariable { get; set; } = "WW_SQL_PASSWORD";
    public bool Encrypt { get; set; }
    public bool TrustServerCertificate { get; set; } = true;
    public int CommandTimeoutSeconds { get; set; } = 90;
}
