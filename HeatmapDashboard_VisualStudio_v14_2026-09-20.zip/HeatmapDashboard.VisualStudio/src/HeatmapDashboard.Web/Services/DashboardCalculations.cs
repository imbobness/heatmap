using HeatmapDashboard.Web.Models;

namespace HeatmapDashboard.Web.Services;

public static class DashboardCalculations
{
    public static Dictionary<string, double?> Columns(Dictionary<string, double?> values)
    {
        double? Yield(string input, string output) => values.GetValueOrDefault(input) is double i && i > 0 && values.GetValueOrDefault(output) is double o ? o / i * 100 : null;
        var result = new Dictionary<string, double?>(values, StringComparer.OrdinalIgnoreCase)
        {
            ["Z2A_YIELD"] = Yield("Z1", "Z2A"),
            ["Z3_YIELD"] = Yield("Z3_IN", "Z3_OUT"),
            ["Z4_YIELD"] = Yield("Z3_OUT", "Z4_OUT"),
            ["Z5_YIELD"] = Yield("Z4_OUT", "Z5_IN"),
            ["ALI_YIELD"] = Yield("ALI_IN", "ALI_OUT"),
            ["Z6_YIELD"] = Yield("ALI_OUT", "Z6_IN"),
            ["LINE_YIELD"] = Yield("Z1", "Z6_IN")
        };
        return result;
    }

    public static (TrendInfo Trend, ActionStatus Action) Trend(IReadOnlyList<HourPeriod> periods, Dictionary<string, double> targets)
    {
        var values = periods.Where(p => !p.IsLiveHour).TakeLast(3).Select(p => p.Columns.GetValueOrDefault("Z6_IN")).Where(v => v.HasValue).Select(v => v!.Value).ToArray();
        if (values.Length < 2) return (new("stable", "No trend", null, null, "Not enough completed hours"), new("NO_DATA", "NO DATA", "Waiting for completed-hour data"));
        var first = values.First(); var last = values.Last(); var change = first == 0 ? 0 : (last - first) / first * 100;
        var target = targets.GetValueOrDefault("Z6_IN"); var attainment = target > 0 ? values.Average() / target * 100 : (double?)null;
        var direction = change >= 5 ? "improving" : change <= -5 ? "declining" : "stable";
        var trend = new TrendInfo(direction, char.ToUpper(direction[0]) + direction[1..], change, attainment, "Three completed-hour loader trend");
        var action = direction == "declining" && attainment < 95 ? new ActionStatus("INTERVENE", "INTERVENE", "Rate is declining below target")
            : direction == "improving" && attainment < 98 ? new("RECOVERING", "RECOVERING", "Output is improving")
            : attainment < 95 ? new("INVESTIGATE", "INVESTIGATE", "Output remains below target")
            : new("HEALTHY", "HEALTHY", "Maintain current conditions");
        return (trend, action);
    }
}
