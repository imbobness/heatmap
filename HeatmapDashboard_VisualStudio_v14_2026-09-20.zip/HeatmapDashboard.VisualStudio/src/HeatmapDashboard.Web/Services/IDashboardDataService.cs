using HeatmapDashboard.Web.Models;

namespace HeatmapDashboard.Web.Services;

public interface IDashboardDataService
{
    Task<LineSnapshot> GetLineAsync(string line, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<OverviewRow>> GetOverviewAsync(CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ManagementReviewRow>> GetManagementReviewAsync(CancellationToken cancellationToken = default);
    Task<object> GetHistoryAsync(string line, int count, CancellationToken cancellationToken = default);
}
