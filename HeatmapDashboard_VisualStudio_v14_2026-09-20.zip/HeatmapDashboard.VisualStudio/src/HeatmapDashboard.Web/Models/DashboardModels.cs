namespace HeatmapDashboard.Web.Models;

public sealed record HourPeriod(
    string Label,
    DateTimeOffset Start,
    DateTimeOffset End,
    bool IsLiveHour,
    Dictionary<string, double?> Columns);

public sealed record ShiftMetric(string Label, double? Value, string Format = "count", string? ShiftWindow = null);

public sealed record TrendInfo(string Direction, string Status, double? ChangePercent, double? TargetAttainmentPercent, string Message);

public sealed record ActionStatus(string Code, string Label, string Message);

public sealed record LineSnapshot(
    string Provider,
    DateTimeOffset GeneratedAt,
    string SelectedLine,
    IReadOnlyList<string> AvailableLines,
    int HistoryHours,
    int RefreshSeconds,
    Dictionary<string, double> Targets,
    Dictionary<string, double> HourlyTargets,
    double? ShiftGoal,
    Dictionary<string, string> Tags,
    IReadOnlyList<string> MissingTags,
    IReadOnlyList<HourPeriod> Periods,
    IReadOnlyList<ShiftMetric> ShiftSummary,
    TrendInfo Trend,
    ActionStatus ActionStatus,
    double? ProjectedAttainment = null);

public sealed record OverviewRow(
    string Line,
    double? LastShift,
    double? CurrentActual,
    double? CurrentProjection,
    double? Goal,
    double? Attainment,
    double? Gap,
    double? CurrentRateAttainment,
    double? TrendChange,
    ActionStatus? Action,
    string? Error = null);

public sealed record ManagementReviewRow(
    string Tier,
    string Line,
    int ConsecutiveRedShifts,
    double? TwentyShiftAverage,
    double? TwentyShiftGap,
    string ReviewStatus,
    double? LastCompletedShift,
    double? Goal,
    double? Gap,
    double? LastKnownGreenShift,
    DateTimeOffset? LastGreenEnd,
    string? Error = null);

public sealed class ManagementActionPlan
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Line { get; set; } = "";
    public string Title { get; set; } = "";
    public string Owner { get; set; } = "";
    public string DueDate { get; set; } = "";
    public string Priority { get; set; } = "Medium";
    public string Status { get; set; } = "Open";
    public string Notes { get; set; } = "";
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? CompletedAt { get; set; }
}

public sealed class ActionPlanDocument
{
    public int Version { get; set; } = 1;
    public List<ManagementActionPlan> Plans { get; set; } = [];
}
