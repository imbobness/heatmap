$ErrorActionPreference = "Stop"
$project = Join-Path $PSScriptRoot "src\HeatmapDashboard.Web\HeatmapDashboard.Web.csproj"
dotnet restore $project
dotnet run --project $project --launch-profile "HeatmapDashboard.Web (Demo)"
