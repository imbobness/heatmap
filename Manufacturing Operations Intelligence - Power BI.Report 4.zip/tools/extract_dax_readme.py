from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "Manufacturing Operations Intelligence - Power BI.SemanticModel" / "definition" / "tables"
OUTPUT = ROOT / "README_DAX.md"


def unquote(name):
    name = name.strip()
    if name.startswith("'") and name.endswith("'"):
        return name[1:-1].replace("''", "'")
    return name


def clean_expression(lines):
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    if not lines:
        return ""
    widths = [len(line) - len(line.lstrip()) for line in lines if line.strip()]
    margin = min(widths) if widths else 0
    return "\n".join(line[margin:].rstrip() for line in lines)


def parse_file(path):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    table_match = next((re.match(r"table\s+(.+)$", line) for line in lines if line.startswith("table ")), None)
    table_name = unquote(table_match.group(1)) if table_match else path.stem
    measures = []
    columns = []
    table_expression = None
    index = 0
    while index < len(lines):
        line = lines[index]
        measure_match = re.match(r"\tmeasure\s+(.+?)\s*=\s*(.*)$", line)
        column_match = re.match(r"\tcolumn\s+(.+?)(?:\s*=\s*(.*))?$", line)
        if measure_match:
            name = unquote(measure_match.group(1))
            expression_lines = []
            if measure_match.group(2).strip():
                expression_lines.append(measure_match.group(2))
            index += 1
            while index < len(lines) and not re.match(r"\t(?:measure|column|partition|hierarchy)\s", lines[index]):
                if not re.match(r"\t\t(?:formatString|lineageTag|annotation|displayFolder):", lines[index]):
                    expression_lines.append(lines[index])
                index += 1
            measures.append((name, clean_expression(expression_lines)))
            continue
        if column_match:
            name = unquote(column_match.group(1))
            expression_lines = []
            if column_match.group(2) and column_match.group(2).strip():
                expression_lines.append(column_match.group(2))
            index += 1
            while index < len(lines) and not re.match(r"\t(?:measure|column|partition|hierarchy)\s", lines[index]):
                expression_match = re.match(r"\t\texpression\s*=\s*(.*)$", lines[index])
                if expression_match:
                    if expression_match.group(1).strip():
                        expression_lines.append(expression_match.group(1))
                    index += 1
                    while index < len(lines) and lines[index].startswith("\t\t\t"):
                        expression_lines.append(lines[index])
                        index += 1
                    continue
                index += 1
            expression = clean_expression(expression_lines)
            if expression:
                columns.append((name, expression))
            continue
        partition_match = re.match(r"\tpartition\s+.+?\s*=\s*calculated", line)
        if partition_match:
            index += 1
            expression_lines = []
            while index < len(lines) and not re.match(r"\t(?:measure|column|partition|hierarchy)\s", lines[index]):
                source_match = re.match(r"\t\tsource\s*=\s*(.*)$", lines[index])
                if source_match:
                    if source_match.group(1).strip():
                        expression_lines.append(source_match.group(1))
                    index += 1
                    while index < len(lines) and lines[index].startswith("\t\t\t"):
                        expression_lines.append(lines[index])
                        index += 1
                    continue
                index += 1
            table_expression = clean_expression(expression_lines)
            continue
        index += 1
    return table_name, measures, columns, table_expression


tables = [parse_file(path) for path in sorted(TABLES.glob("*.tmdl"))]
measure_count = sum(len(table[1]) for table in tables)
column_count = sum(len(table[2]) for table in tables)
calculated_table_count = sum(1 for table in tables if table[3])

output = [
    "# DAX Reference — Manufacturing Operations Intelligence",
    "",
    "This file was generated from the semantic model TMDL definitions. Each heading is one separate Power BI object. Copy only the expression inside its DAX block when recreating that object.",
    "",
    f"- Measures: **{measure_count}**",
    f"- Calculated columns: **{column_count}**",
    f"- Calculated tables: **{calculated_table_count}**",
    "",
    "> Hidden `LocalDateTable_*` and `DateTableTemplate_*` objects are automatically generated Power BI date tables. They normally should not be recreated manually.",
    "",
]

for table_name, measures, columns, table_expression in tables:
    if not measures and not columns and not table_expression:
        continue
    output += [f"## {table_name}", ""]
    if table_expression:
        output += ["### Calculated table", "", f"#### {table_name}", "", "````DAX", table_expression, "````", ""]
    if measures:
        output += ["### Measures", ""]
        for name, expression in measures:
            output += [f"#### {name}", "", "````DAX", expression, "````", ""]
    if columns:
        output += ["### Calculated columns", ""]
        for name, expression in columns:
            output += [f"#### {name}", "", "````DAX", expression, "````", ""]

OUTPUT.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
print(f"Wrote {OUTPUT.name}: {measure_count} measures, {column_count} calculated columns, {calculated_table_count} calculated tables")
