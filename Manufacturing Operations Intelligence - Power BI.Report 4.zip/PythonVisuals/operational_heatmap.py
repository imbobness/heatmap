import math

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.patches import Patch


COLUMNS = [
    "Line",
    "ZoneKey",
    "HourStart",
    "HourlyProduction",
    "ZoneTarget",
    "MinutesSinceProduction",
    "ShiftGoal",
    "ShiftOutput",
    "ProjectedShiftTotal",
    "HistorianLatestTime",
]

ZONE_ORDER = [
    "Z1",
    "Z2A",
    "Z3_IN",
    "Z3_OUT",
    "Z4_IN",
    "Z4_OUT",
    "Z5_IN",
    "ALI_IN",
    "ALI_OUT",
    "Z6_IN",
]

ZONE_LABELS = {
    "Z1": "Zone 1",
    "Z2A": "Zone 2A",
    "Z3_IN": "Zone 3 In",
    "Z3_OUT": "Zone 3 Out",
    "Z4_IN": "Zone 4 In",
    "Z4_OUT": "Zone 4 Out",
    "Z5_IN": "Zone 5 In",
    "ALI_IN": "ALI In",
    "ALI_OUT": "ALI Out",
    "Z6_IN": "Zone 6 In",
}


def natural_line_key(value):
    text = str(value)
    digits = "".join(character for character in text if character.isdigit())
    return (int(digits) if digits else 999999, text)


def empty_visual(message):
    figure, axis = plt.subplots(figsize=(16, 8), facecolor="#111827")
    axis.set_facecolor("#111827")
    axis.axis("off")
    axis.text(
        0.5,
        0.5,
        message,
        ha="center",
        va="center",
        color="#F9FAFB",
        fontsize=20,
        weight="bold",
    )
    plt.tight_layout()
    plt.show()


if dataset is None or dataset.empty:
    empty_visual("No historian data is available for the selected line")
else:
    frame = dataset.copy()
    if len(frame.columns) < len(COLUMNS):
        empty_visual("The Python visual is missing one or more required fields")
    else:
        frame = frame.iloc[:, : len(COLUMNS)]
        frame.columns = COLUMNS
        frame["Line"] = frame["Line"].astype(str)
        frame["ZoneKey"] = frame["ZoneKey"].astype(str)
        frame["HourStart"] = pd.to_datetime(frame["HourStart"], errors="coerce")
        frame["HistorianLatestTime"] = pd.to_datetime(
            frame["HistorianLatestTime"], errors="coerce"
        )
        numeric_columns = [
            "HourlyProduction",
            "ZoneTarget",
            "MinutesSinceProduction",
            "ShiftGoal",
            "ShiftOutput",
            "ProjectedShiftTotal",
        ]
        for column in numeric_columns:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")

        valid_lines = sorted(
            [value for value in frame["Line"].dropna().unique() if value != "nan"],
            key=natural_line_key,
        )
        if not valid_lines:
            empty_visual("Select a manufacturing line")
        else:
            selected_line = valid_lines[0]
            frame = frame[frame["Line"] == selected_line].copy()
            historian_time = frame["HistorianLatestTime"].max()
            if pd.isna(historian_time):
                historian_time = frame["HourStart"].max()

            if pd.isna(historian_time):
                empty_visual("No valid historian timestamps are available")
            else:
                if historian_time.hour >= 18:
                    shift_start = historian_time.normalize() + pd.Timedelta(hours=18)
                elif historian_time.hour >= 6:
                    shift_start = historian_time.normalize() + pd.Timedelta(hours=6)
                else:
                    shift_start = (
                        historian_time.normalize()
                        - pd.Timedelta(days=1)
                        + pd.Timedelta(hours=18)
                    )

                current_hour = historian_time.floor("h")
                frame = frame[
                    (frame["HourStart"] >= shift_start)
                    & (frame["HourStart"] <= current_hour)
                ].copy()

                zones_present = set(frame["ZoneKey"].dropna().unique())
                zones = [zone for zone in ZONE_ORDER if zone in zones_present]
                zones += sorted(zones_present.difference(zones))
                hours = pd.date_range(shift_start, current_hour, freq="h")

                grouped = (
                    frame.groupby(["ZoneKey", "HourStart"], as_index=False)
                    .agg(
                        HourlyProduction=("HourlyProduction", "sum"),
                        ZoneTarget=("ZoneTarget", "max"),
                        MinutesSinceProduction=("MinutesSinceProduction", "max"),
                    )
                )

                score = np.full((len(zones), len(hours)), np.nan)
                production = np.full((len(zones), len(hours)), np.nan)
                annotation = np.full((len(zones), len(hours)), "", dtype=object)
                down_zones = set()
                elapsed_fraction = max(
                    1.0 / 60.0,
                    min(1.0, (historian_time - current_hour).total_seconds() / 3600.0),
                )

                for row_index, zone in enumerate(zones):
                    for column_index, hour in enumerate(hours):
                        match = grouped[
                            (grouped["ZoneKey"] == zone)
                            & (grouped["HourStart"] == hour)
                        ]
                        if match.empty:
                            continue
                        row = match.iloc[0]
                        output = row["HourlyProduction"]
                        target = row["ZoneTarget"]
                        minutes_idle = row["MinutesSinceProduction"]
                        production[row_index, column_index] = output
                        target_for_period = target
                        if hour == current_hour and pd.notna(target):
                            target_for_period = target * elapsed_fraction
                        if pd.notna(output) and pd.notna(target_for_period) and target_for_period > 0:
                            score[row_index, column_index] = output / target_for_period

                        if (
                            hour == current_hour
                            and pd.notna(minutes_idle)
                            and minutes_idle >= 15
                        ):
                            score[row_index, column_index] = -0.25
                            down_zones.add(zone)
                            annotation[row_index, column_index] = (
                                f"DOWN {int(minutes_idle)}m\n{output:,.0f}"
                            )
                        elif pd.notna(output):
                            percent_text = ""
                            if not math.isnan(score[row_index, column_index]):
                                percent_text = f"\n{score[row_index, column_index]:.0%}"
                            annotation[row_index, column_index] = f"{output:,.0f}{percent_text}"

                colors = [
                    "#7F1D1D",
                    "#DC2626",
                    "#F97316",
                    "#FACC15",
                    "#22C55E",
                    "#2563EB",
                ]
                boundaries = [-0.5, 0.0, 0.5, 0.75, 0.95, 1.05, 10.0]
                color_map = ListedColormap(colors)
                color_map.set_bad("#374151")
                normalizer = BoundaryNorm(boundaries, color_map.N)

                figure, axis = plt.subplots(figsize=(16, 8), facecolor="#111827")
                axis.set_facecolor("#111827")
                axis.imshow(score, cmap=color_map, norm=normalizer, aspect="auto")

                for row_index in range(len(zones)):
                    for column_index in range(len(hours)):
                        text = annotation[row_index, column_index]
                        if text:
                            axis.text(
                                column_index,
                                row_index,
                                text,
                                ha="center",
                                va="center",
                                fontsize=8,
                                color="#FFFFFF" if score[row_index, column_index] < 0.75 else "#111827",
                                weight="bold",
                            )

                axis.set_xticks(range(len(hours)))
                axis.set_xticklabels(
                    [hour.strftime("%I %p").lstrip("0") for hour in hours],
                    color="#E5E7EB",
                    fontsize=9,
                )
                axis.set_yticks(range(len(zones)))
                axis.set_yticklabels(
                    [ZONE_LABELS.get(zone, zone) for zone in zones],
                    color="#F9FAFB",
                    fontsize=10,
                    weight="bold",
                )
                axis.set_xlabel("Current 12-hour shift", color="#D1D5DB", labelpad=10)
                axis.tick_params(length=0)
                for spine in axis.spines.values():
                    spine.set_visible(False)

                shift_output = frame["ShiftOutput"].max()
                shift_goal = frame["ShiftGoal"].max()
                projected = frame["ProjectedShiftTotal"].max()
                attainment = projected / shift_goal if pd.notna(projected) and shift_goal > 0 else np.nan
                status_text = "No active 15-minute stops"
                if down_zones:
                    status_text = f"{len(down_zones)} zone stop alert"
                    if len(down_zones) != 1:
                        status_text += "s"
                title = (
                    f"{selected_line}  |  Output {shift_output:,.0f}  |  Goal {shift_goal:,.0f}  |  "
                    f"Projected {projected:,.0f} ({attainment:.1%})  |  {status_text}"
                )
                axis.set_title(title, color="#F9FAFB", fontsize=15, weight="bold", pad=18)
                figure.text(
                    0.99,
                    0.985,
                    f"Historian through {historian_time:%m/%d/%Y %I:%M %p}",
                    ha="right",
                    va="top",
                    color="#9CA3AF",
                    fontsize=8,
                )
                legend_items = [
                    Patch(facecolor="#7F1D1D", label="15+ min no output"),
                    Patch(facecolor="#DC2626", label="Below 50%"),
                    Patch(facecolor="#F97316", label="50–74%"),
                    Patch(facecolor="#FACC15", label="75–94%"),
                    Patch(facecolor="#22C55E", label="95–104%"),
                    Patch(facecolor="#2563EB", label="105%+"),
                    Patch(facecolor="#374151", label="No data"),
                ]
                legend = axis.legend(
                    handles=legend_items,
                    ncol=7,
                    loc="upper center",
                    bbox_to_anchor=(0.5, -0.10),
                    frameon=False,
                    fontsize=8,
                )
                for label in legend.get_texts():
                    label.set_color("#D1D5DB")

                plt.subplots_adjust(left=0.08, right=0.99, top=0.88, bottom=0.18)
                plt.show()
