# DAX Reference — Manufacturing Operations Intelligence

This file was generated from the semantic model TMDL definitions. Each heading is one separate Power BI object. Copy only the expression inside its DAX block when recreating that object.

- Measures: **64**
- Calculated columns: **37**
- Calculated tables: **7**

> Hidden `LocalDateTable_*` and `DateTableTemplate_*` objects are automatically generated Power BI date tables. They normally should not be recreated manually.

## DateTableTemplate_40cd893d-74de-4d18-9292-19409435ec21

### Calculated table

#### DateTableTemplate_40cd893d-74de-4d18-9292-19409435ec21

````DAX
Calendar(Date(2015,1,1), Date(2015,1,1))
````

### Calculated columns

#### Year

````DAX
YEAR([Date])
````

#### MonthNo

````DAX
MONTH([Date])
````

#### Month

````DAX
FORMAT([Date], "MMMM")
````

#### QuarterNo

````DAX
INT(([MonthNo] + 2) / 3)
````

#### Quarter

````DAX
"Qtr " & [QuarterNo]
````

#### Day

````DAX
DAY([Date])
````

## DimLine

### Measures

#### Current Shift Start

````DAX
VAR N = NOW()
VAR D = DATE(YEAR(N), MONTH(N), DAY(N))
RETURN SWITCH(TRUE(), HOUR(N) < 6, D - TIME(6,0,0), HOUR(N) < 18, D + TIME(6,0,0), D + TIME(18,0,0))
````

#### Current Shift Production

````DAX
	VAR S = [Current Shift Start]
	RETURN CALCULATE(SUM(FactRecent[Increment]), FactRecent[SampleTime] >= S, FactRecent[ZoneKey] = "Z6_IN")

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Elapsed Shift Hours

````DAX
```
			MAX(0.0167, DIVIDE(DATEDIFF([Current Shift Start], NOW(), MINUTE), 60.0))

			```

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Current Rate Per Hour

````DAX
```
			DIVIDE([Current Shift Production], [Elapsed Shift Hours])

			```

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Shift Goal

````DAX
VAR L = SELECTEDVALUE(DimLine[Line])
RETURN CALCULATE(MAX(DimTarget[TargetValue]), DimTarget[Line] = L, DimTarget[Metric] = "SHIFT_GOAL")
````

#### Zone Current Shift Production

````DAX
	VAR ShiftStart = [Current Shift Start]
	RETURN
	    CALCULATE(
	            SUM(FactRecent[Increment]),
	            FactRecent[SampleTime]>= ShiftStart,
	            FactRecent[SampleTime]<= NOW())

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Zone Current Rate Per Hour

````DAX
	DIVIDE(
	        [Zone Current Shift Production],
	        [Elapsed Shift Hours]
	)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Zone Target Rate

````DAX
```

			VAR SelectedLine =
			    SELECTEDVALUE(DimLine[Line])
			VAR SelectedZone =
			    SELECTEDVALUE(DimZone[ZoneKey])
			RETURN
			    CALCULATE(
			            MAX(DimTarget[TargetValue]),
			            FILTER(
			                All(DimTarget),
			                DimTarget[Line] = SelectedLine
			                    && DimTarget[Metric] = SelectedZone
			            )
			    )
			```

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Zone Rate Attainment

````DAX
	DIVIDE(
	    [Zone Current Rate Per Hour],
	    [Zone Target Rate]
	)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Zone Heatmap Color

````DAX
VAR Attainment = [Zone Rate Attainment]
VAR DataState = [Data Status]
RETURN
    SWITCH(
        True(),
        DataState = "UNAVAILABLE", "#BDBDBD",
        DataState = "STALE", "#828282",
        ISBLANK(Attainment), "#E0E0E0",
        Attainment >= 0.98, "#27AE60",
        Attainment >= 0.90, "#F2C94C",
        Attainment >= 0.70, "#F2994A",
                            "#EB5757"
    )
````

#### Production

````DAX
	SUMX(
	    FactRecent,
	    VAR Inc = FactRecent[Increment]
	    RETURN
	        IF(
	            ISBLANK(Inc)
	                || Inc < 0
	                || Inc > 50000,
	            BLANK(),
	            Inc
	        )
	)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Zone Target Per Hour

````DAX
	VAR SelectedLine =
	    SELECTEDVALUE(DimLine[Line])
	VAR SelectedZone =
	    SELECTEDVALUE(DimTag[ZoneKey])
	VAR TargetMetric =
	    SWITCH(
	        SelectedZone,
	        "Z3_IN", "Z3_OUT",
	        "Z4_IN", "Z4_OUT",
	        "ALI_IN", "ALI_OUT",
	        SelectedZone
	    )
	RETURN
	    CALCULATE(
	        MAX(DimTarget[TargetValue]),
	        FILTER(
	            ALL(DimTarget),
	            DimTarget[Line] = SelectedLine
	                && DimTarget[Metric] = TargetMetric
	        )
	    )

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Attainment %

````DAX
	DIVIDE(
	    [Production],
	    [Zone Target Per Hour]
	)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Heatmap Background

````DAX
VAR Attainment = [Attainment %]
RETURN
    SWITCH(
        TRUE(),
        ISBLANK(Attainment), "#D9E1E8",
        Attainment < 0.50,    "#EB5757",
        Attainment < 0.75,    "#F2994A",
        Attainment < 0.95,    "#F2C94C",
        Attainment < 1.05,    "#27AE60",
                              "#2F80ED"
    )
````

#### Heatmap Font

````DAX
VAR Attainment = [Attainment %]
RETURN
    IF(
        ISBLANK(Attainment),
        "#5E6C84",
        IF(
            Attainment < 0.50 || Attainment >= 0.95,
            "#FFFFFF",
            "#172B4D"
        )
    )
````

#### Heatmap Value

````DAX
	IF(
	    ISBLANK([Attainment %]),
	    BLANK(),
	    [Attainment %]
	)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Invalid Increment Records

````DAX
COUNTROWS(
    FILTER(
        FactRecent,
        FactRecent[Increment] < 0
            || FactRecent[Increment] > 50000
    )
)
````

#### Record Count

````DAX
COUNTROWS(FactRecent)
````

#### Max Increment

````DAX
	MAX(FactRecent[Increment])

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Historian Latest Recent Time

````DAX
CALCULATE(
    Max(FactRecent[SampleTime]),
    Removefilters(DimLine),
    REMOVEFILTERS(DimZone)
)
````

#### Rolling 60-Minute Production

````DAX
	VAR EndTime = [Historian Latest Recent Time]
	VAR StartTime = EndTime - TIME(1,0,0)
	RETURN
	    CALCULATE(
	        SUM(FactRecent[Increment]),
	        FactRecent[SampleTime] > StartTime,
	        FactRecent[SampleTime] <= EndTime,
	        FactRecent[Increment] >= 0,
	        FactRecent[Increment] <= 50000
	    )

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Last Zone Production TIme

````DAX
VAR EndTime = [Historian Latest Recent Time]
RETURN
    CALCULATE(
        MAX(FactRecent[SampleTime]),
        FactRecent[Increment] >0,
        FactRecent[Increment] <=50000,
        FactRecent[SampleTime] <= EndTime
    )
````

#### Minutes Since Zone Production

````DAX
VAR EndTime = [Historian Latest Recent Time]
VAR LastProduction = [Last Zone Production TIme]
RETURN
    IF(
        ISBLANK(LastProduction),
        BLANK(),
        DATEDIFF(LastProduction, EndTime, MINUTE)
    )
````

#### Zone Down 15 Minutes

````DAX
VAR MinutesStopped = [Minutes Since Zone Production]
RETURN
    IF(
        NOT ISBLANK(MinutesStopped)
        && MinutesStopped >= 15,
        1,
        0
    )
````

#### Rolling Zone Attainment %

````DAX
	DIVIDE(
	    [Rolling 60-Minute Production],
	    [Zone Target Rate]
	)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Zone Operating Status

````DAX
VAR MinutesStopped = [Minutes Since Zone Production]
VAR Attainment = [Rolling Zone Attainment %]
RETURN
    SWITCH(
        TRUE(),
        ISBLANK([Historian Latest Recent Time]), "NO HISTORIAN DATA",
        ISBLANK(MinutesStopped), "NO PRODUCTION DATA",
        MinutesStopped >=15, "DOWN 15+ MIN",
        MinutesStopped >=10, "NO OUTPUT 10+ MIN",
        Attainment >= 0.95, "RUNNING",
        Attainment >= 0.75, "UNDER TARGET",
        Attainment >= 0.50, "LOW OUTPUT",
        "CRITICAL OUTPUT"
    )
````

#### Operational Heatmap Color

````DAX
```

			VAR MinutesStopped = [Minutes Since Zone Production]
			VAR Attainment = [Rolling Zone Attainment %]
			RETURN
			    SWITCH(
			        TRUE(),
			        ISBLANK([Historian Latest Recent Time]), "#7F8C8D",
			        ISBLANK(MinutesStopped),                 "#BDBDBD",

			        -- Downtime overrides throughput
			        MinutesStopped >= 15,                   "#8B0000",
			        MinutesStopped >= 10,                   "#EB5757",

			        -- Zone is moving; evaluate performance
			        ISBLANK(Attainment),                    "#D9E1E8",
			        Attainment < 0.50,                      "#EB5757",
			        Attainment < 0.75,                      "#F2994A",
			        Attainment < 0.95,                      "#F2C94C",
			        Attainment < 1.05,                      "#27AE60",
			                                                "#2F80ED"
			    )

			```
````

#### Operational Heatmap Font Color

````DAX
```

			VAR MinutesStopped = [Minutes Since Zone Production]
			VAR Attainment = [Rolling Zone Attainment %]
			RETURN
			    IF(
			        MinutesStopped >= 15
			            || Attainment < 0.50
			            || Attainment >= 0.95,
			        "#FFFFFF",
			        "#172B4D"
			    )

			```
````

#### Python Hourly Production

````DAX
CALCULATE(
    SUM(FactRecent[Increment]),
    FactRecent[Increment] >= 0,
    FactRecent[Increment] <= 50000
)
````

#### Python Zone Target Per Hour

````DAX
VAR SelectedLine =
    COALESCE(
        SELECTEDVALUE(FactRecent[Line]),
        SELECTEDVALUE(DimLine[Line])
    )
VAR SelectedZone =
    COALESCE(
        SELECTEDVALUE(FactRecent[ZoneKey]),
        SELECTEDVALUE(DimZone[ZoneKey])
    )
VAR TargetMetric =
    SWITCH(
        SelectedZone,
        "Z3_IN", "Z3_OUT",
        "Z4_IN", "Z4_OUT",
        "ALI_IN", "ALI_OUT",
        SelectedZone
    )
RETURN
    CALCULATE(
        MAX(DimTarget[TargetValue]),
        FILTER(
            ALL(DimTarget),
            DimTarget[Line] = SelectedLine
                && DimTarget[Metric] = TargetMetric
        )
    )
````

#### Python Historian Latest Time

````DAX
CALCULATE(
    MAX(FactRecent[SampleTime]),
    REMOVEFILTERS(FactRecent[HourStart]),
    REMOVEFILTERS(FactRecent[ShiftStart]),
    REMOVEFILTERS(FactRecent[SampleTime]),
    REMOVEFILTERS(FactRecent[ZoneKey]),
    REMOVEFILTERS(DimZone)
)
````

#### Python Last Zone Production Time

````DAX
VAR EndTime = [Python Historian Latest Time]
RETURN
    CALCULATE(
        MAX(FactRecent[SampleTime]),
        REMOVEFILTERS(FactRecent[HourStart]),
        REMOVEFILTERS(FactRecent[ShiftStart]),
        REMOVEFILTERS(FactRecent[SampleTime]),
        FactRecent[Increment] > 0,
        FactRecent[Increment] <= 50000,
        FactRecent[SampleTime] <= EndTime
    )
````

#### Python Minutes Since Production

````DAX
VAR EndTime = [Python Historian Latest Time]
VAR LastProduction = [Python Last Zone Production Time]
RETURN
    IF(
        ISBLANK(EndTime) || ISBLANK(LastProduction),
        BLANK(),
        DATEDIFF(LastProduction, EndTime, MINUTE)
    )
````

#### Python Current Shift Start

````DAX
CALCULATE(
    MAX(FactRecent[ShiftStart]),
    REMOVEFILTERS(FactRecent[HourStart]),
    REMOVEFILTERS(FactRecent[SampleTime]),
    REMOVEFILTERS(FactRecent[ZoneKey]),
    REMOVEFILTERS(DimZone)
)
````

#### Python Loader Shift Output

````DAX
VAR ShiftStart = [Python Current Shift Start]
VAR EndTime = [Python Historian Latest Time]
RETURN
    CALCULATE(
        SUM(FactRecent[Increment]),
        REMOVEFILTERS(FactRecent[HourStart]),
        REMOVEFILTERS(FactRecent[ShiftStart]),
        REMOVEFILTERS(FactRecent[SampleTime]),
        REMOVEFILTERS(FactRecent[ZoneKey]),
        REMOVEFILTERS(DimZone),
        FactRecent[ZoneKey] = "Z6_IN",
        FactRecent[SampleTime] >= ShiftStart,
        FactRecent[SampleTime] <= EndTime,
        FactRecent[Increment] >= 0,
        FactRecent[Increment] <= 50000
    )
````

#### Python Shift Goal

````DAX
VAR SelectedLine =
    COALESCE(
        SELECTEDVALUE(FactRecent[Line]),
        SELECTEDVALUE(DimLine[Line])
    )
RETURN
    CALCULATE(
        MAX(DimTarget[TargetValue]),
        FILTER(
            ALL(DimTarget),
            DimTarget[Line] = SelectedLine
                && DimTarget[Metric] = "SHIFT_GOAL"
        )
    )
````

#### Python Projected Shift Total

````DAX
VAR ShiftStart = [Python Current Shift Start]
VAR EndTime = [Python Historian Latest Time]
VAR ElapsedHours =
    MAX(1.0 / 60.0, DIVIDE(DATEDIFF(ShiftStart, EndTime, MINUTE), 60.0))
RETURN
    DIVIDE([Python Loader Shift Output], ElapsedHours) * 12.0
````

## DimTag

### Calculated columns

#### Zone Sort

````DAX
```
````

## DimTarget

### Measures

#### Required Rate Per Hour

````DAX
DIVIDE([Shift Goal], 12.0)

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Projected Shift Total

````DAX
[Current Rate Per Hour] * 12.0

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Projected Attainment %

````DAX
```
			DIVIDE([Projected Shift Total], [Shift Goal])

			```

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Shift Gap

````DAX
[Projected Shift Total] - [Shift Goal]

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Last 3 Hours Output

````DAX
	VAR EndT = NOW()
	RETURN CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey] = "Z6_IN", FactRecent[SampleTime] > EndT - 3/24, FactRecent[SampleTime] <= EndT)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Prior 3 Hours Output

````DAX
	VAR EndT = NOW()
	RETURN CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey] = "Z6_IN", FactRecent[SampleTime] > EndT - 6/24, FactRecent[SampleTime] <= EndT - 3/24)

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Trend Change %

````DAX
DIVIDE([Last 3 Hours Output] - [Prior 3 Hours Output], [Prior 3 Hours Output])

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Trend Direction

````DAX
SWITCH(TRUE(), ISBLANK([Trend Change %]), "No data", [Trend Change %] >= 0.05, "Improving", [Trend Change %] <= -0.05, "Declining", "Stable")
````

#### Current Rate Attainment %

````DAX
DIVIDE([Current Rate Per Hour], [Required Rate Per Hour])

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Action

````DAX
VAR TrendState = [Trend Direction]
VAR RateAttainment = [Current Rate Attainment %]
VAR ProjectedAttainment = [Projected Attainment %]
RETURN SWITCH(TRUE(),
    ISBLANK(RateAttainment), "NO DATA",
    TrendState = "Declining" && (RateAttainment < 0.95 || ProjectedAttainment < 0.95), "INTERVENE",
    TrendState = "Declining", "INVESTIGATE",
    TrendState = "Improving" && RateAttainment < 0.98, "RECOVERING",
    (TrendState = "Improving" || TrendState = "Stable") && RateAttainment >= 0.98 && ProjectedAttainment < 0.95, "STABILIZE",
    TrendState = "Stable" && RateAttainment < 0.95, "INVESTIGATE",
    "HEALTHY")
````

#### Latest Sample Time

````DAX
MAX(FactLive[SampleTime])
````

#### Sample Age Minutes

````DAX
MAX(FactLive[SampleAgeMinutes])

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Data Status

````DAX
SWITCH(TRUE(), ISBLANK([Latest Sample Time]), "UNAVAILABLE", [Sample Age Minutes] > 5, "STALE", "CONNECTED")
````

#### Downtime Minutes

````DAX
SUM(FactDowntime[DowntimeMinutes])
````

#### CMMS Validation Status

````DAX
IF(MAX(FactDowntime[CmmsValidated]) = TRUE(), "CMMS validated", "Historian estimate")
````

#### Completed Shift Production

````DAX
SUM(FactShiftHistory[Production])

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### 5 Shift Average

````DAX
	VAR CurrentShift = MAX(FactShiftHistory[ShiftStart])
	VAR WindowShifts =
	    CALCULATETABLE(
	        TOPN(
	            5,
	            FILTER(
	                VALUES(FactShiftHistory[ShiftStart]),
	                FactShiftHistory[ShiftStart] <= CurrentShift
	            ),
	            FactShiftHistory[ShiftStart], DESC
	        ),
	        REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	        REMOVEFILTERS(FactShiftHistory[ShiftEnd])
	    )
	RETURN
	    AVERAGEX(
	        WindowShifts,
	        VAR WindowStart = FactShiftHistory[ShiftStart]
	        RETURN
	            CALCULATE(
	                [Completed Shift Production],
	                REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	                REMOVEFILTERS(FactShiftHistory[ShiftEnd]),
	                FactShiftHistory[ShiftStart] = WindowStart
	            )
	    )

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### 14 Shift Average

````DAX
	VAR CurrentShift = MAX(FactShiftHistory[ShiftStart])
	VAR WindowShifts =
	    CALCULATETABLE(
	        TOPN(
	            14,
	            FILTER(
	                VALUES(FactShiftHistory[ShiftStart]),
	                FactShiftHistory[ShiftStart] <= CurrentShift
	            ),
	            FactShiftHistory[ShiftStart], DESC
	        ),
	        REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	        REMOVEFILTERS(FactShiftHistory[ShiftEnd])
	    )
	RETURN
	    AVERAGEX(
	        WindowShifts,
	        VAR WindowStart = FactShiftHistory[ShiftStart]
	        RETURN
	            CALCULATE(
	                [Completed Shift Production],
	                REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	                REMOVEFILTERS(FactShiftHistory[ShiftEnd]),
	                FactShiftHistory[ShiftStart] = WindowStart
	            )
	    )

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### 20 Shift Average

````DAX
	VAR CurrentShift = MAX(FactShiftHistory[ShiftStart])
	VAR WindowShifts =
	    CALCULATETABLE(
	        TOPN(
	            20,
	            FILTER(
	                VALUES(FactShiftHistory[ShiftStart]),
	                FactShiftHistory[ShiftStart] <= CurrentShift
	            ),
	            FactShiftHistory[ShiftStart], DESC
	        ),
	        REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	        REMOVEFILTERS(FactShiftHistory[ShiftEnd])
	    )
	RETURN
	    AVERAGEX(
	        WindowShifts,
	        VAR WindowStart = FactShiftHistory[ShiftStart]
	        RETURN
	            CALCULATE(
	                [Completed Shift Production],
	                REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	                REMOVEFILTERS(FactShiftHistory[ShiftEnd]),
	                FactShiftHistory[ShiftStart] = WindowStart
	            )
	    )

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### 30 Day Average

````DAX
	VAR CurrentShift = MAX(FactShiftHistory[ShiftStart])
	VAR WindowShifts =
	    CALCULATETABLE(
	        FILTER(
	            VALUES(FactShiftHistory[ShiftStart]),
	            FactShiftHistory[ShiftStart] <= CurrentShift
	                && FactShiftHistory[ShiftStart] > CurrentShift - 30
	        ),
	        REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	        REMOVEFILTERS(FactShiftHistory[ShiftEnd])
	    )
	RETURN
	    AVERAGEX(
	        WindowShifts,
	        VAR WindowStart = FactShiftHistory[ShiftStart]
	        RETURN
	            CALCULATE(
	                [Completed Shift Production],
	                REMOVEFILTERS(FactShiftHistory[ShiftStart]),
	                REMOVEFILTERS(FactShiftHistory[ShiftEnd]),
	                FactShiftHistory[ShiftStart] = WindowStart
	            )
	    )

annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Z2A Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z2A"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z1"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Z3 Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z3_OUT"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z3_IN"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Z4 Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z4_OUT"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z3_OUT"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Z5 Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z5_IN"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z4_OUT"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### ALI Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="ALI_OUT"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="ALI_IN"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Z6 Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z6_IN"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="ALI_OUT"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

#### Line Yield %

````DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z6_IN"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z1"))

		annotation PBI_FormatHint = {"isGeneralNumber":true}
````

## DimZone

### Calculated table

#### DimZone

````DAX
DATATABLE(
	"ZoneKey", STRING,
	"Zone", STRING,
	"ZoneOrder", INTEGER,
	{
		{"Z1",	"Zone 1", 1},
		{"Z2A",	"Zone 2A", 2},
		{"Z3_OUT","Zone 3", 3},
		{"Z4_OUT","Zone 4", 4},
		{"Z5_IN","Zone 5", 5},
		{"ALI_OUT","ALI", 6},
		{"Z6_IN","Zone 6", 7}
	}
)
````

## LocalDateTable_1a4a5ce2-24d2-44ff-b53d-4e02af7a216d

### Calculated table

#### LocalDateTable_1a4a5ce2-24d2-44ff-b53d-4e02af7a216d

````DAX
Calendar(Date(Year(MIN('FactLive'[SampleTime])), 1, 1), Date(Year(MAX('FactLive'[SampleTime])), 12, 31))
````

### Calculated columns

#### Year

````DAX
YEAR([Date])
````

#### MonthNo

````DAX
MONTH([Date])
````

#### Month

````DAX
FORMAT([Date], "MMMM")
````

#### QuarterNo

````DAX
INT(([MonthNo] + 2) / 3)
````

#### Quarter

````DAX
"Qtr " & [QuarterNo]
````

#### Day

````DAX
DAY([Date])
````

## LocalDateTable_22fda71b-0787-40a4-aba7-7bcaafaacb99

### Calculated table

#### LocalDateTable_22fda71b-0787-40a4-aba7-7bcaafaacb99

````DAX
Calendar(Date(Year(MIN('FactShiftHistory'[ShiftStart])), 1, 1), Date(Year(MAX('FactShiftHistory'[ShiftStart])), 12, 31))
````

### Calculated columns

#### Year

````DAX
YEAR([Date])
````

#### MonthNo

````DAX
MONTH([Date])
````

#### Month

````DAX
FORMAT([Date], "MMMM")
````

#### QuarterNo

````DAX
INT(([MonthNo] + 2) / 3)
````

#### Quarter

````DAX
"Qtr " & [QuarterNo]
````

#### Day

````DAX
DAY([Date])
````

## LocalDateTable_79c8466e-0551-423b-8913-a2aefbef9647

### Calculated table

#### LocalDateTable_79c8466e-0551-423b-8913-a2aefbef9647

````DAX
Calendar(Date(Year(MIN('FactShiftHistory'[ShiftEnd])), 1, 1), Date(Year(MAX('FactShiftHistory'[ShiftEnd])), 12, 31))
````

### Calculated columns

#### Year

````DAX
YEAR([Date])
````

#### MonthNo

````DAX
MONTH([Date])
````

#### Month

````DAX
FORMAT([Date], "MMMM")
````

#### QuarterNo

````DAX
INT(([MonthNo] + 2) / 3)
````

#### Quarter

````DAX
"Qtr " & [QuarterNo]
````

#### Day

````DAX
DAY([Date])
````

## LocalDateTable_7ac1bb44-30ea-4cc6-a8ca-ea9141630658

### Calculated table

#### LocalDateTable_7ac1bb44-30ea-4cc6-a8ca-ea9141630658

````DAX
Calendar(Date(Year(MIN('Query1'[ShiftEnd])), 1, 1), Date(Year(MAX('Query1'[ShiftEnd])), 12, 31))
````

### Calculated columns

#### Year

````DAX
YEAR([Date])
````

#### MonthNo

````DAX
MONTH([Date])
````

#### Month

````DAX
FORMAT([Date], "MMMM")
````

#### QuarterNo

````DAX
INT(([MonthNo] + 2) / 3)
````

#### Quarter

````DAX
"Qtr " & [QuarterNo]
````

#### Day

````DAX
DAY([Date])
````

## LocalDateTable_addef9ea-a10f-4401-a1cd-2ea753d47aec

### Calculated table

#### LocalDateTable_addef9ea-a10f-4401-a1cd-2ea753d47aec

````DAX
Calendar(Date(Year(MIN('Query1'[ShiftStart])), 1, 1), Date(Year(MAX('Query1'[ShiftStart])), 12, 31))
````

### Calculated columns

#### Year

````DAX
YEAR([Date])
````

#### MonthNo

````DAX
MONTH([Date])
````

#### Month

````DAX
FORMAT([Date], "MMMM")
````

#### QuarterNo

````DAX
INT(([MonthNo] + 2) / 3)
````

#### Quarter

````DAX
"Qtr " & [QuarterNo]
````

#### Day

````DAX
DAY([Date])
````
