# Python Heatmap Setup

The **Python Heatmap** report page is already configured. It renders the current 12-hour shift by line, zone, and hour. Each cell displays production and attainment against the configured hourly zone target. The current hour is prorated to the historian timestamp.

The current-hour cell turns dark red when its zone has recorded no production increment for at least 15 minutes. This alert uses the latest historian sample time, so it does not depend on the computer clock.

## One-time workstation setup

1. Install 64-bit Python if it is not already installed.
2. Open PowerShell and install the required packages:

   ```powershell
   py -m pip install pandas numpy matplotlib
   ```

3. In Power BI Desktop, open **File > Options and settings > Options > Python scripting**.
4. Select the Python installation where those packages were installed.
5. Open the PBIP project and allow Python script visuals when Power BI prompts.
6. Refresh the model and open the **Python Heatmap** page.
7. Select one line from the dropdown at the top-left of the page.

## Heatmap status colors

| Color | Meaning |
| --- | --- |
| Dark red | Current zone has not incremented for 15 minutes or more |
| Red | Below 50% of target |
| Orange | 50% through 74% of target |
| Yellow | 75% through 94% of target |
| Green | 95% through 104% of target |
| Blue | 105% or more of target |
| Gray | No data or no configured target |

## Source and maintenance

The editable Python source is in `PythonVisuals/operational_heatmap.py`. The same source is embedded in the report visual so the report can run without referring to an external script file.

The Shift History page also contains repaired rolling calculations. The 5-, 14-, and 20-shift averages end at the shift displayed on each row. The 30-day average uses the 30 calendar days ending at that row. The model now uses the direct `FactShiftHistory[Line]` to `DimLine[Line]` relationship, allowing Shift Goal to filter correctly.
