# DAX Reference — Manufacturing Operations Intelligence

This file was generated from the semantic model's TMDL definitions. Each heading below is one separate Power BI object; copy only the expression inside its DAX block when recreating an object.

- Measures: **55**
- Calculated columns: **37**
- Calculated tables: **7**

> The `LocalDateTable_*` and `DateTableTemplate_*` objects are hidden, automatically generated Power BI date tables. They are included because this README inventories all DAX in the model, but they normally should not be recreated manually.

## Contents

- [DateTableTemplate_40cd893d-74de-4d18-9292-19409435ec21](#datetabletemplate40cd893d-74de-4d18-9292-19409435ec21)
- [DimLine](#dimline)
- [DimTag](#dimtag)
- [DimTarget](#dimtarget)
- [DimZone](#dimzone)
- [LocalDateTable_1a4a5ce2-24d2-44ff-b53d-4e02af7a216d](#localdatetable1a4a5ce2-24d2-44ff-b53d-4e02af7a216d)
- [LocalDateTable_22fda71b-0787-40a4-aba7-7bcaafaacb99](#localdatetable22fda71b-0787-40a4-aba7-7bcaafaacb99)
- [LocalDateTable_79c8466e-0551-423b-8913-a2aefbef9647](#localdatetable79c8466e-0551-423b-8913-a2aefbef9647)
- [LocalDateTable_7ac1bb44-30ea-4cc6-a8ca-ea9141630658](#localdatetable7ac1bb44-30ea-4cc6-a8ca-ea9141630658)
- [LocalDateTable_addef9ea-a10f-4401-a1cd-2ea753d47aec](#localdatetableaddef9ea-a10f-4401-a1cd-2ea753d47aec)

## DateTableTemplate_40cd893d-74de-4d18-9292-19409435ec21

### Calculated table

#### DateTableTemplate_40cd893d-74de-4d18-9292-19409435ec21

```DAX
Calendar(Date(2015,1,1), Date(2015,1,1))
```

### Calculated columns

#### Year

```DAX
YEAR([Date])
```

#### MonthNo

```DAX
MONTH([Date])
```

#### Month

```DAX
FORMAT([Date], "MMMM")
```

#### QuarterNo

```DAX
INT(([MonthNo] + 2) / 3)
```

#### Quarter

```DAX
"Qtr " & [QuarterNo]
```

#### Day

```DAX
DAY([Date])
```


## DimLine

### Measures

#### Current Shift Start

```DAX
VAR N = NOW()
VAR D = DATE(YEAR(N), MONTH(N), DAY(N))
RETURN SWITCH(TRUE(), HOUR(N) < 6, D - TIME(6,0,0), HOUR(N) < 18, D + TIME(6,0,0), D + TIME(18,0,0))
```

#### Current Shift Production

```DAX
VAR S = [Current Shift Start]
RETURN CALCULATE(SUM(FactRecent[Increment]), FactRecent[SampleTime] >= S, FactRecent[ZoneKey] = "Z6_IN")
```

#### Elapsed Shift Hours

```DAX
MAX(0.0167, DIVIDE(DATEDIFF([Current Shift Start], NOW(), MINUTE), 60.0))
```

#### Current Rate Per Hour

```DAX
DIVIDE([Current Shift Production], [Elapsed Shift Hours])
```

#### Shift Goal

```DAX
VAR L = SELECTEDVALUE(DimLine[Line])
RETURN CALCULATE(MAX(DimTarget[TargetValue]), DimTarget[Line] = L, DimTarget[Metric] = "SHIFT_GOAL")
```

#### Zone Current Shift Production

```DAX
VAR ShiftStart = [Current Shift Start]
RETURN
    CALCULATE(
            SUM(FactRecent[Increment]),
            FactRecent[SampleTime]>= ShiftStart,
            FactRecent[SampleTime]<= NOW())
```

#### Zone Current Rate Per Hour

```DAX
DIVIDE(
        [Zone Current Shift Production],
        [Elapsed Shift Hours]
)
```

#### Zone Target Rate

```DAX
VAR SelectedLine = 
    SELECTEDVALUE(DimLine[Line])
VAR SelectedZone = 
    SELECTEDVALUE(DimZone[ZoneKey])
RETURN
    CALCULATE(
            MAX(DimTarget[TargetValue]),
            FILTER(
                All(DimTarget),
                DimTarget[Line] = SelectedLine
                    && DimTarget[Metric] = SelectedZone
            )
    )
```

#### Zone Rate Attainment

```DAX
DIVIDE(
    [Zone Current Rate Per Hour],
    [Zone Target Rate]
)
```

#### Zone Heatmap Color

```DAX
VAR Attainment = [Zone Rate Attainment]
VAR DataState = [Data Status]
RETURN
    SWITCH(
        True(),
        DataState = "UNAVAILABLE", "#BDBDBD",
        DataState = "STALE", "#828282",
        ISBLANK(Attainment), "#E0E0E0",
        Attainment >= 0.98, "#27AE60",
        Attainment >= 0.90, "#F2C94C",
        Attainment >= 0.70, "#F2994A",
                            "#EB5757"
    )
```

#### Production

```DAX
SUMX(
    FactRecent,
    VAR Inc = FactRecent[Increment]
    RETURN
        IF(
            ISBLANK(Inc)
                || Inc < 0
                || Inc > 50000,
            BLANK(),
            Inc
        )
)
```

#### Zone Target Per Hour

```DAX
VAR SelectedLine =
    SELECTEDVALUE(DimLine[Line])
VAR SelectedZone =
    SELECTEDVALUE(DimTag[ZoneKey])
VAR TargetMetric =
    SWITCH(
        SelectedZone,
        "Z3_IN", "Z3_OUT",
        "Z4_IN", "Z4_OUT",
        "ALI_IN", "ALI_OUT",
        SelectedZone
    )
RETURN
    CALCULATE(
        MAX(DimTarget[TargetValue]),
        FILTER(
            ALL(DimTarget),
            DimTarget[Line] = SelectedLine
                && DimTarget[Metric] = TargetMetric
        )
    )
```

#### Attainment %

```DAX
DIVIDE(
    [Production],
    [Zone Target Per Hour]
)
```

#### Heatmap Background

```DAX
VAR Attainment = [Attainment %]
RETURN
    SWITCH(
        TRUE(),
        ISBLANK(Attainment), "#D9E1E8",
        Attainment < 0.50,    "#EB5757",
        Attainment < 0.75,    "#F2994A",
        Attainment < 0.95,    "#F2C94C",
        Attainment < 1.05,    "#27AE60",
                              "#2F80ED"
    )
```

#### Heatmap Font

```DAX
VAR Attainment = [Attainment %]
RETURN
    IF(
        ISBLANK(Attainment),
        "#5E6C84",
        IF(
            Attainment < 0.50 || Attainment >= 0.95,
            "#FFFFFF",
            "#172B4D"
        )
    )
```

#### Heatmap Value

```DAX
IF(
    ISBLANK([Attainment %]),
    BLANK(),
    [Attainment %]
)
```

#### Invalid Increment Records

```DAX
COUNTROWS(
    FILTER(
        FactRecent,
        FactRecent[Increment] < 0
            || FactRecent[Increment] > 50000
    )
)
```

#### Record Count

```DAX
COUNTROWS(FactRecent)
```

#### Max Increment

```DAX
MAX(FactRecent[Increment])
```

#### Historian Latest Recent Time

```DAX
CALCULATE(
    Max(FactRecent[SampleTime]),
    Removefilters(DimLine),
    REMOVEFILTERS(DimZone)
)
```

#### Rolling 60-Minute Production

```DAX
VAR EndTime = [Historian Latest Recent Time]
VAR StartTime = EndTime - TIME(1,0,0)
RETURN
    CALCULATE(
        SUM(FactRecent[Increment]),
        FactRecent[SampleTime] > StartTime,
        FactRecent[SampleTime] <= EndTime,
        FactRecent[Increment] >= 0,
        FactRecent[Increment] <= 50000
    )
```

#### Last Zone Production TIme

```DAX
VAR EndTime = [Historian Latest Recent Time]
RETURN
    CALCULATE(
        MAX(FactRecent[SampleTime]),
        FactRecent[Increment] >0,
        FactRecent[Increment] <=50000,
        FactRecent[SampleTime] <= EndTime
    )
```

#### Minutes Since Zone Production

```DAX
VAR EndTime = [Historian Latest Recent Time]
VAR LastProduction = [Last Zone Production TIme]
RETURN
    IF(
        ISBLANK(LastProduction),
        BLANK(),
        DATEDIFF(LastProduction, EndTime, MINUTE)
    )
```

#### Zone Down 15 Minutes

```DAX
VAR MinutesStopped = [Minutes Since Zone Production]
RETURN
    IF(
        NOT ISBLANK(MinutesStopped)
        && MinutesStopped >= 15,
        1,
        0
    )
```

#### Rolling Zone Attainment %

```DAX
DIVIDE(
    [Rolling 60-Minute Production],
    [Zone Target Rate]
)
```

#### Zone Operating Status

```DAX
VAR MinutesStopped = [Minutes Since Zone Production]
VAR Attainment = [Rolling Zone Attainment %]
RETURN
    SWITCH(
        TRUE(),
        ISBLANK([Historian Latest Recent Time]), "NO HISTORIAN DATA",
        ISBLANK(MinutesStopped), "NO PRODUCTION DATA",
        MinutesStopped >=15, "DOWN 15+ MIN",
        MinutesStopped >=10, "NO OUTPUT 10+ MIN",
        Attainment >= 0.95, "RUNNING",
        Attainment >= 0.75, "UNDER TARGET",
        Attainment >= 0.50, "LOW OUTPUT",
        "CRITICAL OUTPUT"
    )
```

#### Operational Heatmap Color

```DAX
VAR MinutesStopped = [Minutes Since Zone Production]
VAR Attainment = [Rolling Zone Attainment %]
RETURN
    SWITCH(
        TRUE(),
        ISBLANK([Historian Latest Recent Time]), "#7F8C8D",
        ISBLANK(MinutesStopped),                 "#BDBDBD",

        -- Downtime overrides throughput
        MinutesStopped >= 15,                   "#8B0000",
        MinutesStopped >= 10,                   "#EB5757",

        -- Zone is moving; evaluate performance
        ISBLANK(Attainment),                    "#D9E1E8",
        Attainment < 0.50,                      "#EB5757",
        Attainment < 0.75,                      "#F2994A",
        Attainment < 0.95,                      "#F2C94C",
        Attainment < 1.05,                      "#27AE60",
                                                "#2F80ED"
    )
```

#### Operational Heatmap Font Color

```DAX
VAR MinutesStopped = [Minutes Since Zone Production]
VAR Attainment = [Rolling Zone Attainment %]
RETURN
    IF(
        MinutesStopped >= 15
            || Attainment < 0.50
            || Attainment >= 0.95,
        "#FFFFFF",
        "#172B4D"
    )
```


## DimTag

### Calculated columns

#### Zone Sort

```DAX
SWITCH(
    DimTag[ZoneKey],
    "Z1", 10,
    "Z2A", 20,
    "Z3_IN", 30,
    "Z3_OUT", 40,
    "Z4_IN", 50,
    "Z4_OUT", 60,
    "Z5_IN", 70,
    "ALI_IN", 80,
    "ALI_OUT", 90,
    "Z6_IN", 100,
    999
)
```


## DimTarget

### Measures

#### Required Rate Per Hour

```DAX
DIVIDE([Shift Goal], 12.0)
```

#### Projected Shift Total

```DAX
[Current Rate Per Hour] * 12.0
```

#### Projected Attainment %

```DAX
DIVIDE([Projected Shift Total], [Shift Goal])
```

#### Shift Gap

```DAX
[Projected Shift Total] - [Shift Goal]
```

#### Last 3 Hours Output

```DAX
VAR EndT = NOW()
RETURN CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey] = "Z6_IN", FactRecent[SampleTime] > EndT - 3/24, FactRecent[SampleTime] <= EndT)
```

#### Prior 3 Hours Output

```DAX
VAR EndT = NOW()
RETURN CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey] = "Z6_IN", FactRecent[SampleTime] > EndT - 6/24, FactRecent[SampleTime] <= EndT - 3/24)
```

#### Trend Change %

```DAX
DIVIDE([Last 3 Hours Output] - [Prior 3 Hours Output], [Prior 3 Hours Output])
```

#### Trend Direction

```DAX
SWITCH(TRUE(), ISBLANK([Trend Change %]), "No data", [Trend Change %] >= 0.05, "Improving", [Trend Change %] <= -0.05, "Declining", "Stable")
```

#### Current Rate Attainment %

```DAX
DIVIDE([Current Rate Per Hour], [Required Rate Per Hour])
```

#### Action

```DAX
VAR TrendState = [Trend Direction]
VAR RateAttainment = [Current Rate Attainment %]
VAR ProjectedAttainment = [Projected Attainment %]
RETURN SWITCH(TRUE(),
    ISBLANK(RateAttainment), "NO DATA",
    TrendState = "Declining" && (RateAttainment < 0.95 || ProjectedAttainment < 0.95), "INTERVENE",
    TrendState = "Declining", "INVESTIGATE",
    TrendState = "Improving" && RateAttainment < 0.98, "RECOVERING",
    (TrendState = "Improving" || TrendState = "Stable") && RateAttainment >= 0.98 && ProjectedAttainment < 0.95, "STABILIZE",
    TrendState = "Stable" && RateAttainment < 0.95, "INVESTIGATE",
    "HEALTHY")
```

#### Latest Sample Time

```DAX
MAX(FactLive[SampleTime])
```

#### Sample Age Minutes

```DAX
MAX(FactLive[SampleAgeMinutes])
```

#### Data Status

```DAX
SWITCH(TRUE(), ISBLANK([Latest Sample Time]), "UNAVAILABLE", [Sample Age Minutes] > 5, "STALE", "CONNECTED")
```

#### Downtime Minutes

```DAX
SUM(FactDowntime[DowntimeMinutes])
```

#### CMMS Validation Status

```DAX
IF(MAX(FactDowntime[CmmsValidated]) = TRUE(), "CMMS validated", "Historian estimate")
```

#### Completed Shift Production

```DAX
SUM(FactShiftHistory[Production])
```

#### 5 Shift Average

```DAX
AVERAGEX(TOPN(5, VALUES(FactShiftHistory[ShiftStart]), FactShiftHistory[ShiftStart], DESC), [Completed Shift Production])
```

#### 14 Shift Average

```DAX
AVERAGEX(TOPN(14, VALUES(FactShiftHistory[ShiftStart]), FactShiftHistory[ShiftStart], DESC), [Completed Shift Production])
```

#### 20 Shift Average

```DAX
AVERAGEX(TOPN(20, VALUES(FactShiftHistory[ShiftStart]), FactShiftHistory[ShiftStart], DESC), [Completed Shift Production])
```

#### 30 Day Average

```DAX
AVERAGEX(TOPN(60, VALUES(FactShiftHistory[ShiftStart]), FactShiftHistory[ShiftStart], DESC), [Completed Shift Production])
```

#### Z2A Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z2A"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z1"))
```

#### Z3 Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z3_OUT"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z3_IN"))
```

#### Z4 Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z4_OUT"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z3_OUT"))
```

#### Z5 Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z5_IN"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z4_OUT"))
```

#### ALI Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="ALI_OUT"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="ALI_IN"))
```

#### Z6 Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z6_IN"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="ALI_OUT"))
```

#### Line Yield %

```DAX
DIVIDE(CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z6_IN"), CALCULATE(SUM(FactRecent[Increment]), FactRecent[ZoneKey]="Z1"))
```


## DimZone

### Calculated table

#### DimZone

```DAX
	DATATABLE(
		"ZoneKey", STRING,
		"Zone", STRING,
		"ZoneOrder", INTEGER,
		{
			{"Z1",	"Zone 1", 1},
			{"Z2A",	"Zone 2A", 2},
			{"Z3_OUT","Zone 3", 3},
			{"Z4_OUT","Zone 4", 4},
			{"Z5_IN","Zone 5", 5},
			{"ALI_OUT","ALI", 6},
			{"Z6_IN","Zone 6", 7}
		}
	)
```


## LocalDateTable_1a4a5ce2-24d2-44ff-b53d-4e02af7a216d

### Calculated table

#### LocalDateTable_1a4a5ce2-24d2-44ff-b53d-4e02af7a216d

```DAX
Calendar(Date(Year(MIN('FactLive'[SampleTime])), 1, 1), Date(Year(MAX('FactLive'[SampleTime])), 12, 31))
```

### Calculated columns

#### Year

```DAX
YEAR([Date])
```

#### MonthNo

```DAX
MONTH([Date])
```

#### Month

```DAX
FORMAT([Date], "MMMM")
```

#### QuarterNo

```DAX
INT(([MonthNo] + 2) / 3)
```

#### Quarter

```DAX
"Qtr " & [QuarterNo]
```

#### Day

```DAX
DAY([Date])
```


## LocalDateTable_22fda71b-0787-40a4-aba7-7bcaafaacb99

### Calculated table

#### LocalDateTable_22fda71b-0787-40a4-aba7-7bcaafaacb99

```DAX
Calendar(Date(Year(MIN('FactShiftHistory'[ShiftStart])), 1, 1), Date(Year(MAX('FactShiftHistory'[ShiftStart])), 12, 31))
```

### Calculated columns

#### Year

```DAX
YEAR([Date])
```

#### MonthNo

```DAX
MONTH([Date])
```

#### Month

```DAX
FORMAT([Date], "MMMM")
```

#### QuarterNo

```DAX
INT(([MonthNo] + 2) / 3)
```

#### Quarter

```DAX
"Qtr " & [QuarterNo]
```

#### Day

```DAX
DAY([Date])
```


## LocalDateTable_79c8466e-0551-423b-8913-a2aefbef9647

### Calculated table

#### LocalDateTable_79c8466e-0551-423b-8913-a2aefbef9647

```DAX
Calendar(Date(Year(MIN('FactShiftHistory'[ShiftEnd])), 1, 1), Date(Year(MAX('FactShiftHistory'[ShiftEnd])), 12, 31))
```

### Calculated columns

#### Year

```DAX
YEAR([Date])
```

#### MonthNo

```DAX
MONTH([Date])
```

#### Month

```DAX
FORMAT([Date], "MMMM")
```

#### QuarterNo

```DAX
INT(([MonthNo] + 2) / 3)
```

#### Quarter

```DAX
"Qtr " & [QuarterNo]
```

#### Day

```DAX
DAY([Date])
```


## LocalDateTable_7ac1bb44-30ea-4cc6-a8ca-ea9141630658

### Calculated table

#### LocalDateTable_7ac1bb44-30ea-4cc6-a8ca-ea9141630658

```DAX
Calendar(Date(Year(MIN('Query1'[ShiftEnd])), 1, 1), Date(Year(MAX('Query1'[ShiftEnd])), 12, 31))
```

### Calculated columns

#### Year

```DAX
YEAR([Date])
```

#### MonthNo

```DAX
MONTH([Date])
```

#### Month

```DAX
FORMAT([Date], "MMMM")
```

#### QuarterNo

```DAX
INT(([MonthNo] + 2) / 3)
```

#### Quarter

```DAX
"Qtr " & [QuarterNo]
```

#### Day

```DAX
DAY([Date])
```


## LocalDateTable_addef9ea-a10f-4401-a1cd-2ea753d47aec

### Calculated table

#### LocalDateTable_addef9ea-a10f-4401-a1cd-2ea753d47aec

```DAX
Calendar(Date(Year(MIN('Query1'[ShiftStart])), 1, 1), Date(Year(MAX('Query1'[ShiftStart])), 12, 31))
```

### Calculated columns

#### Year

```DAX
YEAR([Date])
```

#### MonthNo

```DAX
MONTH([Date])
```

#### Month

```DAX
FORMAT([Date], "MMMM")
```

#### QuarterNo

```DAX
INT(([MonthNo] + 2) / 3)
```

#### Quarter

```DAX
"Qtr " & [QuarterNo]
```

#### Day

```DAX
DAY([Date])
```
