# Model Relationships

Create these one-to-many, single-direction relationships:

- `DimLine[Line]` 1 -> * `FactLive[Line]`
- `DimLine[Line]` 1 -> * `FactRecent[Line]`
- `DimLine[Line]` 1 -> * `FactShiftHistory[Line]`
- `DimLine[Line]` 1 -> * `FactDowntime[Line]`
- `DimLine[Line]` 1 -> * both alarm fact tables
- `DimTag[TagName]` 1 -> * `FactLive[TagName]`
- `DimTag[TagName]` 1 -> * `FactRecent[TagName]`
- `DimTarget[LineMetricKey]` 1 -> * only if you create a matching concatenated key; otherwise access targets through measures.

Do not create fact-to-fact relationships. Use `DimLine`, a Date table, a Shift table, and an optional Zone dimension as shared filters.
