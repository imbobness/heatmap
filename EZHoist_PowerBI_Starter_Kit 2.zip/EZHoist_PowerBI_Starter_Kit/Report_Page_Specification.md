# Report Page Specification

## 1. Operations Overview

- Cards: active lines, total current projection, fleet goal, projected attainment, historian status.
- Matrix: Line, last completed shift, current actual, projected total, goal, projected attainment, current rate, trend direction, action, gap.
- Conditional colors: healthy >=98%; watch 90-<98%; underperforming 70-<90%; critical <70%; gray for unavailable/stale.
- Slicers: shift, platform, in-production status.

## 2. Line Story

- Single-select Line slicer.
- Zone flow: Z1, Z2A, Z3, Z4, Z5, ALI, Z6.
- Per-zone cards: production, target, yield, no-increment minutes, alarm count, state.
- Tooltips: latest timestamp, data status, top alarm, last recovery.
- Do not display excluded physical zones 7-10 as output contributors.

## 3. Downtime

- Clustered bar chart: downtime minutes by line.
- Drill-down: line > zone > interval.
- Columns: start, end, minutes, shift, associated first alarm, classification, CMMS validation status.
- Banner: `Historian-derived no-increment estimate; CMMS is the validated downtime system.`

## 4. Alarm Analysis

- Alarm counts and duration by line, zone, classification, hour, and shift.
- Classifications: root-cause candidate, operator access, suppressed access consequence, downstream/cascade symptom, run alarm, warning, stop-alarm candidate.
- Exclude zones 7-10 and confirmed non-stopping events from downtime attribution while retaining them in an optional suppressed-events detail page.
- Do not interpret severity/priority alone as proof of downtime.

## 5. Shift History

- 60 completed shifts shown left-to-right.
- Goal line plus 5-, 14-, 20-shift and 30-day averages.
- Last green shift and top-10 completed shifts.
- Red/green shift coloring based on the line goal.

## 6. Management Review

- Tier 1: 2-4 consecutive red shifts.
- Tier 2: 5-7 consecutive red shifts.
- Tier 3: 8+ consecutive red shifts.
- Exit condition: 20-shift average at or above goal.

## 7. Data Quality

- Source status: CONNECTED, STALE (>5 minutes), UNAVAILABLE.
- Missing tags by line/zone.
- Rejected implausible deltas and counter resets.
- Lines excluded from fleet totals.
- Last successful query time and query duration.

## Read-only footer

Add to every page: `READ-ONLY VISUALIZATION — NO MACHINE CONTROL — NO SOURCE DATA MODIFICATION — NOT A SYSTEM OF RECORD`.
