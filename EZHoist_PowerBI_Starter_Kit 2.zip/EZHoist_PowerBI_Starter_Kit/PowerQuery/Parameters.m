// Create these as individual Power Query parameters.
pHistorianServer = "10.74.51.114"
pHistorianDatabase = "Runtime"
pLegacyAlarmServer = "visusjp3gtalarm.jaxprod.local"
pLegacyAlarmDatabase = "WWALMDB"
pFlexAlarmServer = "visusjpflxalarm.jaxprod.local"
pFlexAlarmDatabase = "RWAEDB"
pRecentHours = 48
pIdleThresholdMinutes = 15
