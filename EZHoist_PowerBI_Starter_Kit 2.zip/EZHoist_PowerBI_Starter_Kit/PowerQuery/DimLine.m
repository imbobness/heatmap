let
    Source = #table({"Line", "LineNumber", "Platform", "InProduction", "IncludeInFleetTotals"}, {
        {"TAM01", 1, "Legacy", true, true},
        {"TAM02", 2, "Legacy", true, true},
        {"TAM05", 5, "Legacy", true, true},
        {"TAM06", 6, "Legacy", true, true},
        {"TAM07", 7, "Legacy", true, true},
        {"TAM09", 9, "Legacy", true, true},
        {"TAM10", 10, "Legacy", true, true},
        {"TAM17", 17, "Legacy", true, true},
        {"TAM18", 18, "Legacy", true, true},
        {"TAM20", 20, "Legacy", true, true},
        {"TAM21", 21, "Transition", true, true},
        {"TAM22", 22, "Transition", true, true},
        {"TAM23", 23, "Transition", true, true},
        {"TAM24", 24, "FLEX", true, true},
        {"TAM25", 25, "FLEX", true, true},
        {"TAM26", 26, "FLEX", true, true},
        {"TAM27", 27, "FLEX", true, true},
        {"TAM28", 28, "FLEX", true, true},
        {"TAM29", 29, "FLEX", true, true},
        {"TAM30", 30, "FLEX", true, true},
        {"TAM31", 31, "FLEX", true, true},
        {"TAM32", 32, "FLEX", false, false},
        {"TAM33", 33, "FLEX", false, false}
    }),
    Typed = Table.TransformColumnTypes(Source, {{"Line", type text}, {"LineNumber", Int64.Type}, {"Platform", type text}, {"InProduction", type logical}, {"IncludeInFleetTotals", type logical}})
in
    Typed
