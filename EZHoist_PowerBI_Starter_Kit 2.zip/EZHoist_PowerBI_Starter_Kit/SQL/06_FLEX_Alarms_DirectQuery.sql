/* FLEX alarm database: visusjpflxalarm.jaxprod.local / RWAEDB */
SELECT
    'FLEX' AS SourceSystem,
    CONCAT('TAM', RIGHT('0' + CONVERT(varchar(2), TRY_CONVERT(int, RIGHT(LoggingNode, 2))), 2)) AS Line,
    SourceName AS SourceZone,
    Message AS AlarmMessage,
    SourceName AS TagName,
    CAST('' AS varchar(50)) AS AlarmType,
    Priority,
    Severity,
    AlarmStartTimeStamp AS StartTime,
    AlarmEndTimeStamp AS EndTime,
    DATEDIFF(second, AlarmStartTimeStamp, COALESCE(AlarmEndTimeStamp, GETDATE())) AS DurationSeconds,
    Acked
FROM RWAEDB.dbo.FLEXALARMS
WHERE AlarmStartTimeStamp >= DATEADD(day, -30, GETDATE())
  AND Severity >= 740
