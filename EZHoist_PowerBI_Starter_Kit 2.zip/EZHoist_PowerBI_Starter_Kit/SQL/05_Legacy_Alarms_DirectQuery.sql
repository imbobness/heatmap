/* Legacy alarm database: visusjp3gtalarm.jaxprod.local / WWALMDB */
SELECT
    'Legacy 3GT' AS SourceSystem,
    CONCAT('TAM', RIGHT('0' + CONVERT(varchar(2), TRY_CONVERT(int, RIGHT(LoggingNode, 2))), 2)) AS Line,
    GroupName AS SourceZone,
    Comment AS AlarmMessage,
    TagName,
    AlarmType,
    Priority,
    CAST(NULL AS int) AS Severity,
    OriginationTime AS StartTime,
    ReturnTime AS EndTime,
    DATEDIFF(second, OriginationTime, COALESCE(ReturnTime, GETDATE())) AS DurationSeconds,
    CAST(NULL AS bit) AS Acked
FROM WWALMDB.dbo.[3GTAlarms]
WHERE OriginationTime >= DATEADD(day, -30, GETDATE())
  AND Priority >= 1
  AND Priority <> 500
