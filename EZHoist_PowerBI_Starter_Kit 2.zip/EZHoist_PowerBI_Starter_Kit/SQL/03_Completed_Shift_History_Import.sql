/*
EZHoist / 3GT read-only Power BI query.
Power BI DirectQuery wrapper-safe: no CTE and no trailing semicolon.
Do not grant this report account INSERT, UPDATE, DELETE, or DDL permissions.
*/

SELECT
    x.Line, x.Platform, x.ZoneKey, x.TagName,
    x.ShiftStart,
    DATEADD(hour, 12, x.ShiftStart) AS ShiftEnd,
    SUM(x.Increment) AS Production
FROM (
    SELECT
        s.Line, s.Platform, s.ZoneKey, s.TagName,
        DATEADD(hour,
            (DATEDIFF(hour, CONVERT(datetime,'19000101 06:00:00',120), s.SampleTime) / 12) * 12,
            CONVERT(datetime,'19000101 06:00:00',120)) AS ShiftStart,
        CASE
            WHEN s.PreviousValue IS NULL OR s.CounterValue IS NULL THEN NULL
            WHEN s.CounterValue >= s.PreviousValue THEN s.CounterValue - s.PreviousValue
            ELSE s.CounterValue
        END AS Increment
    FROM (
        SELECT
            m.Line, m.Platform, m.ZoneKey, h.TagName,
            h.DateTime AS SampleTime,
            CONVERT(float, h.Value) AS CounterValue,
            LAG(CONVERT(float, h.Value)) OVER
                (PARTITION BY h.TagName ORDER BY h.DateTime) AS PreviousValue
        FROM Runtime.dbo.AnalogHistory h
        INNER JOIN (
            SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'AP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'AP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'AP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'AP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'AP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'AP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'AP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'AP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM01' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'AP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'BP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'BP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'BP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'BP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'BP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'BP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'BP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'BP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM02' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'BP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'EP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'EP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'EP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'EP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'EP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'EP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'EP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'EP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM05' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'EP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'FP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'FP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'FP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'FP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'FP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'FP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'FP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'FP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM06' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'FP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'GP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'GP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'GP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'GP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'GP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'GP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'GP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'GP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM07' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'GP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'IP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'IP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'IP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'IP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'IP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'IP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'IP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'IP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM09' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'IP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'JP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'JP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'JP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'JP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'JP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'JP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'JP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'JP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM10' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'JP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'MP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'MP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'MP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'MP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'MP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'MP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'MP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'MP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM17' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'MP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'NP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'NP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'NP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'NP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'NP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'NP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'NP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'NP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM18' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'NP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z1' AS ZoneKey, 'PP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z2A' AS ZoneKey, 'PP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z3_IN' AS ZoneKey, 'PP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z3_OUT' AS ZoneKey, 'PP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z4_OUT' AS ZoneKey, 'PP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z5_IN' AS ZoneKey, 'PP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'ALI_IN' AS ZoneKey, 'PP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'ALI_OUT' AS ZoneKey, 'PP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM20' AS Line, 'Legacy' AS Platform, 'Z6_IN' AS ZoneKey, 'PP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z1' AS ZoneKey, 'L21_P1_Data.Crv_CountIMMStarts' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z2A' AS ZoneKey, 'L21_P1_Data.GoodCountInlay' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z3_IN' AS ZoneKey, 'L21_P1_Data.GoodCountCure' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z3_OUT' AS ZoneKey, 'L21_P1_Data.GoodCountDemold' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z4_OUT' AS ZoneKey, 'L21_P1_Data.GoodCountFCXfer' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z5_IN' AS ZoneKey, 'L21_P3_Data.InCountLensXfer' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'ALI_IN' AS ZoneKey, 'L21_P3_Data.OutCountLensXfer' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'ALI_OUT' AS ZoneKey, 'L21_P3_Data.OutCountDIRemoval' AS TagName
        UNION ALL
        SELECT 'TAM21' AS Line, 'Transition' AS Platform, 'Z6_IN' AS ZoneKey, 'L21_P4_Data.OutCountLoader' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z1' AS ZoneKey, 'L22_P1_Data.Crv_CountIMMStarts' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z2A' AS ZoneKey, 'L22_P1_Data.GoodCountInlay' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z3_IN' AS ZoneKey, 'L22_P1_Data.GoodCountCure' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z3_OUT' AS ZoneKey, 'L22_P1_Data.GoodCountDemold' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z4_OUT' AS ZoneKey, 'L22_P1_Data.GoodCountFCXfer' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z5_IN' AS ZoneKey, 'L22_P3_Data.InCountLensXfer' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'ALI_IN' AS ZoneKey, 'L22_P3_Data.OutCountLensXfer' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'ALI_OUT' AS ZoneKey, 'L22_P3_Data.OutCountDIRemoval' AS TagName
        UNION ALL
        SELECT 'TAM22' AS Line, 'Transition' AS Platform, 'Z6_IN' AS ZoneKey, 'L22_P4_Data.OutCountLoader' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z1' AS ZoneKey, 'SP0_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z2A' AS ZoneKey, 'SP0_GOODCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z3_IN' AS ZoneKey, 'SP0_GOODCOUNT6' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z3_OUT' AS ZoneKey, 'SP1_GOODCOUNT1' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z4_OUT' AS ZoneKey, 'SP1_GOODCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z5_IN' AS ZoneKey, 'SP2_INCOUNT2' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'ALI_IN' AS ZoneKey, 'SP2_INCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'ALI_OUT' AS ZoneKey, 'SP2_OUTCOUNT3' AS TagName
        UNION ALL
        SELECT 'TAM23' AS Line, 'Transition' AS Platform, 'Z6_IN' AS ZoneKey, 'SP3_LOAD_IN_CNT' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L24_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L24_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L24_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L24_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L24_PLC1_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L24_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L24_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L24_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM24' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L24_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L25_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L25_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L25_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L25_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L25_PLC1_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L25_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L25_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L25_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM25' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L25_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L26_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L26_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L26_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L26_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L26_PLC1_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L26_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L26_PLC3.EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L26_PLC3.EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM26' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L26_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L27_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L27_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L27_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L27_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L27_PLC1_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L27_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L27_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L27_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM27' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L27_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L28_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L28_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L28_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L28_PLC1_EM0304_WB_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L28_PLC1_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L28_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L28_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L28_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM28' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L28_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L29_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L29_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L29_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L29_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z4_IN' AS ZoneKey, 'L29_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L29_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L29_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L29_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L29_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM29' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L29_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L30_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L30_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L30_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L30_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z4_IN' AS ZoneKey, 'L30_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L30_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L30_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L30_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L30_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM30' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L30_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L31_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L31_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L31_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L31_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z4_IN' AS ZoneKey, 'L31_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L31_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L31_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L31_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L31_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM31' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L31_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L32_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L32_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L32_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L32_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z4_IN' AS ZoneKey, 'L32_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L32_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L32_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L32_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L32_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM32' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L32_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z1' AS ZoneKey, 'L33_PLC1_Global.StatsCnt_Z01.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z2A' AS ZoneKey, 'L33_PLC1_Global.StatsCnt_Z02.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z3_IN' AS ZoneKey, 'L33_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z3_OUT' AS ZoneKey, 'L33_PLC2_EM0312_Demold.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z4_IN' AS ZoneKey, 'L33_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z4_OUT' AS ZoneKey, 'L33_PLC2_EM0332_FC_Transfer.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z5_IN' AS ZoneKey, 'L33_PLC3_EM0510_Lens_Transfer.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'ALI_IN' AS ZoneKey, 'L33_PLC3_EM0514_DI_Removal_Inlet.StatsCnt.CurrS.Total.In' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'ALI_OUT' AS ZoneKey, 'L33_PLC3_EM0518_DI_Removal_Outlet.StatsCnt.CurrS.Total.Out' AS TagName
        UNION ALL
        SELECT 'TAM33' AS Line, 'FLEX' AS Platform, 'Z6_IN' AS ZoneKey, 'L33_PLC4_EM0602_Stray_Indexer.StatsCnt.CurrS.Total.In' AS TagName
        ) m ON m.TagName = h.TagName
        WHERE h.DateTime >= DATEADD(day, -60, GETDATE())
          AND h.DateTime < DATEADD(hour,
              (DATEDIFF(hour, CONVERT(datetime,'19000101 06:00:00',120), GETDATE()) / 12) * 12,
              CONVERT(datetime,'19000101 06:00:00',120))
          AND h.wwRetrievalMode = 'Delta'
    ) s
) x
WHERE x.Increment IS NOT NULL
GROUP BY x.Line, x.Platform, x.ZoneKey, x.TagName, x.ShiftStart
