# 3GT TAM Operations Dashboard — Visual Studio Edition

This is the complete C# / ASP.NET Core migration of the Python heatmap dashboard.
It is a read-only manufacturing visualization: it reads historian and alarm data,
stores only local dashboard configuration/cache state, and does not control equipment,
modify source data, disposition product, or create authoritative manufacturing records.

## Requirements

- Windows 10/11 or Windows Server
- Visual Studio 2026 with **ASP.NET and web development**
- .NET 10 SDK
- ODBC Driver 18 for SQL Server (or the approved site driver)
- Network access to the AVEVA production historian and both alarm databases
- Outlook desktop for the default Outlook email transport, or configured SMTP

## Open and run

1. Open `HeatmapDashboard.sln` in Visual Studio.
2. Allow NuGet restore to finish.
3. Select **Heatmap Demo** to run without historian access.
4. Select **Heatmap Live** only while connected to the manufacturing network.
5. Press `F5`.
6. The dashboard opens at `http://localhost:8787`.

Automatic email is forced **OFF** at every application startup. Enable it only from
Shift Control after confirming the correct mode, historian status, lines, and recipients.

## Live environment variables

Production historian authentication can use Windows integrated security. If SQL
credentials are required, set:

```powershell
$env:WW_SQL_USER = "approved-user"
$env:WW_SQL_PASSWORD = "approved-password"
```

Alarm historian access uses:

```powershell
$env:ALARM_SQL_USER = "wwUser"
$env:ALARM_SQL_PASSWORD = "approved-password"
```

Optional server/driver overrides:

```powershell
$env:WW_SQL_DRIVER = "ODBC Driver 18 for SQL Server"
$env:WW_SQL_SERVER = "VISUSJANAW0002"
$env:WW_SQL_DATABASE = "Runtime"
$env:LEGACY_ALARM_SERVER = "visusjp3gtalarm.jaxprod.local"
$env:LEGACY_ALARM_DATABASE = "WWALMDB"
$env:FLEX_ALARM_SERVER = "visusjpflxalarm.jaxprod.local"
$env:FLEX_ALARM_DATABASE = "RWAEDB"
```

Do not put passwords in `appsettings.json`, source control, or screenshots.

## Preserved behavior

- Operations heatmap and all-lines loader table
- Current Rate, Trend, and Action in live overview
- Line Story and selected-zone hourly downtime chart
- Trends and thirty-day Shift History
- Management Review trigger/recovery logic
- Historical-record rebuild
- Validated non-stopping, downstream, operator-access, and root-cause alarm rules
- Zones 7–10 exclusion from alarm/output analysis
- Out-of-production line filtering
- Hourly performance email
- Zone inactivity and recovery email
- 5:00 PM day-shift downtime summary for 6:00 AM–5:00 PM
- Manual downtime preview and confirmed manual send from Shift Control
- Duplicate-send state and startup email safety
- Demo and Live profiles

## 5:00 PM downtime summary

The hosted notification worker runs once per minute. At or after 5:00 PM during the
day shift it queries all active measured counters in one batched request, calculates
sustained no-increment periods, and sends one report per date to the active Hourly
Performance distribution list. The fixed query window is 6:00 AM–5:00 PM even if the
application catches up after 5:00 PM.

Line downtime uses `Z6_IN` as the output proxy. Zone downtime overlaps and is not
summed to obtain line downtime. Planned downtime remains identified as a limitation
until a reliable schedule/source is connected.

The manual preview button never sends email and never changes scheduled-send state.
Before 5:00 PM it queries 6:00 AM through the current time; after 5:00 PM it queries
the completed 6:00 AM–5:00 PM window. Manual sending requires Live mode, enabled
email, and confirmation. A completed report can optionally count as the day's
scheduled email; a partial report cannot suppress the later scheduled report.

## Publishing

Run `publish_windows.ps1`, or use Visual Studio **Publish → Folder**. The scripted
output is a self-contained `win-x64` folder under `publish`.

For shared production use, host the published application through IIS or install it
as a Windows Service after site IT approval. Do not run the production dashboard from
the Visual Studio development server.

## Validation

In Visual Studio, select **Test → Run All Tests**. Before live release also complete
`LIVE_VALIDATION_CHECKLIST.md` and compare a known shift against the Python v15.2
dashboard and the source historians.
