using System.Text.Json;
using System.Text.Json.Nodes;
using HeatmapDashboard.Web.Models;
using HeatmapDashboard.Web.Services;
using HeatmapDashboard.Web.Workers;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);
builder.Services.Configure<DashboardOptions>(builder.Configuration.GetSection("Dashboard"));
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<ConfigurationStore>();
builder.Services.AddSingleton<SyntheticHistorianService>();
builder.Services.AddSingleton<AvevaHistorianService>();
builder.Services.AddSingleton<IHistorianService>(sp =>
    sp.GetRequiredService<IOptions<DashboardOptions>>().Value.IsLive
        ? sp.GetRequiredService<AvevaHistorianService>()
        : sp.GetRequiredService<SyntheticHistorianService>());
builder.Services.AddSingleton<DashboardService>();
builder.Services.AddSingleton<AlarmService>();
builder.Services.AddSingleton<EmailService>();
builder.Services.AddSingleton<HistoricalRecordService>();
builder.Services.AddHostedService<NotificationWorker>();
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    options.SerializerOptions.WriteIndented = false;
});

var app = builder.Build();
app.UseDefaultFiles();
app.UseStaticFiles();

// Startup safety: communication is always opt-in after the application is opened.
var configStore = app.Services.GetRequiredService<ConfigurationStore>();
var startupAlerts = configStore.LoadAlerts();
startupAlerts["enabled"] = false;
await configStore.SaveAlertsAsync(startupAlerts);

app.MapGet("/api/mappings", (ConfigurationStore store) => Results.Ok(store.LoadLineTags()));
app.MapGet("/api/data", async (string? line, DashboardService dashboard, ConfigurationStore store, CancellationToken token) =>
    Results.Ok(await dashboard.GetLineDataAsync(line ?? store.LoadLineTags().Keys.First(), token)));
app.MapGet("/api/overview", async (DashboardService dashboard, CancellationToken token) => Results.Ok(await dashboard.GetOverviewAsync(token)));
app.MapGet("/api/review-triggers", async (DashboardService dashboard, CancellationToken token) => Results.Ok(await dashboard.GetReviewTriggersAsync(token)));
app.MapGet("/api/history", async (string? line, int? count, DashboardService dashboard, ConfigurationStore store, CancellationToken token) =>
    Results.Ok(await dashboard.GetHistoryAsync(line ?? store.LoadLineTags().Keys.First(), count ?? 60, token)));
app.MapGet("/api/zone-downtime", async (string? line, string? zone, DashboardService dashboard, ConfigurationStore store, CancellationToken token) =>
    Results.Ok(await dashboard.GetZoneDowntimeAsync(line ?? store.LoadLineTags().Keys.First(), zone ?? "Z6_IN", token)));
app.MapGet("/api/downtime-summary/preview", async (DashboardService dashboard, IHistorianService historian, CancellationToken token) =>
{
    if (!historian.IsLive) return Results.BadRequest(new { error = "Manual downtime summary preview requires Live mode" });
    return Results.Ok(await dashboard.GetManualDowntimeSummaryAsync(DateTime.Now, token));
});

app.MapGet("/api/alarms", async (string? line, AlarmService alarms, ConfigurationStore store, CancellationToken token) =>
{
    var selected = line ?? store.LoadLineTags().Keys.First();
    return Results.Ok(new { line = selected, alarms = await alarms.GetAlarmsAsync(selected, 24, token), generatedAt = DateTimeOffset.Now });
});
app.MapGet("/api/story", async (string? line, AlarmService alarms, ConfigurationStore store, CancellationToken token) =>
{
    var selected = line ?? store.LoadLineTags().Keys.First();
    return Results.Ok(BuildStory(selected, await alarms.GetAlarmsAsync(selected, 24, token)));
});
app.MapGet("/api/snapshot", async (string? line, DashboardService dashboard, AlarmService alarms, ConfigurationStore store, CancellationToken token) =>
{
    var selected = line ?? store.LoadLineTags().Keys.First();
    var productionTask = dashboard.GetLineDataAsync(selected, token);
    var alarmTask = alarms.GetAlarmsAsync(selected, 24, token);
    await Task.WhenAll(productionTask, alarmTask);
    return Results.Ok(new { line = selected, production = productionTask.Result, alarms = alarmTask.Result, story = BuildStory(selected, alarmTask.Result), generatedAt = DateTimeOffset.Now });
});
app.MapGet("/api/interventions", (string? line) => Results.Ok(new { line, actions = Array.Empty<object>(), visualizationOnly = true }));

app.MapGet("/api/zone-alerts", (ConfigurationStore store) =>
{
    var state = store.LoadAlertState();
    var zones = state["zones"] as JsonObject ?? new JsonObject();
    var active = zones.Select(x => x.Value as JsonObject).Where(x => x?["alerted"]?.GetValue<bool?>() == true)
        .Where(x => store.LineIsInProduction(x?["line"]?.GetValue<string>() ?? "")).ToList();
    return Results.Ok(new { generatedAt = DateTimeOffset.Now, alerts = active });
});
app.MapGet("/api/alerts/status", (ConfigurationStore store) =>
{
    var config = store.LoadAlerts(); var state = store.LoadAlertState(); var zones = state["zones"] as JsonObject ?? new JsonObject();
    var active = zones.Select(x => x.Value as JsonObject).Where(x => x?["alerted"]?.GetValue<bool?>() == true)
        .Where(x => store.LineIsInProduction(x?["line"]?.GetValue<string>() ?? "")).ToList();
    return Results.Ok(new { enabled = config["enabled"]?.GetValue<bool?>() ?? false, transport = config["transport"]?.GetValue<string>() ?? "outlook",
        lastRun = state["lastRun"], lastZoneCheck = state["lastZoneCheck"], lastError = state["lastError"], activeZoneAlerts = active });
});

app.MapGet("/api/health", async (IHistorianService historian, AlarmService alarms, CancellationToken token) =>
{
    var production = await historian.CheckHealthAsync(token); var alarm = await alarms.HealthAsync(token);
    return Results.Ok(new { production = new { ok = production.Ok, detail = production.Detail }, alarms = alarm });
});
app.MapGet("/api/compliance-boundary", () => Results.Ok(new
{
    applicationVersion = "16.1-manual-downtime-summary", visualizationOnly = true, readOnly = true,
    machineControl = false, sourceModification = false, productDisposition = false,
    authoritativeRecord = false, emailSending = true, emailConfigurationOnly = true, operationalRecordEntry = false
}));

app.MapGet("/api/settings/email-control", (ConfigurationStore store) =>
{
    var config = store.LoadAlerts(); return Results.Ok(new { enabled = config["enabled"]?.GetValue<bool?>() ?? false, transport = config["transport"]?.GetValue<string>() ?? "outlook" });
});
app.MapGet("/api/settings/recipients", (ConfigurationStore store) => Results.Ok(store.LoadRecipients()));
app.MapGet("/api/settings/line-status", (ConfigurationStore store) => Results.Ok(new { lines = store.LoadLineStatus() }));
app.MapGet("/api/settings/targets", (ConfigurationStore store) => Results.Ok(new { targets = store.LoadTargets() }));
app.MapGet("/api/history-records", (string? line, HistoricalRecordService records, ConfigurationStore store) => Results.Ok(records.Summary(line ?? store.LoadLineTags().Keys.First())));
app.MapGet("/api/history-records/status", (HistoricalRecordService records) => Results.Ok(records.Status));
app.MapGet("/api/history-records/rebuild", (HistoricalRecordService records) => Results.Ok(records.Start()));

app.MapPost("/api/settings/email-control", async (JsonObject payload, ConfigurationStore store) =>
{
    var config = store.LoadAlerts(); config["enabled"] = payload["enabled"]?.GetValue<bool?>() ?? false; await store.SaveAlertsAsync(config);
    return Results.Ok(new { ok = true, enabled = config["enabled"] });
});
app.MapPost("/api/settings/recipients", async (JsonObject payload, ConfigurationStore store) =>
{
    if (payload["people"] is not JsonArray || payload["groups"] is not JsonObject) return Results.BadRequest(new { error = "Invalid recipient configuration" });
    await store.SaveRecipientsAsync(payload); return Results.Ok(new { ok = true });
});
app.MapPost("/api/settings/line-status", async (JsonObject payload, ConfigurationStore store) =>
{
    var submitted = payload["lines"] as JsonObject ?? new JsonObject();
    var clean = new JsonObject(); foreach (var line in store.LoadLineTags().Keys) clean[line] = submitted[line]?.GetValue<bool?>() ?? true;
    await store.SaveLineStatusAsync(clean); return Results.Ok(new { ok = true, lines = clean });
});
app.MapPost("/api/settings/targets", async (JsonObject payload, ConfigurationStore store) =>
{
    var line = payload["line"]?.GetValue<string>() ?? ""; var values = payload["values"] as JsonObject;
    if (!store.LoadLineTags().ContainsKey(line) || values is null) return Results.BadRequest(new { error = "Invalid line or target values" });
    foreach (var item in values)
    {
        var number = item.Value?.GetValue<double?>() ?? 0;
        if (number < 0 || item.Key.Contains("YIELD", StringComparison.OrdinalIgnoreCase) && number > 100)
            return Results.BadRequest(new { error = $"Invalid target {item.Key}" });
    }
    var targets = store.LoadTargets(); targets[line] = values.DeepClone(); await store.SaveTargetsAsync(targets);
    return Results.Ok(new { ok = true, line, targets = values });
});
app.MapPost("/api/history-records/rebuild", (HistoricalRecordService records) => Results.Ok(records.Start()));
app.MapPost("/api/downtime-summary/send", async (JsonObject payload, DashboardService dashboard, IHistorianService historian,
    EmailService email, ConfigurationStore store, CancellationToken token) =>
{
    if (!historian.IsLive) return Results.BadRequest(new { error = "Manual downtime summary email requires Live mode" });
    if (!(payload["confirmed"]?.GetValue<bool?>() ?? false)) return Results.BadRequest(new { error = "Manual downtime email requires confirmation" });
    var config = store.LoadAlerts();
    if (!(config["enabled"]?.GetValue<bool?>() ?? false)) return Results.BadRequest(new { error = "Enable automatic emails in Shift Control before sending a manual downtime summary" });
    var report = await dashboard.GetManualDowntimeSummaryAsync(DateTime.Now, token);
    await email.SendAsync(config, store.ResolveRecipients("performance"), report.Subject, report.Html, true, token);
    var counted = (payload["countAsScheduled"]?.GetValue<bool?>() ?? false) && report.CompleteWindow;
    if (counted)
    {
        var state = store.LoadAlertState();
        var sent = state["dailySummarySent"] as JsonObject ?? new JsonObject();
        sent[report.WindowStart.ToString("yyyy-MM-dd")] = new JsonObject
        {
            ["sentAt"] = DateTime.Now.ToString("O"), ["windowStart"] = report.WindowStart.ToString("O"),
            ["windowEnd"] = report.WindowEnd.ToString("O"), ["lineDowntimeMinutes"] = report.LineDowntimeMinutes,
            ["lines"] = report.LineRows.Count, ["zoneRows"] = report.ZoneRows.Count, ["manual"] = true
        };
        state["dailySummarySent"] = sent.DeepClone();
        await store.SaveAlertStateAsync(state);
    }
    return Results.Ok(new { ok = true, sent = true, countedAsScheduled = counted, report });
});

app.MapFallbackToFile("index.html");
app.Run();

static object BuildStory(string line, IReadOnlyList<AlarmEvent> alarms)
{
    var actionable = alarms.Where(x => !x.Nuisance).ToList();
    var roots = actionable.Count(x => x.Classification is "Root-cause Candidate" or "Confirmed Root Cause");
    var access = alarms.Count(x => x.Classification == "Operator Access");
    var minutes = alarms.Where(x => !x.Nuisance).Sum(x => x.DurationSeconds) / 60;
    var timeline = alarms.Take(30).Select(x => new { timestamp = x.Start, kind = "alarm", label = x.Classification, zone = x.Zone, detail = x.Alarm });
    return new
    {
        line, headline = actionable.Count == 0 ? "No actionable alarm burden detected" : $"{actionable.Count} actionable alarm event(s) require review",
        narrative = $"The timeline contains {roots} root-cause candidate(s) and {access} operator-access event(s). Alarm association is temporal evidence, not proof of causation.",
        alarmMinutes = minutes, rootCandidates = roots, operatorAccess = access, interventionCount = 0, timeline, alarms
    };
}

public partial class Program { }
