namespace HeatmapDashboard.Web.Models;

public sealed record HistorianSample(DateTime Timestamp, double? Value);
public sealed record TaggedHistorianSample(DateTime Timestamp, string Tag, double? Value);
public sealed record LiveTagValue(DateTime? Timestamp, double? Value, int? Quality = null, string? QualityDetail = null);

public sealed record DowntimeInterval(DateTime Start, DateTime End)
{
    public double Minutes => Math.Max(0, (End - Start).TotalMinutes);
}

public sealed record DowntimeMetric(
    double DowntimeMinutes,
    int EventCount,
    double LongestStopMinutes,
    double Production,
    double CoveragePercent,
    string CurrentStatus,
    DateTime? FirstStop,
    DateTime? LatestRecovery,
    IReadOnlyList<DowntimeInterval> Intervals);

public sealed record ZoneDowntimeRow(
    string Line,
    string Zone,
    string Tag,
    double DowntimeMinutes,
    int EventCount,
    double LongestStopMinutes,
    double Production,
    double CoveragePercent,
    string CurrentStatus);

public sealed record HourlyDowntimeBar(
    DateTime Start,
    DateTime End,
    string Label,
    double DowntimeMinutes,
    int EventCount);

public sealed record ManualDowntimeReport(
    DateTime GeneratedAt,
    DateTime WindowStart,
    DateTime WindowEnd,
    DateTime ScheduledEnd,
    bool CompleteWindow,
    string Subject,
    string Html,
    IReadOnlyList<ZoneDowntimeRow> LineRows,
    IReadOnlyList<ZoneDowntimeRow> ZoneRows,
    double LineDowntimeMinutes,
    double MinimumIdleMinutes,
    string LineDowntimeZone);

public sealed record AlarmEvent(
    string SourceSystem,
    string Line,
    string Zone,
    string Alarm,
    string Tag,
    DateTime Start,
    DateTime? End,
    double DurationSeconds,
    bool Acked,
    string Classification,
    bool Nuisance,
    bool ExcludedFromAnalysis,
    string? RootCauseTag = null);

public sealed class DashboardOptions
{
    public string Mode { get; set; } = "Demo";
    public int RefreshSeconds { get; set; } = 60;
    public int HistoryHours { get; set; } = 12;
    public int ShiftHours { get; set; } = 12;
    public int DayShiftStartHour { get; set; } = 6;
    public int NightShiftStartHour { get; set; } = 18;
    public HistorianOptions Historian { get; set; } = new();
    public bool IsLive => Mode.Equals("Live", StringComparison.OrdinalIgnoreCase);
}

public sealed class HistorianOptions
{
    public string Driver { get; set; } = "ODBC Driver 18 for SQL Server";
    public string Server { get; set; } = "VISUSJANAW0002";
    public string Database { get; set; } = "Runtime";
    public bool TrustedConnection { get; set; } = true;
    public bool Encrypt { get; set; } = true;
    public bool TrustServerCertificate { get; set; } = true;
    public string UsernameEnvironmentVariable { get; set; } = "WW_SQL_USER";
    public string PasswordEnvironmentVariable { get; set; } = "WW_SQL_PASSWORD";
}
