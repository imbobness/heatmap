$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
Write-Host "Starting 3GT TAM dashboard in OFFLINE DEMO mode..." -ForegroundColor Cyan
py -m py_compile .\app.py
Start-Process "http://localhost:8080"
py .\app.py
