$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not $env:WW_SQL_USER) { $env:WW_SQL_USER = Read-Host "Historian SQL username" }
if (-not $env:WW_SQL_PASSWORD) {
  $secure = Read-Host "Historian SQL password" -AsSecureString
  $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  try { $env:WW_SQL_PASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}
py -m py_compile .\app.py
py .\app.py
